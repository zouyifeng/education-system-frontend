/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-29
 */
package com.chao.chaosearchapp.manager;

import org.afinal.simplecache.SimplceCache;

import com.chao.chaosearchapp.ChaoSearchApplication;
import com.chao.chaosearchapp.model.AppInfoBO;

/**
 * 
 * 1、是否首次进入App<br />
 * 2、更新App<br />
 * 
 * @author chaoking
 * 
 */
public class AppManager {

	private static final String TAG = "AppManager.TAG";
	private static SimplceCache mAppCache = SimplceCache.get(
			ChaoSearchApplication.getContext(), "chao_app_info");
	private static AppInfoBO mAppInfo;

	public static AppInfoBO getAppInfo() {
		if (mAppInfo == null)
			mAppInfo = (AppInfoBO) mAppCache.getAsObject("info_");
		if (mAppInfo == null)
			mAppInfo = new AppInfoBO();
		return mAppInfo;
	}

	public static void putAppInfo(AppInfoBO appInfo) {
		mAppInfo = appInfo;
		mAppCache.put("info_", appInfo, 3 * SimplceCache.TIME_DAY);
	}

	public static boolean isFirstInAppFlag() {
		String firstFlag = mAppCache.getAsString("first_in_app_flag");
		if (firstFlag == null || "".equals(firstFlag))
			return true;
		return Boolean.valueOf(firstFlag);
	}

	public static void setFirstInAppFlag(boolean flag) {
		mAppCache.put("first_in_app_flag", String.valueOf(flag));
	}

	/**
	 * @return the language
	 */
	public static String getLanguage(String defaultValue) {
		return returnDefaultValue(mAppCache.getAsString("app_language"),
				defaultValue);
	}

	/**
	 * 
	 * @param language
	 *            the language to set
	 */
	public static void setLanguage(String language) {
		mAppCache.put("app_language", language);
	}

	private static String returnDefaultValue(String value, String defaultValue) {
		if (value != null && !"".equals(value))
			return value;
		return defaultValue;
	};

}
