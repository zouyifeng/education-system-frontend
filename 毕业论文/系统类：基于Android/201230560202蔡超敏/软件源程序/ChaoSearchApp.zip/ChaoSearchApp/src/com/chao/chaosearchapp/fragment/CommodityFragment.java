/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-10
 */
package com.chao.chaosearchapp.fragment;

import java.util.Iterator;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.activity.BrowserActivity;
import com.chao.chaosearchapp.model.CommodityBO;
import com.chao.chaosearchapp.model.PriceBO;
import com.chao.chaosearchapp.util.imageLoader.ImageLoader;
import com.handmark.pulltorefresh.library.PullToRefreshScrollView;

/**
 * @author chaoking
 * 
 */
public class CommodityFragment extends ChaoBaseFragment {

	private CommodityBO commodityBO;

	// 组件
	private CommodityViewHolder commodityViewHolder;

	/**
	 * 必须最好调用initImageLoader初始化才用
	 */
	private ImageLoader mLoader;

	@Override
	protected View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_commodity, container,
				false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		commodityViewHolder = new CommodityViewHolder(view);

		PullToRefreshScrollView refreshScrollView = (PullToRefreshScrollView) view
				.findViewById(R.id.commodity_scrollview);
		// 这几个刷新Label的设置
		refreshScrollView.getLoadingLayoutProxy().setPullLabel(null);
		refreshScrollView.getLoadingLayoutProxy().setRefreshingLabel(null);
		refreshScrollView.getLoadingLayoutProxy().setReleaseLabel(null);
		refreshScrollView.getLoadingLayoutProxy().setLoadingDrawable(null);
	}

	/**
	 * 初始化图片加载组件
	 */
	private void initImageLoader() {
		mLoader = new ImageLoader(mActivity);
		WindowManager wm = (WindowManager) mActivity
				.getSystemService(Context.WINDOW_SERVICE);
		int width = wm.getDefaultDisplay().getWidth();
		mLoader.setIsUseMediaStoreThumbnails(false);
		mLoader.setRequiredSize(width / 3);
	}

	@Override
	protected void initData() {
		initImageLoader();
		commodityBO = (CommodityBO) mActivity.getIntent().getSerializableExtra(
				Constants.KEY_COMMODITY_COMMODITYBO);
		if (commodityBO != null)
			refreshLayout(commodityBO);
	}

	public void refreshLayout(CommodityBO commodityBO) {
		this.commodityBO = commodityBO;
		mLoader.DisplayImage(commodityBO.getPic(), commodityViewHolder.imPic,
				R.drawable.ic_launcher);
		commodityViewHolder.tvName.setText(commodityBO.getName());
		commodityViewHolder.tvIntroduce.setText(commodityBO.getIntroduce());

		if (commodityBO.getPrices() != null
				&& !commodityBO.getPrices().isEmpty()) {
			commodityViewHolder.layoutStore.setVisibility(View.VISIBLE);
			commodityViewHolder.layoutStore.removeAllViews();

			int commodityPriceNum = commodityBO.getPrices().size();
			LayoutInflater inflater = LayoutInflater.from(mActivity);
			for (Iterator<PriceBO> iterator = commodityBO.getPrices()
					.iterator(); iterator.hasNext();) {
				final PriceBO priceBO = iterator.next();
				View itemView = inflater.inflate(R.layout.item_commodity_store,
						commodityViewHolder.layoutStore, false);

				StoreViewHolder storeViewHolder = new StoreViewHolder(itemView);

				mLoader.DisplayImage(priceBO.getStore().getPic(),
						storeViewHolder.imPic, R.drawable.ic_launcher);
				storeViewHolder.tvName.setText(priceBO.getStore().getName());
				storeViewHolder.tvPrice.setText(String.format("¥%.2f",
						priceBO.getEstimateAmount()));

				if (priceBO.getModelType() == 1) {
					storeViewHolder.tvType.setText("现金商品");
					storeViewHolder.tvType
							.setBackgroundResource(R.drawable.bg_btn_green);
					storeViewHolder.tvUp.setVisibility(View.GONE);
				} else if (priceBO.getModelType() == 3) {
					storeViewHolder.tvType.setText("折扣商品");
					double diffValue = priceBO.getFaceValue()
							- priceBO.getEstimateAmount();

					double percentage = diffValue / priceBO.getFaceValue();

					storeViewHolder.tvUp.setText("下降了"
							+ String.format("%.2f", percentage * 100) + "%");
				} else {
					storeViewHolder.tvType.setText("抵扣商品");
					double diffValue = priceBO.getFaceValue()
							- priceBO.getEstimateAmount();

					double percentage = diffValue / priceBO.getFaceValue();

					storeViewHolder.tvUp.setText("下降了"
							+ String.format("%.2f", percentage * 100) + "%");
				}

				itemView.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						if (priceBO != null && priceBO.getUrl() != null) {
							String link = priceBO.getUrl();
							if (Patterns.WEB_URL.matcher(link).matches()) {
								// makeToast("链接符合标准"+obj.getUrl());
								// 符合标准
								Intent webIntent = new Intent(mActivity,
										BrowserActivity.class);
								webIntent.putExtra(Constants.KEY_BROWSER_LINK,
										link);
								webIntent.putExtra(Constants.KEY_BROWSER_TITLE,
										priceBO.getStore().getName());
								webIntent.putExtra(Constants.KEY_BROWSER_TYPE,
										1);
								webIntent
										.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
								startActivity(webIntent);
							} else {
								// 不符合标准
								makeToast("链接不符合标准" + priceBO.getUrl());
							}
						}
					}
				});

				itemView.setTag(priceBO);
				commodityViewHolder.layoutStore.addView(itemView);
			}

		} else {
			commodityViewHolder.layoutStore.setVisibility(View.GONE);
		}
	}

	@Override
	protected void addListener() {
		// TODO Auto-generated method stub

	}

	static class CommodityViewHolder {
		public CommodityViewHolder(View view) {
			imPic = (ImageView) view.findViewById(R.id.commodity_pic);
			tvName = (TextView) view.findViewById(R.id.commodity_name);
			tvIntroduce = (TextView) view
					.findViewById(R.id.commodity_introduce);
			layoutStore = (LinearLayout) view
					.findViewById(R.id.commodity_store_layout);
		}

		ImageView imPic;
		TextView tvName;
		TextView tvIntroduce;
		LinearLayout layoutStore;
	}

	static class StoreViewHolder {
		public StoreViewHolder(View view) {
			imPic = (ImageView) view.findViewById(R.id.commodity_store_pic);
			tvName = (TextView) view.findViewById(R.id.commodity_store_name);
			tvType = (TextView) view
					.findViewById(R.id.commodity_store_price_type);
			tvUp = (TextView) view.findViewById(R.id.commodity_store_price_up);
			tvPrice = (TextView) view
					.findViewById(R.id.commodity_store_price_estimate_amount);
		}

		ImageView imPic;
		TextView tvName;
		TextView tvType;
		TextView tvUp;
		TextView tvPrice;
	}

}
