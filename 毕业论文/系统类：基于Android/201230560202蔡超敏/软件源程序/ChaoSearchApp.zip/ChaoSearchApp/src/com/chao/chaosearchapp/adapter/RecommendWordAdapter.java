/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-25
 */
package com.chao.chaosearchapp.adapter;

import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.chao.chaosearchapp.R;

/**
 * @author chaoking
 * 
 */
public class RecommendWordAdapter extends ChaoBaseAdapter<String> {

	private boolean isChange = true;


	/**
	 * @param context
	 */
	public RecommendWordAdapter(Context context) {
		super(context);
	}

	@Override
	public void addItems(List<String> itemList) {
		if (!itemList.isEmpty()) {
			super.addItems(itemList);
			addItem(0, "热搜");
			setChange(true);
		}
	}

	@Override
	public View getView(int i, View view, ViewGroup viewGroup) {
		ViewHolder holder;
		if (view == null) {
			view = inflater.inflate(R.layout.item_list_recommend_word,
					viewGroup, false);
			holder = new ViewHolder();
			holder.tvTitle = (TextView) view
					.findViewById(R.id.item_list_recommend_title);
			holder.btnWord = (Button) view
					.findViewById(R.id.item_list_recommend_word);
			view.setTag(holder);
		} else {
			holder = (ViewHolder) view.getTag();
		}

		String obj = (String) getItem(i);

		if (i == 0) {
			holder.tvTitle.setVisibility(View.VISIBLE);
			holder.btnWord.setVisibility(View.GONE);

			holder.tvTitle.setText(obj);
		} else {
			holder.tvTitle.setVisibility(View.GONE);
			holder.btnWord.setVisibility(View.VISIBLE);

			holder.btnWord.setText(obj);
//			holder.btnWord.setOnClickListener(onClickListener);
		}

		return view;
	}

	static class ViewHolder {
		TextView tvTitle;
		Button btnWord;
	}

	/**
	 * @return the isChange
	 */
	public boolean isChange() {
		return isChange;
	}

	/**
	 * @param isChange
	 *            the isChange to set
	 */
	public void setChange(boolean isChange) {
		this.isChange = isChange;
	}

}
