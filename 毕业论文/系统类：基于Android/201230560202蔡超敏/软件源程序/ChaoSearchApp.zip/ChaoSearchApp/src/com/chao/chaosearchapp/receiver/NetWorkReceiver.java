/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-5-2
 */
package com.chao.chaosearchapp.receiver;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.view.View;
import android.view.View.OnClickListener;

import com.chao.chaosearchapp.ChaoSearchApplication;
import com.chao.chaosearchapp.activity.ChaoBaseActivity;
import com.chao.chaosearchapp.manager.AppManager;
import com.chao.chaosearchapp.model.AppInfoBO;
import com.litesuits.android.log.Log;
import com.litesuits.common.assist.Network;

/**
 * @author chaoking
 * 
 */
public class NetWorkReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		Log.d("NetWorkReceiver", "chaoking-NetWorkReceiver");
		String mAction = intent.getAction();
		if (mAction.equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
			if (Network.isConnectedOrConnecting(ChaoSearchApplication
					.getContext())) {
				AppInfoBO appInfo = AppManager.getAppInfo();
				if (appInfo == null) {// 连接服务器出问题
					Log.d("NetWorkReceiver",
							"chaoking-NetWorkReceiver-连接服务器出问题");
					showNetworkTip(context, true, "连接服务器出问题");
					return;
				} else {// 连接服务器正常
					Log.d("NetWorkReceiver", "chaoking-NetWorkReceiver-连接服务器正常");
					showNetworkTip(context, false, "连接服务器正常");
					return;
				}
			} else {// 网络已断开
				Log.d("NetWorkReceiver", "chaoking-NetWorkReceiver-网络已断开");
				showNetworkTip(context, true, "网络请求失败，请检查您的网络设置");
				return;
			}
		}
	}

	private void showNetworkTip(final Context context, boolean isShow,
			String text) {
		ChaoSearchApplication.networkTip.setShow(isShow);
		ChaoSearchApplication.networkTip.setTip(text);
		ChaoSearchApplication.networkTip
				.setClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Intent wifiSettingsIntent = new Intent(
								"android.settings.WIFI_SETTINGS");
						wifiSettingsIntent
								.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						context.startActivity(wifiSettingsIntent);
					}
				});

		Activity activity = ChaoSearchApplication.getCurActivity();
		if (activity != null)
			((ChaoBaseActivity) activity).setNetworkTip();
	}
}
