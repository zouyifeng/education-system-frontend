/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-27
 */
package com.chao.chaosearchapp.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.ChaoActionBar;
import com.chao.chaosearchapp.assembly.ChaoActionBar.ChaoActionBarCallBack;
import com.chao.chaosearchapp.assembly.ChaoSearchEditText;
import com.chao.chaosearchapp.fragment.CommodityListFragment;
import com.chao.chaosearchapp.fragment.HistoryKeywordSearchFragment;
import com.chao.chaosearchapp.manager.UserManager;
import com.chao.chaosearchapp.util.AppUtil;

/**
 * 显示商品列表
 * 
 * @author chaoking
 * 
 */
public class CommodityListActivity extends SingleFragmentActivity {

	private ChaoSearchEditText chaoSearchEditText;

	@Override
	protected Fragment createFragment() {
		return new CommodityListFragment();
	}

	@Override
	protected void initViews() {
		ChaoActionBar chaoActionBar = getChaoActionBar();
		chaoActionBar.getTitleView().setVisibility(View.GONE);
		chaoActionBar.setHomeIcon(R.drawable.arrow_left_circle);
		chaoActionBar.getHomeView().setPadding(
				AppUtil.dpToPx(10, getResources()), 0, 0, 0);
		chaoActionBar.getHomeView().setVisibility(View.VISIBLE);

		chaoActionBar.setSubmenuIcon(0);
		((Button) chaoActionBar.getSubMenuView()).setTextColor(getResources()
				.getColor(R.color.theme_font_black));
		((Button) chaoActionBar.getSubMenuView()).setTextSize(
				TypedValue.COMPLEX_UNIT_SP, 15);
		chaoActionBar.getSubMenuView().setBackgroundDrawable(null);
		chaoActionBar.setSubmenuText("搜索");
		chaoActionBar.getSubMenuView().setVisibility(View.VISIBLE);

		chaoActionBar.setGrayBackgroundColor();

		chaoSearchEditText = getChaoActionBar().getChaoSearchEditText();
		chaoSearchEditText.setVisibility(View.VISIBLE);
	}

	@Override
	protected void initData() {
		Intent intent=getIntent();
		Bundle bundle=intent.getExtras();
		String keyword=bundle.getString(Constants.KEY_SEARCH_KEYWORD);
		chaoSearchEditText.setText(keyword);
		chaoSearchEditText.setSelection(keyword.length());
		
		UserManager.setHistorySearchKeyword(keyword);
	}

	@Override
	protected void addListener() {
		chaoSearchEditText.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				finish();
				return false;
			}
		});
	}

	@Override
	protected ChaoActionBarCallBack addChaoActionBarCallBack() {
		return new ChaoActionBarCallBack() {

			@Override
			public void onSubmenuClickCallBack(Button submenubtn) {

			}

			@Override
			public void onHomeClickCallBack(Button homebtn) {
				finish();
			}
		};
	}
}
