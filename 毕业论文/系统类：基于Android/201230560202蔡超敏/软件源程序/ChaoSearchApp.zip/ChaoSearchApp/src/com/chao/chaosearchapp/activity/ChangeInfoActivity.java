/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-11
 */
package com.chao.chaosearchapp.activity;

import android.support.v4.app.Fragment;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.ChaoActionBar;
import com.chao.chaosearchapp.fragment.ChangeInfoFragment;
import com.chao.chaosearchapp.util.AppUtil;

/**
 * @author chaoking
 * 
 */
public class ChangeInfoActivity extends SingleFragmentActivity {

	private int type = 0;

	@Override
	protected Fragment createFragment() {
		return new ChangeInfoFragment();
	}

	@Override
	protected void initViews() {
		ChaoActionBar chaoActionBar = getChaoActionBar();

		chaoActionBar.getTitleView().setVisibility(View.VISIBLE);
		chaoActionBar.setHomeIcon(R.drawable.arrow_left_circle);
		chaoActionBar.getHomeView().setPadding(
				AppUtil.dpToPx(10, getResources()), 0, 0, 0);
		chaoActionBar.setHomeVisibility(View.VISIBLE);

		chaoActionBar.getChaoSearchEditText().setVisibility(View.GONE);

		chaoActionBar.setSubmenuIcon(0);
		((Button) chaoActionBar.getSubMenuView()).setTextColor(getResources()
				.getColor(R.color.theme_font_black));
		((Button) chaoActionBar.getSubMenuView()).setTextSize(
				TypedValue.COMPLEX_UNIT_SP, 15);
		chaoActionBar.getSubMenuView().setBackgroundDrawable(null);
		chaoActionBar.setSubmenuText("保存");
		chaoActionBar.getSubMenuView().setVisibility(View.VISIBLE);

	}

	@Override
	protected void initData() {
		type = getIntent().getIntExtra(Constants.KEY_CHANGE_INFO_TYPE, 0);

		switch (type) {
		case 0:
			getChaoActionBar().setTitleText("更改昵称");
			break;
		case 1:
			getChaoActionBar().setTitleText("更改名字");
			break;
		case 2:
			getChaoActionBar().setTitleText("更改邮箱");
			break;
		case 3:
			getChaoActionBar().setTitleText("修改密码");
			break;
		default:
			break;
		}
	}

	@Override
	protected void addListener() {
		// TODO Auto-generated method stub

	}

}
