/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-5-3
 */
package com.chao.chaosearchapp.adapter;

import java.util.Date;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.SliderView;
import com.chao.chaosearchapp.listener.OnObjectClickListener;
import com.chao.chaosearchapp.model.MessageBO;
import com.chao.chaosearchapp.util.DateUtil;

/**
 * @author chaoking
 * 
 */
public class MessageListAdapter extends ChaoBaseAdapter<MessageBO> {

	private OnObjectClickListener<MessageBO> onDeleteClickListener;

	public void setOnDeleteClickListener(
			OnObjectClickListener<MessageBO> onDeleteClickListener) {
		this.onDeleteClickListener = onDeleteClickListener;
	}

	/**
	 * @param context
	 */
	public MessageListAdapter(Context context) {
		super(context);
	}

	@Override
	public View getView(int i, View view, ViewGroup viewGroup) {
		SliderView sliderView;
		final ViewHolder holder;
		if (view == null) {
			view = inflater.inflate(R.layout.item_list_message, null);
			sliderView = new SliderView(context);
			sliderView.setContentView(view);

			holder = new ViewHolder(sliderView);
			sliderView.setTag(holder);
		} else {
			sliderView = (SliderView) view;
			holder = (ViewHolder) sliderView.getTag();
		}

		sliderView.shrink();
		final MessageBO message = itemList.get(i);

		holder.itemTitle.setText(message.getTitle());
		holder.itemContent.setText(message.getContent());
		holder.itemTime.setText(DateUtil.longToString(message.getTime()));

		holder.deleteHolder.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (onDeleteClickListener != null) {
					onDeleteClickListener.OnClick(v, message);
				}
			}
		});
		return sliderView;
	}

	static class ViewHolder {
		TextView itemTitle;
		TextView itemContent;
		TextView itemTime;

		ViewGroup deleteHolder;

		public ViewHolder(View view) {
			itemTitle = (TextView) view
					.findViewById(R.id.item_list_message_title);
			itemContent = (TextView) view
					.findViewById(R.id.item_list_message_content);
			itemTime = (TextView) view
					.findViewById(R.id.item_list_message_time);
			deleteHolder = (ViewGroup) view.findViewById(R.id.holder);
		}
	}
}
