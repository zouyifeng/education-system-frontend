/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-24
 */
package com.chao.chaosearchapp.fragment;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.activity.AboutActivity;
import com.chao.chaosearchapp.activity.LoginActivity;
import com.chao.chaosearchapp.activity.UpdateActivity;
import com.chao.chaosearchapp.manager.AppManager;
import com.chao.chaosearchapp.manager.UserManager;
import com.chao.chaosearchapp.model.AppInfoBO;
import com.chao.chaosearchapp.util.PackageUtil;
import com.chao.chaosearchapp.util.TipDialogUtil;
import com.handmark.pulltorefresh.library.PullToRefreshScrollView;

/**
 * @author chaoking
 * 
 */
public class PersonalCenterFragment extends ChaoBaseFragment {
	@Override
	public View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.activity_personal_center,
				container, false);
		return view;
	}

	// 登陆后
	private View vLoginLayout, vUserName, vPhone, vSex, vAbout, vUpdate,
			vUpdateVersion, vContactService;

	// 登陆前
	private View vReleaseLayout, vLogin;

	// 退出登陆状态的组件
	private View btnReleaseBound, vReleaseBoundLine, vReleaseBoundLine2;

	private PullToRefreshScrollView refreshScrollView;

	/**
	 * 检测是否绑定及显示用户信息
	 */
	private void checkBindUserAndShowLayout() {
		Log.d("checkBindUserAndShowLayout", "UserManager.isBingAccount()"
				+ UserManager.isBingAccount());
		if (UserManager.isBingAccount()) {
			vReleaseLayout.setVisibility(View.GONE);
			vLoginLayout.setVisibility(View.VISIBLE);
			btnReleaseBound.setVisibility(View.VISIBLE);
			vReleaseBoundLine.setVisibility(View.VISIBLE);
			vReleaseBoundLine2.setVisibility(View.VISIBLE);

			((TextView) vUserName).setText(UserManager.getUserName("chaoking"));

			String phone = UserManager.getPhone("12345678901").substring(0, 3)
					+ "****"
					+ UserManager.getPhone("12345678901").substring(7, 11);
			((TextView) vPhone).setText(phone);
			((TextView) vSex).setText(UserManager.getSex("男"));
		} else {
			vLoginLayout.setVisibility(View.GONE);
			vReleaseLayout.setVisibility(View.VISIBLE);
			btnReleaseBound.setVisibility(View.GONE);
			vReleaseBoundLine.setVisibility(View.GONE);
			vReleaseBoundLine2.setVisibility(View.GONE);
		}
	}

	private void releaseBoundUser() {
		UserManager.clearBingAccountInfo();
		Intent i = mActivity.getPackageManager().getLaunchIntentForPackage(
				mActivity.getPackageName());
		i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(i);
		// overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
		android.os.Process.killProcess(android.os.Process.myPid());
	}

	@Override
	public void onResume() {
		checkBindUserAndShowLayout();
		super.onResume();
	}

	@Override
	protected void initViews(View view) {
		vLoginLayout = view.findViewById(R.id.personal_center_info_layout);
		vUserName = view.findViewById(R.id.personal_center_name);
		vPhone = view.findViewById(R.id.personal_center_phone);
		vSex = view.findViewById(R.id.personal_center_sex);
		vAbout = view.findViewById(R.id.personal_center_about);
		vContactService = view
				.findViewById(R.id.personal_center_contact_customer_service);
		vUpdate = view.findViewById(R.id.personal_center_update);
		vUpdateVersion = view.findViewById(R.id.personal_center_update_version);

		vReleaseLayout = view.findViewById(R.id.personal_center_empty_layout);
		vLogin = view.findViewById(R.id.personal_center_empty_img_head);

		btnReleaseBound = view.findViewById(R.id.personal_center_release_bound);
		vReleaseBoundLine = view
				.findViewById(R.id.personal_center_release_bound_line);
		vReleaseBoundLine2 = view
				.findViewById(R.id.personal_center_release_bound_line2);

		refreshScrollView = (PullToRefreshScrollView) view
				.findViewById(R.id.personal_center_scrollview);
	}

	@Override
	protected void initData() {
		// 这几个刷新Label的设置
		refreshScrollView.getLoadingLayoutProxy().setPullLabel(null);
		refreshScrollView.getLoadingLayoutProxy().setRefreshingLabel(null);
		refreshScrollView.getLoadingLayoutProxy().setReleaseLabel(null);
		refreshScrollView.getLoadingLayoutProxy().setLoadingDrawable(null);

		checkBindUserAndShowLayout();

		String version = PackageUtil.getVersionName(getActivity());
		if (version != null && !"".equals(version)) {
			((TextView) vUpdateVersion).setText(version);
		}
		AppInfoBO appInfo = AppManager.getAppInfo();
		version = PackageUtil.getVersionName(mActivity);
		String newVersion = appInfo != null ? appInfo.getVersion() : null;
		if (version != null && newVersion != null
				&& version.compareTo(newVersion) < 0) {// 检查是否已需要更新版本
			((TextView) vUpdateVersion).setText(newVersion);
			((TextView) vUpdateVersion).setTypeface(Typeface
					.defaultFromStyle(Typeface.BOLD));
			((TextView) vUpdateVersion).setTextColor(getResources().getColor(
					R.color.theme_font_red));
		} else {
			if (version != null && !"".equals(version)) {
				((TextView) vUpdateVersion).setText(version);
			}
		}

	}

	@Override
	protected void addListener() {
		vLogin.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mActivity, LoginActivity.class);
				startActivity(intent);
			}
		});

		btnReleaseBound.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				releaseBoundUser();
			}
		});

		vAbout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Log.d("", "chaoking-vAbout");
				Intent intent = new Intent(getActivity(), AboutActivity.class);
				getActivity().startActivity(intent);
			}
		});
		vContactService.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Log.d("", "chaoking-vContactService");
				// 是否拨打客服电话dialog
				TipDialogUtil.showContactService(mActivity);
			}
		});
		vUpdate.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Log.d("", "chaoking-vUpdate");
				// 检查更新
				Intent intent = new Intent(getActivity(), UpdateActivity.class);
				getActivity().startActivity(intent);
			}
		});
	}
}
