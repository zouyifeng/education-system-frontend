/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-3
 */
package com.chao.chaosearchapp.adapter;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.listener.OnObjectClickListener;
import com.chao.chaosearchapp.model.CommodityBO;
import com.chao.chaosearchapp.model.PriceBO;

/**
 * @author chaoking
 * 
 */
public class RecommendCommodityAdapter extends ChaoBaseAdapter<CommodityBO> {

	private OnObjectClickListener<CommodityBO> onCollectClickListener;

	public void setOnCollectClickListener(
			OnObjectClickListener<CommodityBO> listener) {
		this.onCollectClickListener = listener;
	}

	/**
	 * @param context
	 */
	public RecommendCommodityAdapter(Context context) {
		super(context);
		initImageLoader();
	}

	/**
	 * 初始化图片加载组件
	 */
	private void initImageLoader() {
		WindowManager wm = (WindowManager) context
				.getSystemService(Context.WINDOW_SERVICE);
		int width = wm.getDefaultDisplay().getWidth();
		mLoader.setIsUseMediaStoreThumbnails(false);
		mLoader.setRequiredSize(width / 3);
	}

	@Override
	public View getView(int i, View view, ViewGroup viewGroup) {
		ViewHolder holder;
		if (view == null) {
			view = inflater.inflate(R.layout.item_list_recommend_commodity,
					viewGroup, false);
			holder = new ViewHolder();
			holder.tvName = (TextView) view
					.findViewById(R.id.item_list_recommend_commodity_name);
			holder.imPic = (ImageView) view
					.findViewById(R.id.item_list_recommend_commodity_pic);
			holder.btnCollect = (Button) view
					.findViewById(R.id.item_list_recommend_commodity_collect);
			holder.tvPrice = (TextView) view
					.findViewById(R.id.item_list_recommend_commodity_price);
			view.setTag(holder);
		} else {
			holder = (ViewHolder) view.getTag();
		}

		final CommodityBO obj = (CommodityBO) getItem(i);

		holder.tvName.setText(obj.getName());

		if (obj.getPrices() != null && !obj.getPrices().isEmpty()) {
			PriceBO priceBO = obj.getPrices().get(0);
			holder.tvPrice.setText("¥"
					+ String.format("%.2f", priceBO.getEstimateAmount()));
		}

		if (obj.isCollected()) {
			holder.btnCollect.setSelected(true);
			holder.btnCollect.setText("已收藏");
		} else {
			holder.btnCollect.setSelected(false);
			holder.btnCollect.setText("收藏");
		}

		mLoader.DisplayImage(obj.getPic(), holder.imPic, R.drawable.ic_launcher);
		if (onCollectClickListener != null) {
			holder.btnCollect.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					onCollectClickListener.OnClick(v, obj);
				}
			});
		}

		return view;
	}

	static class ViewHolder {
		TextView tvName;
		TextView tvPrice;
		ImageView imPic;
		Button btnCollect;
	}
}
