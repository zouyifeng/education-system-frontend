/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-12
 */
package com.chao.chaosearchapp.api;

import java.util.List;

import com.chao.chaosearchapp.model.AdvertisementBO;
import com.chao.chaosearchapp.model.AppInfoBO;
import com.chao.chaosearchapp.model.BrandBO;
import com.chao.chaosearchapp.model.CommodityBO;
import com.chao.chaosearchapp.model.FeedbackBO;
import com.chao.chaosearchapp.model.HistoryKeywordBO;
import com.chao.chaosearchapp.model.PriceBO;
import com.chao.chaosearchapp.model.RecommendKeywordBO;
import com.chao.chaosearchapp.model.UserBO;

/**
 * @author chaoking
 * 
 */
public interface Api {
	// 发送验证码
	public final static String SEND_SMS_CODE = "sendSmsCode4Register";
	// 注册
	public final static String REGISTER = "/user/regist";

	// 登录
	public final static String LOGIN = "/user/login";
	// 商品列表
	public final static String LIST_COMMODITY = "/commodity/commodities";
	// 智能关键字推送
	public final static String LIST_RECOMMEND_KEYWORD = "/recommend/intelligent";
	// 历史搜索关键字列表
	public final static String LIST_HISTORY_SEARCH_KEYWORD = "/recommend/history";
	// 清除用户历史搜索关键字列表
	public final static String CLEAR_HISTORY_SEARCH_KEYWORD = "/searchHistory/searchHistorys";
	// 收藏商品
	public final static String COLLECT_COMMODITY = "/collections/collections";
	// 收藏列表
	public final static String LIST_COLLECTION = "/collections/collectionsPage";
	// 广告列表
	public final static String LIST_ADVERTISEMENT = "/advertisement/advertisement";
	// 品牌列表
	public final static String LIST_BRAND = "/advertisement/brand";
	// 得到版本信息
	public final static String VERSION_INFO = "/version/check";
	// 修改用户信息
	public final static String CHANGE_USER_INFO = "/user/user";
	// 修改用户密码
	public final static String CHANGE_USER_PASSWORD = "/user/user";
	// 向服务器发送反馈
	public final static String SEND_COMMENT = "/feedback/feedback";

	// 通过id获取广告
	public final static String ADVERTISEMENT_BY_ID = "/advertisement/getAdvertisement";
	// 通过id获取品牌
	public final static String BRAND_BY_ID = "/recommend/brand";
	// 通过id获取商品
	public final static String COMMODITY_BY_ID = "/commodity/commodity";
	// 通过id获取反馈
	public final static String FEEDBACK_BY_ID = "/feedback/getFeedback";

	// 通过id获取价格
	public final static String PRICE_BY_ID = "/price/price";

	// 获取推荐商品
	public final static String LIST_RECOMMEND_COMMODITY = "/commodity/getCommodities";

	/**
	 * 发送验证码
	 * 
	 * @param phoneNum
	 *            手机号码
	 * @return 成功时返回：{ "event": "0", "msg":"success" }
	 */
	public ApiResponse<Void> sendSmsCode4Register(String phoneNum);

	/**
	 * 注册
	 * 
	 * @param phoneNum
	 *            手机号码
	 * @param code
	 *            验证码
	 * @param password
	 *            MD5加密的密码
	 * @return 成功时返回：{ "event": "0", "msg":"success" }
	 */
	public ApiResponse<Void> registerByPhone(String phoneNum, String code,
			String password);

	/**
	 * 登录
	 * 
	 * @param loginName
	 *            登录名（手机号）
	 * @param password
	 *            MD5加密的密码
	 * @param imei
	 *            手机IMEI串号
	 * @param loginOS
	 *            Android为1
	 * @return 成功时返回：{ "event": "0", "msg":"success" }
	 */
	public ApiResponse<UserBO> loginByApp(String loginName, String password,
			String imei, int loginOS);

	/**
	 * @param pageNum
	 *            当前页数
	 * @param pageSize
	 *            每页显示数量
	 * @param name
	 *            名称关键字
	 * @param introduce
	 *            简介关键字
	 * @param userId
	 *            用户id
	 * @return 成功时返回：{ "event": "0", "msg":"success", "objList":[...] }
	 */
	public ApiResponse<List<CommodityBO>> listCommodity(int pageNum,
			int pageSize, String name, String introduce, String userId);

	/**
	 * @param pageNum
	 *            当前页数
	 * @param pageSize
	 *            每页显示数量
	 * @param userId
	 *            用户id
	 * @return 成功时返回：{ "event": "0", "msg":"success", "objList":[...] }
	 */
	public ApiResponse<List<CommodityBO>> listRecommendCommodity(int pageNum,
			int pageSize, String userId);

	/**
	 * 
	 * @param userId
	 * @return
	 */
	public ApiResponse<RecommendKeywordBO> getRecommendKeyword(String userId);

	/**
	 * 
	 * @param userId
	 * @return
	 */
	public ApiResponse<List<HistoryKeywordBO>> getHistorySearchKeyword(
			String userId);

	/**
	 * 
	 * @param userId
	 * @return
	 */
	public ApiResponse<Void> clearHistorySearchKeyword(String userId);

	/**
	 * @param pageNum
	 *            当前页数
	 * @param pageSize
	 *            每页显示数量
	 * @param userId
	 *            用户id
	 * @return 成功时返回：{ "event": "0", "msg":"success", "objList":[...] }
	 */
	public ApiResponse<List<CommodityBO>> listCollection(int pageNum,
			int pageSize, String userId);

	/**
	 * 
	 * @param userId
	 *            用户id
	 * @param typeId
	 *            类型id（商品id或价格id）
	 * @param type
	 *            类型（0代表商品，1代表价格）
	 * @return 成功时返回：{ "event": "0", "msg":"success" }
	 */
	public ApiResponse<Void> collectCommodity(String userId, int typeId,
			int type);

	/**
	 * 
	 * @param userId
	 *            用户id
	 * @param typeId
	 *            类型id（商品id或价格id）
	 * @param type
	 *            类型（0代表商品，1代表价格）
	 * @return 成功时返回：{ "event": "0", "msg":"success" }
	 */
	public ApiResponse<Void> cancelCollectCommodity(String userId, int typeId,
			int type);

	/**
	 * @param pageNum
	 *            当前页数
	 * @param pageSize
	 *            每页显示数量
	 * @param userId
	 *            用户id
	 * @return 成功时返回：{ "event": "0", "msg":"success", "objList":[...] }
	 */
	public ApiResponse<List<AdvertisementBO>> listAdvertisement(int placeNum);

	/**
	 * @param pageNum
	 *            当前页数
	 * @param pageSize
	 *            每页显示数量
	 * @param userId
	 *            用户id
	 * @return 成功时返回：{ "event": "0", "msg":"success", "objList":[...] }
	 */
	public ApiResponse<List<BrandBO>> listBrand(int placeNum);

	/**
	 * 
	 * @param version
	 * @return
	 */
	public ApiResponse<AppInfoBO> getVersionInfo(String imei, String version);

	/**
	 * 
	 * @param version
	 * @return
	 */
	public ApiResponse<Void> changeUserInfo(UserBO user, int loginOS);

	/**
	 * 
	 * @param version
	 * @return
	 */
	public ApiResponse<Void> changeUserPassword(String userId, String password,
			int loginOS);

	/**
	 * 
	 * @param userId
	 * @param title
	 * @param comment
	 * @return 成功时返回：{ "event": "0", "msg":"success" }
	 */
	public ApiResponse<Void> sendComment(String userId, String title,
			String comment);

	/**
	 * 
	 * @param id
	 * @return
	 */
	public ApiResponse<AdvertisementBO> getAdvertisement(int id);

	/**
	 * 
	 * @param id
	 * @return
	 */
	public ApiResponse<BrandBO> getBrand(int id);

	/**
	 * 
	 * @param id
	 * @return
	 */
	public ApiResponse<CommodityBO> getCommodity(String userId, int id);

	/**
	 * 
	 * @param id
	 * @return
	 */
	public ApiResponse<PriceBO> getPrice(String userId, int id);

	/**
	 * 
	 * @param id
	 * @return
	 */
	public ApiResponse<FeedbackBO> getFeedback(int id);
}
