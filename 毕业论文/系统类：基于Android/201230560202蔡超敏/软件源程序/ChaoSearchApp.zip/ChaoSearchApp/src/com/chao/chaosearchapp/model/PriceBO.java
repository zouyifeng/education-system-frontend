/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-12
 */
package com.chao.chaosearchapp.model;

import java.io.Serializable;

/**
 * @author chaoking
 * 
 */
public class PriceBO implements Serializable {

	private static final long serialVersionUID = 6553569995017187171L;

	private int id; // 商品价格id
	private int modelType; // 商品类型，1为现金商品，2为抵扣商品，3为折扣商品
	private double faceValue; // 现金商品的面值
	private double estimateAmount; // 现金商品的售价
	private String url; // 商品的地址

	private int isCollected; // 是否被收藏,0没有，1有

	private StoreBO store; // 商店

	public boolean isCollected() {
		return isCollected == 1;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the modelType
	 */
	public int getModelType() {
		return modelType;
	}

	/**
	 * @param modelType
	 *            the modelType to set
	 */
	public void setModelType(int modelType) {
		this.modelType = modelType;
	}

	/**
	 * @return the faceValue
	 */
	public double getFaceValue() {
		return faceValue;
	}

	/**
	 * @param faceValue
	 *            the faceValue to set
	 */
	public void setFaceValue(double faceValue) {
		this.faceValue = faceValue;
	}

	/**
	 * @return the estimateAmount
	 */
	public double getEstimateAmount() {
		return estimateAmount;
	}

	/**
	 * @param estimateAmount
	 *            the estimateAmount to set
	 */
	public void setEstimateAmount(double estimateAmount) {
		this.estimateAmount = estimateAmount;
	}

	/**
	 * @return the store
	 */
	public StoreBO getStore() {
		return store;
	}

	/**
	 * @param store
	 *            the store to set
	 */
	public void setStore(StoreBO store) {
		this.store = store;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url
	 *            the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the isCollected
	 */
	public int getIsCollected() {
		return isCollected;
	}

	/**
	 * @param isCollected
	 *            the isCollected to set
	 */
	public void setIsCollected(int isCollected) {
		this.isCollected = isCollected;
	}

	@Override
	public boolean equals(Object o) {
		if (getId() == ((PriceBO) o).getId())
			return true;

		return super.equals(o);
	}

}
