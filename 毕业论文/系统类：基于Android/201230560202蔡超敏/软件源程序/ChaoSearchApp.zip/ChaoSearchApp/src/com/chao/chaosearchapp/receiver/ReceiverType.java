/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-29
 */
package com.chao.chaosearchapp.receiver;

import java.lang.reflect.Type;

import com.chao.chaosearchapp.api.ApiResponse;
import com.chao.chaosearchapp.model.AdvertisementBO;
import com.chao.chaosearchapp.model.AppInfoBO;
import com.chao.chaosearchapp.model.BrandBO;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * @author chaoking
 * 
 */
public enum ReceiverType {

	/**
	 * 空
	 */
	NULL(0, new TypeToken<ApiResponse<Void>>() {
	}.getType()),
	/**
	 * 版本
	 */
	VERSION(1, new TypeToken<ApiResponse<AppInfoBO>>() {
	}.getType()),
	/**
	 * 品牌
	 */
	BRAND(2, new TypeToken<ApiResponse<BrandBO>>() {
	}.getType()),
	/**
	 * 广告
	 */
	ADVERTISEMENT(3, new TypeToken<ApiResponse<AdvertisementBO>>() {
	}.getType());

	private ReceiverType(int typeId, Type objType) {
		this.typeId = typeId;
		this.objType = objType;
	}

	private ReceiverType(int typeId, Type objType, Object obj) {
		this.typeId = typeId;
		this.objType = objType;

	}

	private int typeId;
	private Type objType;

	/**
	 * @return the typeId
	 */
	public int getTypeId() {
		return typeId;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}

	/**
	 * @return the objType
	 */
	public Type getObjType() {
		return objType;
	}

	/**
	 * @param objType
	 *            the objType to set
	 */
	public void setObjType(Type objType) {
		this.objType = objType;
	}

	@Override
	public String toString() {
		return super.toString() + "(" + typeId + "," + objType + ")";
	}

	public static ReceiverType getReceiverType(int typeId) {
		switch (typeId) {
		case 1:
			return ReceiverType.VERSION;
		case 2:
			return ReceiverType.BRAND;
		case 3:
			return ReceiverType.ADVERTISEMENT;
		default:
			return ReceiverType.NULL;
		}
	}

	public <T> T getApiResponse(String json) {
		Gson gson = new Gson();
		return gson.fromJson(json, this.objType);

	}
}
