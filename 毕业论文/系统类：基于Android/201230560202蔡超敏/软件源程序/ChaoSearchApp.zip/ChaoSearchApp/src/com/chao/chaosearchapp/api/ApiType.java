/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-31
 */
package com.chao.chaosearchapp.api;

/**
 * @author chaoking
 * 
 */
public enum ApiType {
	/**
	 * 登录
	 */
	LOGIN(1, "/user/login"),
	/**
	 * 商品列表
	 */
	LIST_COMMODITY(2, "/commodity/commodities"),
	/**
	 * 智能关键字推送
	 */
	LIST_RECOMMEND_KEYWORD(3, "/recommend/intelligent"),
	/**
	 * 历史搜索关键字列表
	 */
	LIST_HISTORY_SEARCH_KEYWORD(4, "/recommend/history"),
	/**
	 * 收藏商品
	 */
	COLLECT_COMMODITY(5, ""),
	/**
	 * 收藏列表
	 */
	LIST_COLLECTION(6, ""),
	/**
	 * 广告列表
	 */
	LIST_ADVERTISEMENT(7, "/recommend/history");

	private ApiType(int type, String subpath) {
		this.type = type;
		this.subpath = subpath;
	}

	private int type;
	private String subpath;

	/**
	 * @return the type
	 */
	public int getType() {
		return type;
	}

	/**
	 * @return the subpath
	 */
	public String getSubpath() {
		return subpath;
	}

	@Override
	public String toString() {
		return super.toString() + "(" + type + "," + subpath + ")";
	}
}
