/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-8
 */
package com.chao.chaosearchapp.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.VideoView;

import cn.jpush.android.api.JPushInterface;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.manager.AppManager;
import com.chao.chaosearchapp.manager.UserManager;
import com.chao.chaosearchapp.model.AppInfoBO;
import com.chao.chaosearchapp.model.HistoryKeywordBO;
import com.chao.chaosearchapp.util.PackageUtil;

/**
 * 启动画面
 * 
 * @author chaoking
 * 
 */
public class ChaoStartActivity extends ChaoBaseActivity {

	boolean isFirstIn = false;

	private static final int GO_HOME = 1000;
	private static final int GO_GUIDE = 1001;
	// 延迟3秒
	private static final long SPLASH_DELAY_MILLIS = 1500;

	protected static final String TAG = "ChaoStartActivity";

	// 提示组件
	private TextView mTextView;

	// 新加的播放控件
	private VideoView videoView;

	// 更新版本
	private String newVersion = "";

	private String apkFile = Constants.APK_SAVE_PATH + "update" + newVersion
			+ ".apk";

	private int progress; // 下载进度
	private static final int DOWNLOADING = 1; // 表示正在下载
	private static final int DOWNLOADED = 2; // 下载完毕
	private static final int DOWNLOAD_FAILED = 3; // 下载失败

	/**
	 * Handler:跳转到不同界面
	 */
	private Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case GO_HOME:
				goHome();
				break;
			case GO_GUIDE:
				goGuide();
				break;
			case DOWNLOADING:
				mTextView.setText(Html.fromHtml("<font color='red'>正在升级中( "
						+ progress + "/100 )...</font>"));
				break;
			case DOWNLOADED:
				File tFile = (File) msg.obj;
				installAPK(tFile);
				break;
			case DOWNLOAD_FAILED:
				mTextView.setText("升级失败!点击重新下载");
				mTextView.setEnabled(true);
				break;
			default:
				break;
			}
			super.handleMessage(msg);
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_chao_start);
	}

	/**
	 * 播放动画
	 */
	private void toShowVideo() {
		/* 设定VideoView */
		videoView = (VideoView) findViewById(R.id.start_view_video);
		// 资源传入路径格式： android.resource://[package name]/R.raw.start
		Uri uri = Uri.parse("android.resource://com.chao.chaosearchapp/"
				+ R.raw.start);
		videoView.setVideoURI(uri);
		videoView.requestFocus();
		/* 开始播放影片 */
		videoView.start();

		/* 影片播放完后会运行的OnCompletionListener */
		videoView
				.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
					@Override
					public void onCompletion(MediaPlayer arg0) {
						// init();
					}
				});
	}

	/**
	 * 
	 * method desc：设置已经引导过了，下次启动不用再次引导
	 */
	private void setGuided() {
		AppManager.setFirstInAppFlag(false);
	}

	private void goHome() {
		Intent intent = new Intent(this, ChaoMainActivity.class);
		startActivity(intent);
		finish();
	}

	private void goGuide() {
		Intent intent = new Intent(this, GuideActivity.class);
		startActivity(intent);
		finish();
	}

	@Override
	protected void initViews() {
		mTextView = (TextView) findViewById(R.id.appStartTip);
		mTextView.setEnabled(false);
		// toShowVideo();
	}

	@Override
	protected void initData() {
		checkVersion();
	}

	/**
	 * 判断程序与第几次运行，如果是第一次运行则跳转到引导界面，否则跳转到主界面
	 */
	private void checkIsFirstInApp() {
		if (!AppManager.isFirstInAppFlag()) {
			InitAppData();
		} else {
			setGuided();
			mHandler.sendEmptyMessageDelayed(GO_GUIDE, SPLASH_DELAY_MILLIS);
		}
	}

	/**
	 * 检查更新问题
	 */
	private void checkVersion() {
		String version = PackageUtil.getVersionName(this);
		appAction.getVersionInfo(version,
				new ActionCallbackListener<AppInfoBO>() {

					@Override
					public void onSuccess(AppInfoBO data) {
						analysisAppInfo(data);
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						makeToast(message);
						checkIsFirstInApp();
					}
				});
	}

	/**
	 * 处理版本信息
	 * 
	 * @param data
	 */
	private void analysisAppInfo(AppInfoBO appInfo) {
		if (appInfo == null) {
			checkIsFirstInApp();
			return;
		}
		Log.d("", "chaoking-appInfo" + appInfo.getVersion());
		AppManager.putAppInfo(appInfo);
		newVersion = appInfo.getVersion();
		if (appInfo.isForce()) {
			// 如果是强制更新,则自动下载，不进行提示
			mTextView.setText("商品搜索正在升级中...");
			downloadAPK(appInfo.getClientURL());
			return;
		}
		if (PackageUtil.getVersionName(this).compareTo(appInfo.getVersion()) < 0) {// 非强制更新提示
			showUpdateDialog(appInfo);
		} else {// 无更新提示
			checkIsFirstInApp();
		}
	}

	/**
	 * 提醒更新版本
	 * 
	 * @param appInfo
	 */
	private void showUpdateDialog(final AppInfoBO appInfo) {
		AlertDialog.Builder builder = new Builder(this);

		apkFile = "update" + newVersion + ".apk";
		Log.d("UpdateActivity", Constants.APK_SAVE_PATH + apkFile);
		final File apk = new File(Constants.APK_SAVE_PATH + apkFile);
		if (apkFile == null || !apk.exists()) {
			builder.setTitle("发现新版本 ：" + appInfo.getVersion());
			builder.setMessage(appInfo.getClientDesc());
			builder.setPositiveButton("现在更新",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							mTextView.setText("商品搜索正在升级中...");
							downloadAPK(appInfo.getClientURL());
						}
					});
			builder.setNegativeButton("待会更新",
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface arg0, int arg1) {
							arg0.dismiss();
							checkIsFirstInApp();
							// updateAppResource(appInfo);
						}
					});

			builder.create().setCancelable(false);
			builder.create().setCanceledOnTouchOutside(false);
			builder.show();
		} else {
			builder.setTitle("发现新版本安装包 ：" + appInfo.getVersion());
			builder.setMessage(appInfo.getClientDesc());
			builder.setPositiveButton("现在安装",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							installAPK(apk);
						}
					});
			builder.setNegativeButton("待会安装",
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface arg0, int arg1) {
							arg0.dismiss();
							checkIsFirstInApp();
							// updateAppResource(appInfo);
						}
					});
			builder.create().setCancelable(true);
			builder.show();
		}
	}

	/**
	 * 初始化app信息
	 */
	private void InitAppData() {
		if (UserManager.isBingAccount()) {
			appAction
					.getHistorySearchKeyword(new ActionCallbackListener<List<HistoryKeywordBO>>() {

						@Override
						public void onSuccess(List<HistoryKeywordBO> data) {
							if (data != null) {
								ArrayList<String> keywords = new ArrayList<String>();
								for (Iterator<HistoryKeywordBO> iterator = data
										.iterator(); iterator.hasNext();) {
									HistoryKeywordBO historyKeywordBO = iterator
											.next();
									keywords.add(historyKeywordBO
											.getSearchValue());
								}
								UserManager.setHistorySearchKeywords(keywords);
							}
							mHandler.sendEmptyMessage(GO_HOME);
						}

						@Override
						public void onFailure(String errorEvent, String message) {
							makeToast(message);
							mHandler.sendEmptyMessage(GO_HOME);
						}
					});
		} else {
			mHandler.sendEmptyMessage(GO_HOME);
		}
	}

	@Override
	protected void addListener() {

		mTextView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				AppInfoBO appInfo = AppManager.getAppInfo();
				if (appInfo != null && !"".equals(appInfo.getClientURL())) {
					mTextView.setEnabled(false);
					downloadAPK(appInfo.getClientURL());
					return;
				} else {
					if (appInfo != null)
						makeToast("更新失败,地址  =" + appInfo.getClientURL());
					checkVersion();
				}
			}
		});
	}

	@Override
	protected int setChaoActionBarId() {
		// TODO Auto-generated method stub
		return 0;
	}

	private void downloadAPK(final String apkUrl) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					URL url = new URL(apkUrl);
					HttpURLConnection conn = (HttpURLConnection) url
							.openConnection();
					conn.connect();

					int length = conn.getContentLength();
					InputStream is = conn.getInputStream();

					File file = new File(Constants.APK_SAVE_PATH);
					if (!file.exists()) {
						file.mkdir();
					}
					apkFile = Constants.APK_SAVE_PATH + "update" + newVersion
							+ ".apk";

					File ApkFile = new File(apkFile);
					Log.d(TAG, ApkFile.getAbsolutePath());
					FileOutputStream fos = new FileOutputStream(ApkFile);

					int count = 0;
					byte buf[] = new byte[1024];

					do {
						int numread = is.read(buf);
						count += numread;
						progress = (int) (((float) count / length) * 100);
						// 更新进度
						mHandler.sendEmptyMessage(DOWNLOADING);
						if (numread <= 0) {
							// 下载完成通知安装
							Message message = mHandler.obtainMessage();
							message.what = DOWNLOADED;
							message.obj = ApkFile;
							mHandler.sendMessage(message);
							break;
						}
						fos.write(buf, 0, numread);
					} while (true); // 点击取消就停止下载.这里可以设置开关

					fos.close();
					is.close();
				} catch (Exception e) {
					mHandler.sendEmptyMessage(DOWNLOAD_FAILED);
					e.printStackTrace();
				}
			}
		}).start();
	}

	// 安装apk
	private void installAPK(File apkFile) {
		if (apkFile == null || !apkFile.exists()) {
			makeToast("找不到更新文件");
			checkIsFirstInApp();
			return;
		}
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setDataAndType(Uri.parse("file://" + apkFile.toString()),
				"application/vnd.android.package-archive");
		startActivity(intent);
		android.os.Process.killProcess(android.os.Process.myPid());
	}

	@Override
	protected void onResume() {
		JPushInterface.onResume(this);
		super.onResume();
	}

	@Override
	protected void onPause() {
		JPushInterface.onPause(this);
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		apkFile = "update" + newVersion + ".apk";
		File apk = new File(Constants.APK_SAVE_PATH + apkFile);
		if (apk.exists()) {
			apk.delete();
		}
		super.onDestroy();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.chao.chaosearchapp.activity.ChaoBaseActivity#setNetworkTip(boolean,
	 * java.lang.String)
	 */
	@Override
	public void setNetworkTip() {
		// TODO Auto-generated method stub

	}
}
