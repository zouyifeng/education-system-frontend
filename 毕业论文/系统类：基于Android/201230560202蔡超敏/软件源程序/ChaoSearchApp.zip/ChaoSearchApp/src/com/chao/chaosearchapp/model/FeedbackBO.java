/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-26
 */
package com.chao.chaosearchapp.model;

import java.io.Serializable;
import java.util.Date;

/**
 * 反馈对象
 * 
 * @author chaoking
 * 
 */
public class FeedbackBO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1834179512381999160L;

	private Integer id;

	private Integer userId;

	private String title;

	private String comment;

	private String commentDate;

	private Integer feedbackUserId;

	private String feedbackComment;

	private String feedbackDate;

	private Integer schedule;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the userId
	 */
	public Integer getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title
	 *            the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment
	 *            the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the commentDate
	 */
	public String getCommentDate() {
		return commentDate;
	}

	/**
	 * @param commentDate
	 *            the commentDate to set
	 */
	public void setCommentDate(String commentDate) {
		this.commentDate = commentDate;
	}

	/**
	 * @return the feedbackUserId
	 */
	public Integer getFeedbackUserId() {
		return feedbackUserId;
	}

	/**
	 * @param feedbackUserId
	 *            the feedbackUserId to set
	 */
	public void setFeedbackUserId(Integer feedbackUserId) {
		this.feedbackUserId = feedbackUserId;
	}

	/**
	 * @return the feedbackComment
	 */
	public String getFeedbackComment() {
		return feedbackComment;
	}

	/**
	 * @param feedbackComment
	 *            the feedbackComment to set
	 */
	public void setFeedbackComment(String feedbackComment) {
		this.feedbackComment = feedbackComment;
	}

	/**
	 * @return the feedbackDate
	 */
	public String getFeedbackDate() {
		return feedbackDate;
	}

	/**
	 * @param feedbackDate
	 *            the feedbackDate to set
	 */
	public void setFeedbackDate(String feedbackDate) {
		this.feedbackDate = feedbackDate;
	}

	/**
	 * @return the schedule
	 */
	public Integer getSchedule() {
		return schedule;
	}

	/**
	 * @param schedule
	 *            the schedule to set
	 */
	public void setSchedule(Integer schedule) {
		this.schedule = schedule;
	}

}
