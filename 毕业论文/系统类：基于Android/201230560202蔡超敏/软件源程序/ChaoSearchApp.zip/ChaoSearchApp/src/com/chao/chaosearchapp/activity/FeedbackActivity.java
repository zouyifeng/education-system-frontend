/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-26
 */
package com.chao.chaosearchapp.activity;

import android.support.v4.app.Fragment;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.ChaoActionBar;
import com.chao.chaosearchapp.fragment.FeedbackFragment;
import com.chao.chaosearchapp.util.AppUtil;

/**
 * @author chaoking
 * 
 */
public class FeedbackActivity extends SingleFragmentActivity {
	@Override
	protected Fragment createFragment() {
		return new FeedbackFragment();
	}

	@Override
	protected void initViews() {
		ChaoActionBar chaoActionBar = getChaoActionBar();
		chaoActionBar.setTitleText("意见反馈");
		chaoActionBar.getTitleView().setVisibility(View.VISIBLE);
		chaoActionBar.setHomeIcon(R.drawable.arrow_left_circle);
		chaoActionBar.getHomeView().setPadding(
				AppUtil.dpToPx(10, getResources()), 0, 0, 0);
		chaoActionBar.setHomeVisibility(View.VISIBLE);

		chaoActionBar.getChaoSearchEditText().setVisibility(View.GONE);

		chaoActionBar.setSubmenuIcon(0);
		((Button) chaoActionBar.getSubMenuView()).setTextColor(getResources()
				.getColor(R.color.theme_font_black));
		((Button) chaoActionBar.getSubMenuView()).setTextSize(
				TypedValue.COMPLEX_UNIT_SP, 15);
		chaoActionBar.getSubMenuView().setBackgroundDrawable(null);
		chaoActionBar.setSubmenuText("提交");
		chaoActionBar.getSubMenuView().setVisibility(View.VISIBLE);
	}

	@Override
	protected void initData() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void addListener() {
		// TODO Auto-generated method stub

	}
}
