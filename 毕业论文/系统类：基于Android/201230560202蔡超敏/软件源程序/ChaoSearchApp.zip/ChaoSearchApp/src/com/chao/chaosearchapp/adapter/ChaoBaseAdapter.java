/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-12
 */
package com.chao.chaosearchapp.adapter;

import java.util.ArrayList;
import java.util.List;

import com.chao.chaosearchapp.util.imageLoader.ImageLoader;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

/**
 * Adapter抽象基类
 * 
 * @author chaoking
 * 
 */
public abstract class ChaoBaseAdapter<T> extends BaseAdapter {

	protected Context context;
	protected LayoutInflater inflater;
	protected List<T> itemList = new ArrayList<T>();
	

	/**
	 * 必须最好调用initImageLoader初始化才用
	 */
	protected ImageLoader mLoader;

	public ChaoBaseAdapter(Context context) {
		this.context = context;
		inflater = LayoutInflater.from(context);
		mLoader=new ImageLoader(context);
	}

	/**
	 * 判断数据是否为空
	 * 
	 * @return 为空返回true，不为空返回false
	 */
	public boolean isEmpty() {
		return itemList.isEmpty();
	}

	/**
	 * 在原有的数据上添加新数据
	 * 
	 * @param itemList
	 */
	public void addItems(List<T> itemList) {
		this.itemList.addAll(itemList);
		notifyDataSetChanged();
	}

	/**
	 * 在原有的数据上添加新数据
	 * 
	 * @param itemList
	 */
	public void addItem(int i, T item) {
		this.itemList.add(i, item);
		notifyDataSetChanged();
	}

	/**
	 * 在原有的数据上添加新数据
	 * 
	 * @param itemList
	 */
	public void addItem(T item) {
		this.itemList.add(item);
		notifyDataSetChanged();
	}

	/**
	 * 设置为新的数据，旧数据会被清空
	 * 
	 * @param itemList
	 */
	public void setItems(List<T> itemList) {
		this.itemList.clear();
		this.itemList = itemList;
		notifyDataSetChanged();
	}

	/**
	 * 清空数据
	 */
	public void clearItems() {
		itemList.clear();
		notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return itemList.size();
	}

	@Override
	public Object getItem(int i) {
		return itemList.get(i);
	}

	@Override
	public long getItemId(int i) {
		return i;
	}

	/**
	 * 
	 * 返回数据集
	 * 
	 * @return List<T>
	 */
	public List<T> getItems() {
		return itemList;
	}

	@Override
	abstract public View getView(int i, View view, ViewGroup viewGroup);
}
