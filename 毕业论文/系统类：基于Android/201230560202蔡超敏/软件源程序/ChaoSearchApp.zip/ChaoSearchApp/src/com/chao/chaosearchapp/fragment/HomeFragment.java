/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-24
 */
package com.chao.chaosearchapp.fragment;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.format.DateUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.activity.BrowserActivity;
import com.chao.chaosearchapp.activity.CommodityActivity;
import com.chao.chaosearchapp.activity.HistoryKeywordSearchActivity;
import com.chao.chaosearchapp.adapter.RecommendBrandAdapter;
import com.chao.chaosearchapp.adapter.RecommendCommodityAdapter;
import com.chao.chaosearchapp.adapter.RecommendationPagerAdapter;
import com.chao.chaosearchapp.assembly.HorizontalListView;
import com.chao.chaosearchapp.assembly.PageIndicatorView;
import com.chao.chaosearchapp.assembly.ScrollRecommendationViewPager;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.listener.OnObjectClickListener;
import com.chao.chaosearchapp.model.AdvertisementBO;
import com.chao.chaosearchapp.model.BrandBO;
import com.chao.chaosearchapp.model.CommodityBO;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.Mode;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2;
import com.handmark.pulltorefresh.library.PullToRefreshScrollView;

/**
 * @author chaoking
 * 
 */
public class HomeFragment extends ChaoBaseFragment {

	private List<AdvertisementBO> advertisements;
	private ScrollRecommendationViewPager advertisementPager;// 广告轮播器
	private RecommendationPagerAdapter advertisementPagerAdapter;// 广告适配器
	private PageIndicatorView circleIndicator;// 小圆点指示器

	private PullToRefreshScrollView refreshScrollView;

	// 推荐品牌
	private HorizontalListView recommendBrandListView;
	private RecommendBrandAdapter recommendBrandAdapter;

	// 推荐商品
	private GridView gridView;
	private RecommendCommodityAdapter recommendCommodityAdapter;

	// 更新时间view
	private TextView tvLastUpdate;

	private int pageNum = 1;
	private int pageSize = 10;

	@Override
	public View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_home, container, false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		advertisementPager = (ScrollRecommendationViewPager) view
				.findViewById(R.id.home_view_pager);
		circleIndicator = (PageIndicatorView) view
				.findViewById(R.id.home_circle_indicator);

		refreshScrollView = (PullToRefreshScrollView) view
				.findViewById(R.id.home_scrollview);

		// 推荐品牌
		recommendBrandListView = (HorizontalListView) view
				.findViewById(R.id.home_horizontal_list_brand);

		// 推荐商品
		gridView = (GridView) view
				.findViewById(R.id.home_grid_recommend_commodity);

		tvLastUpdate = (TextView) view
				.findViewById(R.id.home_grid_recommend_commodity_title);

	}

	@Override
	protected void initData() {
		// 这几个刷新Label的设置
		// refreshScrollView.getLoadingLayoutProxy().setPullLabel(null);
		// refreshScrollView.getLoadingLayoutProxy().setRefreshingLabel(null);
		// refreshScrollView.getLoadingLayoutProxy().setReleaseLabel(null);
		// refreshScrollView.getLoadingLayoutProxy().setLoadingDrawable(null);
		refreshScrollView.setMode(Mode.BOTH);

		// 广告列表
		advertisements = new ArrayList<AdvertisementBO>();

		advertisementPagerAdapter = new RecommendationPagerAdapter(mActivity,
				advertisements);
		advertisementPagerAdapter.setCircleIndicator(circleIndicator);
		advertisementPager.setAdapter(advertisementPagerAdapter);

		advertisementPager.startAutoScroll();

		// 获取广告列表
		mActivity.appAction.listAdvertisement(5,
				new ActionCallbackListener<List<AdvertisementBO>>() {

					@Override
					public void onSuccess(List<AdvertisementBO> data) {
						advertisements.clear();
						advertisements.addAll(data);
						advertisementPagerAdapter.notifyDataSetChanged();
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						makeToast(message);
					}
				});

		// 推荐品牌
		recommendBrandAdapter = new RecommendBrandAdapter(mActivity);
		recommendBrandListView.setAdapter(recommendBrandAdapter);

		// 获取推荐品牌列表
		mActivity.appAction.listBrand(10,
				new ActionCallbackListener<List<BrandBO>>() {

					@Override
					public void onSuccess(List<BrandBO> data) {
						if (data != null) {
							recommendBrandAdapter.setItems(data);
						}
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						makeToast(message);
					}
				});

		// 推荐商品
		recommendCommodityAdapter = new RecommendCommodityAdapter(mActivity);
		gridView.setAdapter(recommendCommodityAdapter);
		pullDownToRefresh();

	}

	@Override
	protected void addListener() {
		mActivity.getChaoActionBar().getChaoSearchEditText()
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Log.d("addListener-onFocusChange", "onClick");
						goToHistoryKeywordSearchActivity();
					}
				});

		advertisementPager.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageScrollStateChanged(int arg0) {

			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {

			}

			@Override
			public void onPageSelected(int arg0) {

				circleIndicator.setCurrentPage(arg0);
			}

		});

		advertisementPagerAdapter
				.setOnAdvertisementClickListener(new OnObjectClickListener<AdvertisementBO>() {

					@Override
					public void OnClick(View view, AdvertisementBO obj) {
						if (obj != null && obj.getLink() != null) {
							String link = obj.getLink();
							if (Patterns.WEB_URL.matcher(link).matches()) {
								// makeToast("链接符合标准"+obj.getUrl());
								// 符合标准
								Intent webIntent = new Intent(mActivity,
										BrowserActivity.class);
								webIntent.putExtra(Constants.KEY_BROWSER_LINK,
										link);
								webIntent.putExtra(Constants.KEY_BROWSER_TITLE,
										obj.getTitle());
								webIntent.putExtra(Constants.KEY_BROWSER_TYPE,
										1);
								webIntent
										.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
								startActivity(webIntent);
							} else {
								// 不符合标准
								makeToast("链接不符合标准" + obj.getLink());
							}
						}
					}
				});
		gridView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// Intent webIntent = new Intent(mActivity,
				// BrowserActivity.class);
				// webIntent.putExtra(Constants.KEY_BROWSER_LINK,
				// ((CommodityBO) gridView.getAdapter().getItem(position))
				// .getPic());
				// // webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				// startActivity(webIntent);
				CommodityBO commodityBO = (CommodityBO) gridView.getAdapter()
						.getItem(position);
				Intent intent = new Intent(mActivity, CommodityActivity.class);
				intent.putExtra(Constants.KEY_COMMODITY_TYPE, 1);
				intent.putExtra(Constants.KEY_COMMODITY_ID, commodityBO.getId());
				intent.putExtra(Constants.KEY_COMMODITY_TITLE,
						commodityBO.getName());
				intent.putExtra(Constants.KEY_COMMODITY_COMMODITYBO,
						commodityBO);
				// intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intent);
			}
		});

		recommendCommodityAdapter
				.setOnCollectClickListener(new OnObjectClickListener<CommodityBO>() {

					@Override
					public void OnClick(final View view, final CommodityBO obj) {
						if (view.isSelected()) {
							mActivity.appAction.cancelCollectCommodity(
									obj.getId(), 1,
									new ActionCallbackListener<Void>() {

										@Override
										public void onSuccess(Void data) {
											view.setSelected(false);
											((Button) view).setText("收藏");
											makeToast("已取消收藏" + obj.getName());
											obj.setIsCollected(0);
										}

										@Override
										public void onFailure(
												String errorEvent,
												String message) {
											makeToast(message);
										}
									});

						} else {
							mActivity.appAction.collectCommodity(obj.getId(),
									1, new ActionCallbackListener<Void>() {

										@Override
										public void onSuccess(Void data) {
											view.setSelected(true);
											((Button) view).setText("已收藏");
											makeToast("已收藏" + obj.getName());
											obj.setIsCollected(1);
										}

										@Override
										public void onFailure(
												String errorEvent,
												String message) {
											makeToast(message);
										}
									});
						}
					}
				});

		refreshScrollView.setOnRefreshListener(new OnRefreshListener2() {

			@Override
			public void onPullDownToRefresh(PullToRefreshBase refreshView) {
				pullDownToRefresh();
			}

			@Override
			public void onPullUpToRefresh(PullToRefreshBase refreshView) {
				pullUpToRefresh();
			}
		});
		recommendBrandListView
				.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						Intent webIntent = new Intent(mActivity,
								BrowserActivity.class);
						webIntent.putExtra(Constants.KEY_BROWSER_LINK,
								((BrandBO) recommendBrandListView.getAdapter()
										.getItem(position)).getLink());
						// webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						startActivity(webIntent);
					}
				});
	}

	/**
	 * 更新ui数据
	 */
	private void refreshData() {

		// 获取广告列表
		mActivity.appAction.listAdvertisement(5,
				new ActionCallbackListener<List<AdvertisementBO>>() {

					@Override
					public void onSuccess(List<AdvertisementBO> data) {
						advertisements.clear();
						advertisements.addAll(data);
						advertisementPagerAdapter.notifyDataSetChanged();
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						// TODO Auto-generated method stub

					}
				});

		// 获取推荐品牌列表
		mActivity.appAction.listBrand(10,
				new ActionCallbackListener<List<BrandBO>>() {

					@Override
					public void onSuccess(List<BrandBO> data) {
						if (data != null) {
							recommendBrandAdapter.setItems(data);
						}
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						makeToast(message);
					}
				});
	}

	/**
	 * 向上更新
	 */
	protected void pullUpToRefresh() {
		mActivity.appAction.listRecommendCommodity(pageNum, pageSize,
				new ActionCallbackListener<List<CommodityBO>>() {

					@Override
					public void onSuccess(List<CommodityBO> data) {
						if (data == null || data.isEmpty())
							return;
						recommendCommodityAdapter.addItems(data);
						pageNum++;
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						// TODO Auto-generated method stub

					}
				});
		refreshScrollView.onRefreshComplete();
	}

	/**
	 * 向下更新
	 */
	protected void pullDownToRefresh() {
		// 获取推荐商品列表
		pageNum = 1;
		mActivity.appAction.listRecommendCommodity(pageNum, pageSize,
				new ActionCallbackListener<List<CommodityBO>>() {

					@Override
					public void onSuccess(List<CommodityBO> data) {
						if (data != null && !data.isEmpty()) {
							recommendCommodityAdapter.setItems(data);
							pageNum = 2;
						} else {
							makeToast("没有更多数据了");
						}
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						// TODO Auto-generated method stub

					}
				});
		refreshScrollView.onRefreshComplete();
		resetLastUpdateLabel();

		refreshData();
	}

	/**
	 * 更新最后一次更新数据的时间组件
	 */
	private void resetLastUpdateLabel() {
		String label = DateUtils.formatDateTime(mActivity,
				System.currentTimeMillis(), DateUtils.FORMAT_SHOW_TIME);
		tvLastUpdate.setText(label + "为你推荐已更新");
	}

	/**
	 * 跳转界面
	 */
	private void goToHistoryKeywordSearchActivity() {
		Intent intent = new Intent(getActivity(),
				HistoryKeywordSearchActivity.class);
		getActivity().startActivity(intent);
	}

	@Override
	public void onResume() {
		super.onResume();
		if (refreshScrollView != null)
			refreshScrollView.scrollTo(0, 0);
	}
}