/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-31
 */
package com.chao.chaosearchapp.activity;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.ChaoActionBar;
import com.chao.chaosearchapp.assembly.ChaoActionBar.ChaoActionBarCallBack;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.fragment.BrowserFragment;
import com.chao.chaosearchapp.model.AdvertisementBO;
import com.chao.chaosearchapp.model.BrandBO;
import com.chao.chaosearchapp.model.PriceBO;
import com.chao.chaosearchapp.util.AppUtil;

/**
 * @author chaoking
 * 
 */
public class BrowserActivity extends SingleFragmentActivity {

	private int type = -1;

	private BrowserFragment browserFragment;
	// type=0
	private PriceBO priceBO;

	@Override
	protected Fragment createFragment() {
		browserFragment = new BrowserFragment();
		return browserFragment;
	}

	@Override
	protected void initViews() {
		ChaoActionBar chaoActionBar = getChaoActionBar();

		chaoActionBar.getTitleView().setVisibility(View.VISIBLE);
		chaoActionBar.setHomeIcon(R.drawable.arrow_left_circle);
		chaoActionBar.getHomeView().setPadding(
				AppUtil.dpToPx(10, getResources()), 0, 0, 0);
		chaoActionBar.setHomeVisibility(View.VISIBLE);

		chaoActionBar.setSubMenuVisibility(View.GONE);

		chaoActionBar.getChaoSearchEditText().setVisibility(View.GONE);
	}

	@Override
	protected void initData() {
		type = getIntent().getIntExtra(Constants.KEY_BROWSER_TYPE, -1);
		switch (this.type) {
		case 0:
			priceBO = (PriceBO) getIntent().getSerializableExtra(
					Constants.KEY_BROWSER_PRICEBO);

			if (priceBO.isCollected()) {
				getChaoActionBar().setSubmenuIcon(
						R.drawable.collect_star_selected);
			} else {
				getChaoActionBar().setSubmenuIcon(
						R.drawable.collect_star_unselected);
			}
			getChaoActionBar().setSubMenuVisibility(View.VISIBLE);
			getChaoActionBar().getSubMenuView().setPadding(0, 0,
					AppUtil.dpToPx(5, getResources()), 0);

			// int pid = getIntent().getIntExtra(Constants.KEY_BROWSER_ID, 0);
			appAction.getPrice(priceBO.getId(),
					new ActionCallbackListener<PriceBO>() {

						@Override
						public void onSuccess(PriceBO data) {
							if (data == null)
								return;
							priceBO = data;
							getIntent().putExtra(Constants.KEY_BROWSER_PRICEBO,
									priceBO);
							if (priceBO.isCollected()) {
								getChaoActionBar().setSubmenuIcon(
										R.drawable.collect_star_selected);
							} else {
								getChaoActionBar().setSubmenuIcon(
										R.drawable.collect_star_unselected);
							}
						}

						@Override
						public void onFailure(String errorEvent, String message) {
							makeToast(message);
						}
					});
			break;
		case 1:

			break;
		case 2:

			break;
		case 11:
			int id = getIntent().getIntExtra(Constants.KEY_BROWSER_ID, 0);
			appAction.getAdvertisement(id,
					new ActionCallbackListener<AdvertisementBO>() {

						@Override
						public void onSuccess(AdvertisementBO data) {
							if (data != null) {
								getIntent().putExtra(
										Constants.KEY_BROWSER_LINK,
										data.getLink());
								browserFragment.openBrowser(data.getLink());
							}
							// makeToast(data.getLink());
						}

						@Override
						public void onFailure(String errorEvent, String message) {
							makeToast(message);
						}
					});
			break;
		case 12:
			int id2 = getIntent().getIntExtra(Constants.KEY_BROWSER_ID, 0);
			appAction.getBrand(id2, new ActionCallbackListener<BrandBO>() {

				@Override
				public void onSuccess(BrandBO data) {
					if (data != null) {
						getIntent().putExtra(Constants.KEY_BROWSER_LINK,
								data.getLink());
						browserFragment.openBrowser(data.getLink());
					}
				}

				@Override
				public void onFailure(String errorEvent, String message) {
					makeToast(message);
				}
			});
			break;
		default:
			break;
		}

		String title = getIntent().getStringExtra(Constants.KEY_BROWSER_TITLE);
		getChaoActionBar().setTitleText(title);

	}

	@Override
	protected void addListener() {
		// TODO Auto-generated method stub
	}

	@Override
	protected ChaoActionBarCallBack addChaoActionBarCallBack() {
		return new ChaoActionBarCallBack() {

			@Override
			public void onSubmenuClickCallBack(Button submenubtn) {
				// makeToast("是否收藏" + priceBO.isCollected());
				if (priceBO != null && priceBO.isCollected()) {
					appAction.cancelCollectCommodity(priceBO.getId(), 2,
							new ActionCallbackListener<Void>() {

								@Override
								public void onSuccess(Void data) {
									makeToast("已取消收藏");
									priceBO.setIsCollected(0);
									getChaoActionBar().setSubmenuIcon(
											R.drawable.collect_star_unselected);
								}

								@Override
								public void onFailure(String errorEvent,
										String message) {
									makeToast(message);
								}
							});
				} else {
					appAction.collectCommodity(priceBO.getId(), 2,
							new ActionCallbackListener<Void>() {

								@Override
								public void onSuccess(Void data) {
									makeToast("已收藏");
									priceBO.setIsCollected(1);
									getChaoActionBar().setSubmenuIcon(
											R.drawable.collect_star_selected);
								}

								@Override
								public void onFailure(String errorEvent,
										String message) {
									makeToast(message);
								}
							});
				}
			}

			@Override
			public void onHomeClickCallBack(Button homebtn) {
				finish();
			}
		};
	}

	/**
	 * 返回activity类型
	 * 
	 * @return
	 */
	public int getType() {
		return type;
	}

	@Override
	public void finish() {
		if (priceBO != null && type == 0) {
			Intent intent = new Intent();
			intent.putExtra(Constants.KEY_BROWSER_PRICEBO, priceBO);
			setResult(0, intent);
		}
		super.finish();
	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		if (browserFragment != null)
			browserFragment.dispatchTouchEvent(ev);
		return super.dispatchTouchEvent(ev);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (browserFragment != null) {
			if (!browserFragment.onKeyDown(keyCode, event)) {
				return super.onKeyDown(keyCode, event);
			} else
				return true;
		} else
			return super.onKeyDown(keyCode, event);
	}

}
