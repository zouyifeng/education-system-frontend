/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-5-2
 */
package com.chao.chaosearchapp.model;

import java.io.Serializable;

import android.view.View.OnClickListener;

/**
 * @author chaoking
 * 
 */
public class NetworkTipBO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -326617072807851023L;

	private boolean isShow = false;
	private String tip;
	private OnClickListener clickListener;

	/**
	 * @return the isShow
	 */
	public boolean isShow() {
		return isShow;
	}

	/**
	 * @param isShow
	 *            the isShow to set
	 */
	public void setShow(boolean isShow) {
		this.isShow = isShow;
	}

	/**
	 * @return the tip
	 */
	public String getTip() {
		return tip;
	}

	/**
	 * @param tip
	 *            the tip to set
	 */
	public void setTip(String tip) {
		this.tip = tip;
	}

	/**
	 * @return the clickListener
	 */
	public OnClickListener getClickListener() {
		return clickListener;
	}

	/**
	 * @param clickListener
	 *            the clickListener to set
	 */
	public void setClickListener(OnClickListener clickListener) {
		this.clickListener = clickListener;
	}

}
