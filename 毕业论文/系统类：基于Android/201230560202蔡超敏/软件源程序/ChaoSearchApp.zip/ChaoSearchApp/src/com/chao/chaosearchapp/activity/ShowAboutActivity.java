/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-5-4
 */
package com.chao.chaosearchapp.activity;

import android.support.v4.app.Fragment;
import android.view.View;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.ChaoActionBar;
import com.chao.chaosearchapp.fragment.ShowAboutFragment;
import com.chao.chaosearchapp.util.AppUtil;

/**
 * @author chaoking
 * 
 */
public class ShowAboutActivity extends SingleFragmentActivity {

	@Override
	protected Fragment createFragment() {
		return new ShowAboutFragment();
	}

	@Override
	protected void initViews() {
		ChaoActionBar chaoActionBar = getChaoActionBar();

		int type = getIntent().getIntExtra(Constants.KEY_SHOWUS_ID, 1);
		if (type == 1) {
			chaoActionBar.setTitleText("功能介绍");
		} else {
			chaoActionBar.setTitleText("关于我们");
		}
		chaoActionBar.getTitleView().setVisibility(View.VISIBLE);
		chaoActionBar.setHomeIcon(R.drawable.arrow_left_circle);
		chaoActionBar.getHomeView().setPadding(
				AppUtil.dpToPx(10, getResources()), 0, 0, 0);
		chaoActionBar.setHomeVisibility(View.VISIBLE);

		chaoActionBar.setSubMenuVisibility(View.GONE);

		chaoActionBar.getChaoSearchEditText().setVisibility(View.GONE);
	}

	@Override
	protected void initData() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void addListener() {
		// TODO Auto-generated method stub

	}

}