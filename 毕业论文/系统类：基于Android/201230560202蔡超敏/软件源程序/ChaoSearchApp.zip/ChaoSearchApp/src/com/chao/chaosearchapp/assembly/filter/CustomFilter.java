/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-11
 */
package com.chao.chaosearchapp.assembly.filter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.text.InputFilter;
import android.text.Spanned;

/**
 * 
 * 过滤字符串 最大长度maxLen,默认为20,字符串长度（半角算1、全角算2） 非法字符illegalRegex
 * 可以设置onFullAndillegalListener来获得是否达到最长或含有非法字符
 * 
 * @author chaoking
 * 
 */
public class CustomFilter implements InputFilter {
	private int maxLen = 20;
	private String illegalRegex;
	private onFullAndillegalListener listener;

	public CustomFilter(int maxLen) {
		this.maxLen = maxLen;
	}

	public CustomFilter(int maxLen, String illegalRegex) {
		this.maxLen = maxLen;
		this.illegalRegex = illegalRegex;
	}

	/**
	 * CharSequence source, //输入的文字 int start, //开始位置 int end, //结束位置 Spanned
	 * dest, //当前显示的内容 int dstart, //当前开始位置 int dend //当前结束位置
	 */
	@Override
	public CharSequence filter(CharSequence source, int start, int end,
			Spanned dest, int dstart, int dend) {
		if (!isNull(illegalRegex) && !isViald(source)) {// 如果不合法
			if (null != listener) {
				listener.isIllegal();
			}
			return "";
		}
		int mlength = getLength(dest.subSequence(dstart, dend).toString());// 修改字符串的长度
		int dlength = getLength(dest.toString());// 已有字符串的长度
		int slength = getLength(source.subSequence(start, end).toString());// 要增加的字符串的长度
		int keep = this.maxLen - (dlength - mlength);// 还差多少字符到最大长度
		if (null != listener) {
			listener.onChange(keep);
		}
		if (keep <= 0) {// 已经到达最大长度
			if (null != listener) {
				listener.isFull();
			}
			return "";
		} else if (keep >= slength) {// 还没到达最大长度
			return null;
		} else {// 超出最大长度
			int tmp = 0;
			int index;
			for (index = start; index <= end; index++) {
				if (isFullwidthCharacter(source.charAt(index))) {
					tmp += 2;
				} else {
					tmp += 1;
				}
				if (tmp > keep) {
					break;
				}
			}
			if (null != listener) {
				listener.isFull();
			}
			return source.subSequence(start, index);
		}
	}

	/**
	 * 以illegalRegex过滤字符串，如含有illegalRegex字符则返回false，反之true
	 * 
	 * @param source
	 * @return boolean
	 */
	private boolean isViald(CharSequence source) {
		Pattern p = Pattern.compile("[" + illegalRegex + "]");
		Matcher m = p.matcher(source);
		if (m.find()) {
			return false;
		}
		return true;
	}

	/**
	 * 超出长度时调用事件
	 * 
	 * @param listener
	 */
	public void setOnFullAndillegalListener(onFullAndillegalListener listener) {
		this.listener = listener;
	}

	/**
	 * 超出长度时调用事件
	 * 
	 * @author chaoking
	 * 
	 */
	public interface onFullAndillegalListener {
		/**
		 * 这个方法会在输入字符串超出极限时被调用
		 */
		void isFull();

		/**
		 * 这个方法会在输入非法字符时被调用
		 */
		void isIllegal();

		/**
		 * 这个方法会在输入时反馈剩下大小
		 */
		void onChange(int num);
	}

	/**
	 * 判断字符串是否为空或空串
	 * 
	 * @param str
	 * @return true
	 */
	public static boolean isNull(final String str) {
		if (null == str || "".equals(str)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 获取字符串长度（半角算1、全角算2）
	 * 
	 * @param str
	 * @return 字符串长度
	 */
	public static int getLength(final String str) {
		if (isNull(str)) {
			return 0;
		}
		int len = str.length();
		for (int i = 0; i < str.length(); i++) {
			if (isFullwidthCharacter(str.charAt(i))) {
				len = len + 1;
			}
		}
		return len;
	}

	/**
	 * 获取字符串的全角字符数
	 * 
	 * @param str
	 * @return 字符串的全角字符数
	 */
	public static int getFwCharNum(final String str) {
		if (isNull(str)) {
			return 0;
		}
		int num = 0;
		for (int i = 0; i < str.length(); i++) {
			if (isFullwidthCharacter(str.charAt(i))) {
				num++;
			}
		}
		return num;
	}

	/**
	 * 判断字符是否为全角字符
	 * 
	 * @param ch
	 * @return true：全角； false：半角
	 */
	public static boolean isFullwidthCharacter(final char ch) {
		if (ch >= 32 && ch <= 127) {// 基本拉丁字母（即键盘上可见的，空格、数字、字母、符号）
			return false;
		} else if (ch >= 65377 && ch <= 65439) {// 日文半角片假名和符号
			return false;
		} else {
			return true;
		}
	}
}