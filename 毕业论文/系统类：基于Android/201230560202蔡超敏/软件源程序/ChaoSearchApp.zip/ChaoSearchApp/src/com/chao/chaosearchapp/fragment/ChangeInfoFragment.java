/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-11
 */
package com.chao.chaosearchapp.fragment;

import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.ChaoActionBar.ChaoActionBarCallBack;
import com.chao.chaosearchapp.assembly.filter.CustomFilter;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.manager.UserManager;
import com.chao.chaosearchapp.model.UserBO;

/**
 * @author chaoking
 * 
 */
public class ChangeInfoFragment extends ChaoBaseFragment {

	private ViewHolder viewHolder;
	private int type;

	@Override
	protected View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_change_info, container,
				false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		viewHolder = new ViewHolder(view);
	}

	@Override
	protected void initData() {
		type = mActivity.getIntent().getIntExtra(
				Constants.KEY_CHANGE_INFO_TYPE, 0);
		switch (type) {
		case 0:
			viewHolder.evName.setVisibility(View.VISIBLE);
			viewHolder.tvName.setVisibility(View.VISIBLE);
			viewHolder.tvName.setText("好名字可以让大家对你印象深刻");
			viewHolder.evName.setText(UserManager.getUserName(""));
			viewHolder.evName.setFilters(new InputFilter[] { new CustomFilter(
					16, "<>/") });
			viewHolder.evName
					.setSelection(UserManager.getUserName("").length());
			viewHolder.evName.setInputType(InputType.TYPE_CLASS_TEXT
					| InputType.TYPE_TEXT_VARIATION_PERSON_NAME);
			break;
		case 1:
			viewHolder.evName.setVisibility(View.VISIBLE);
			viewHolder.tvName.setVisibility(View.VISIBLE);
			viewHolder.tvName.setText("正经地输入你的名字");
			viewHolder.evName.setText(UserManager.getRealName(""));
			viewHolder.evName.setFilters(new InputFilter[] { new CustomFilter(
					10, "<>/") });
			viewHolder.evName
					.setSelection(UserManager.getRealName("").length());
			viewHolder.evName.setInputType(InputType.TYPE_CLASS_TEXT
					| InputType.TYPE_TEXT_VARIATION_PERSON_NAME);
			break;
		case 2:
			viewHolder.evName.setVisibility(View.VISIBLE);
			viewHolder.tvName.setVisibility(View.VISIBLE);
			viewHolder.tvName.setText("我们可以通过你的邮箱来推送你感兴趣的信息");
			viewHolder.evName.setText(UserManager.getEmail(""));
			viewHolder.evName.setFilters(new InputFilter[] { new CustomFilter(
					30, "<>/") });
			viewHolder.evName.setSelection(UserManager.getEmail("").length());
			viewHolder.evName.setInputType(InputType.TYPE_CLASS_TEXT
					| InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
			break;
		case 3:
			viewHolder.evName.setVisibility(View.VISIBLE);
			viewHolder.tvName.setVisibility(View.VISIBLE);
			viewHolder.tvName.setText("好的密码可以提高你账号的安全性");
			viewHolder.evName.setText("");
			viewHolder.evName.setFilters(new InputFilter[] { new CustomFilter(
					30) });
			viewHolder.evName.setInputType(InputType.TYPE_CLASS_TEXT
					| InputType.TYPE_TEXT_VARIATION_PASSWORD);
			break;
		default:
			break;
		}
	}

	@Override
	protected void addListener() {
		mActivity.getChaoActionBar().addChaoActionBarCallBack(
				new ChaoActionBarCallBack() {

					@Override
					public void onSubmenuClickCallBack(Button submenubtn) {
						updateInfo();
					}

					@Override
					public void onHomeClickCallBack(Button homebtn) {
						mActivity.finish();
					}
				});

	}

	/**
	 * 检测并更新用户信息
	 */
	private void updateInfo() {
		UserBO user = new UserBO();
		user.setId(Integer.parseInt(UserManager.getUserId("0")));
		switch (type) {
		case 0:
			user.setName(viewHolder.evName.getText().toString());
			mActivity.appAction.changeUserInfo(user,
					new ActionCallbackListener<Void>() {

						@Override
						public void onSuccess(Void data) {
							makeToast("保存成功");
							UserManager.setUserName(viewHolder.evName.getText()
									.toString());

							mActivity.finish();
						}

						@Override
						public void onFailure(String errorEvent, String message) {
							makeToast(message);
						}
					});
			break;
		case 1:
			user.setRealName(viewHolder.evName.getText().toString());
			mActivity.appAction.changeUserInfo(user,
					new ActionCallbackListener<Void>() {

						@Override
						public void onSuccess(Void data) {
							makeToast("保存成功");
							UserManager.setRealName(viewHolder.evName.getText()
									.toString());

							mActivity.finish();
						}

						@Override
						public void onFailure(String errorEvent, String message) {
							makeToast(message);
						}
					});
			break;
		case 2:
			user.setEmail(viewHolder.evName.getText().toString());
			mActivity.appAction.changeUserInfo(user,
					new ActionCallbackListener<Void>() {

						@Override
						public void onSuccess(Void data) {
							makeToast("保存成功");
							UserManager.setEmail(viewHolder.evName.getText()
									.toString());

							mActivity.finish();
						}

						@Override
						public void onFailure(String errorEvent, String message) {
							makeToast(message);
						}
					});
			break;
		case 3:
			mActivity.appAction.changeUserPassword(viewHolder.evName.getText()
					.toString(), new ActionCallbackListener<Void>() {

				@Override
				public void onSuccess(Void data) {
					makeToast("修改成功");

					mActivity.finish();
				}

				@Override
				public void onFailure(String errorEvent, String message) {
					makeToast(message);
				}
			});
			break;
		default:
			break;
		}
	}

	static class ViewHolder {
		public ViewHolder(View view) {
			evName = (EditText) view.findViewById(R.id.edit_name);

			tvName = (TextView) view.findViewById(R.id.edit_name_tip);

		}

		EditText evName;

		TextView tvName;
	}

}
