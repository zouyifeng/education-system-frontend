/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-9
 */
package com.chao.chaosearchapp.model;

import java.io.Serializable;

/**
 * @author chaoking
 * 
 */
public class HistoryKeywordBO implements Serializable {

	private static final long serialVersionUID = 7769784923726602822L;

	private int id; // 历史记录
	private int userId; // 用户id
	private String searchValue; // 搜索关键字
	private String searchTime; // 搜索时间
	private int type; // 记录是否有效标识，1有效，0表示无效

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the userId
	 */
	public int getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}

	/**
	 * @return the searchValue
	 */
	public String getSearchValue() {
		return searchValue;
	}

	/**
	 * @param searchValue
	 *            the searchValue to set
	 */
	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	/**
	 * @return the searchTime
	 */
	public String getSearchTime() {
		return searchTime;
	}

	/**
	 * @param searchTime
	 *            the searchTime to set
	 */
	public void setSearchTime(String searchTime) {
		this.searchTime = searchTime;
	}

	/**
	 * @return the type
	 */
	public int getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(int type) {
		this.type = type;
	}

}
