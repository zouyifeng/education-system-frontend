/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-11
 */
package com.chao.chaosearchapp.fragment;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.ChaoWheelView;
import com.chao.chaosearchapp.assembly.ChaoWheelView.OnWheelChangedListener;
import com.chao.chaosearchapp.assembly.ChaoWheelView.OnWheelScrollListener;
import com.chao.chaosearchapp.assembly.ChaoWheelView.WheelAdapter;

/**
 * 
 * 选择时间DialogFragment 调用需要实现onSelectedDateListener接口获取Date
 * 
 * @author chaoking
 * 
 */
public class TimePickerFragment extends DialogFragment {
	private boolean timeChanged = false;
	private boolean timeScrolled = false;

	private ChaoWheelView years;
	private ChaoWheelView months;
	private ChaoWheelView days;

	private int mYear;
	private int mMonth;
	private int mDay;

	private DateFormat formatDay = new SimpleDateFormat("yyyy-MM-dd");

	private onSelectedDateListener onSelectedDateListener;

	public void setOnSelectedDateListener(
			onSelectedDateListener selectedDateListener) {
		this.onSelectedDateListener = selectedDateListener;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_time_picker, container);
		initView(view);
		return view;
	}

	@Override
	public void show(FragmentManager manager, String tag) {
		setStyle(DialogFragment.STYLE_NO_TITLE, R.style.AppTheme_DialogStyle);
		super.show(manager, tag);
	}

	private Date convertString2Date(String strDate) throws ParseException {
		return (strDate == null || "".equals(strDate)) ? new Date() : formatDay
				.parse(strDate);
	}

	private String checkDoubleString(int value) {
		return value < 10 ? ("0" + value) : ("" + value);
	}

	private String settingDateStr;

	/**
	 * 格式为yyyy-MM-dd
	 * 
	 * @param dateStr
	 * @return
	 */
	public boolean setDate(String dateStr) {
		if (years != null) {
			settingDateStr = dateStr;
			int year, month, day;
			try {
				String[] str = dateStr.split("-");
				year = Integer.parseInt(str[0]);
				month = Integer.parseInt(str[1]);
				day = Integer.parseInt(str[2]);
				return setDate(year, month, day);
			} catch (Exception e) {
				return false;
			}
		} else {
			settingDateStr = dateStr;
			return true;
		}
	}

	/**
	 * year 1970~至今 month 1~12 day 1~31
	 * 
	 * @param year
	 * @param month
	 * @param day
	 * @return
	 */
	public boolean setDate(int year, int month, int day) {
		Calendar c = Calendar.getInstance();
		int nowYears = c.get(Calendar.YEAR);
		if (year >= 1970 && year <= nowYears && month >= 1 && month <= 12
				&& day >= 1 && day <= 31) {
			mYear = year - 1970;
			mMonth = month - 1;
			mDay = day - 1;
			years.setCurrentItem(mYear);
			months.setCurrentItem(mMonth);
			days.setCurrentItem(mDay);
			return true;
		} else {
			return false;
		}
	}

	public void initView(View view) {
		Calendar c = Calendar.getInstance();
		mYear = c.get(Calendar.YEAR);
		mMonth = c.get(Calendar.MONTH);
		mDay = c.get(Calendar.DAY_OF_MONTH);
		Log.e("initView---mDay", String.valueOf(mDay));

		years = (ChaoWheelView) view.findViewById(R.id.year);
		years.setAdapter(new NumericWheelAdapter(1970, mYear, "%d"));

		months = (ChaoWheelView) view.findViewById(R.id.month);
		months.setAdapter(new NumericWheelAdapter(1, 12, "%02d"));

		days = (ChaoWheelView) view.findViewById(R.id.date);
		days.setAdapter(new NumericWheelAdapter(1, 31, "%02d"));
		mYear = mYear - 1970;

		// years.setCurrentItem(mYear);
		// months.setCurrentItem(mMonth);
		// days.setCurrentItem(mDay);
		setDate(settingDateStr);

		// TODO add listeners
		addChangingListener(years, "年");
		addChangingListener(months, "月");
		addChangingListener(days, "日");

		years.addChangingListener(wheelListener);
		months.addChangingListener(wheelListener);
		days.addChangingListener(wheelListener);

		years.addScrollingListener(scrollListener);
		months.addScrollingListener(scrollListener);
		days.addScrollingListener(scrollListener);

		// 点击事件
		((Button) view.findViewById(R.id.btn_confirm))
				.setOnClickListener(confirmClickListener);
		((Button) view.findViewById(R.id.btn_cancel))
				.setOnClickListener(cancelsClickListener);
	}

	// 确定点击事件
	private OnClickListener confirmClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			String strDate;
			Date reserveDate;
			mYear = mYear + 1970;
			mMonth++;
			mDay++;
			strDate = (mYear) + "-" + (mMonth) + "-" + mDay;
			try {
				reserveDate = convertString2Date(strDate);
				onSelectedDateListener.onGetDate(strDate, reserveDate);
				dismiss();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	};

	// 取消点击事件
	private OnClickListener cancelsClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			dismiss();
		}
	};

	OnWheelChangedListener wheelListener = new OnWheelChangedListener() {
		public void onChanged(ChaoWheelView wheel, int oldValue, int newValue) {
			if (!timeScrolled) {
				timeChanged = true;
				mYear = years.getCurrentItem();
				mMonth = months.getCurrentItem();
				mDay = days.getCurrentItem();
				timeChanged = false;
			}
		}
	};

	OnWheelScrollListener scrollListener = new OnWheelScrollListener() {
		public void onScrollingStarted(ChaoWheelView wheel) {
			timeScrolled = true;
			Log.e("onScrollingStarted", "onScrollingStarted");
		}

		public void onScrollingFinished(ChaoWheelView wheel) {
			timeScrolled = false;
			timeChanged = true;
			mYear = years.getCurrentItem();
			mMonth = months.getCurrentItem();
			mDay = days.getCurrentItem();
			timeChanged = false;
			Log.e("onScrollingFinished", "onScrollingFinished");
		}
	};

	/**
	 * Adds changing listener for wheel that updates the wheel label
	 */
	private void addChangingListener(final ChaoWheelView wheel,
			final String label) {
		wheel.addChangingListener(new OnWheelChangedListener() {
			public void onChanged(ChaoWheelView wheel, int oldValue,
					int newValue) {
				wheel.setLabel(newValue != 1 ? label + "" : label);
			}
		});
	}

	/**
	 * Numeric Wheel adapter.
	 */
	public class NumericWheelAdapter implements WheelAdapter {

		/** The default min value */
		public static final int DEFAULT_MAX_VALUE = 9;

		/** The default max value */
		private static final int DEFAULT_MIN_VALUE = 0;

		// Values
		private int minValue;
		private int maxValue;

		// format
		private String format;

		/**
		 * Default constructor
		 */
		public NumericWheelAdapter() {
			this(DEFAULT_MIN_VALUE, DEFAULT_MAX_VALUE);
		}

		/**
		 * Constructor
		 * 
		 * @param minValue
		 *            the wheel min value
		 * @param maxValue
		 *            the wheel max value
		 */
		public NumericWheelAdapter(int minValue, int maxValue) {
			this(minValue, maxValue, null);
		}

		/**
		 * Constructor
		 * 
		 * @param minValue
		 *            the wheel min value
		 * @param maxValue
		 *            the wheel max value
		 * @param format
		 *            the format string
		 */
		public NumericWheelAdapter(int minValue, int maxValue, String format) {
			this.minValue = minValue;
			this.maxValue = maxValue;
			this.format = format;
		}

		@Override
		public String getItem(int index) {
			if (index >= 0 && index < getItemsCount()) {
				int value = minValue + index;
				return format != null ? String.format(format, value) : Integer
						.toString(value);
			}
			return null;
		}

		@Override
		public int getItemsCount() {
			return maxValue - minValue + 1;
		}

		@Override
		public int getMaximumLength() {
			int max = Math.max(Math.abs(maxValue), Math.abs(minValue));
			int maxLen = Integer.toString(max).length();
			if (minValue < 0) {
				maxLen++;
			}
			return maxLen;
		}
	}

	// 调用接口
	public interface onSelectedDateListener {
		public void onGetDate(String dateStr, Date Date);
	}
}