/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-29
 */
package com.chao.chaosearchapp;

/**
 * @author chaoking
 * 
 */
public class Constants {

	// 客服电话
	public static final String APK_SAVE_PATH = "/sdcard/searchapp/";
	// 客服电话
	public static final String CUSTOMER_SERVICE_PHONE = "13560419126";
	// 传给browserActivity的链接的key
	public static final String KEY_BROWSER_LINK = "KEY_BROWSER_LINK";
	// 传给browserActivity的标题的key
	public static final String KEY_BROWSER_TITLE = "KEY_BROWSER_TITLE";
	/**
	 * 传给browserActivity的类型的key</br> 商品：0 广告：1 品牌：2 </br> 需要从服务器获取数据 </br> 商品：10
	 * 广告：11 品牌：12
	 */
	public static final String KEY_BROWSER_TYPE = "KEY_BROWSER_TYPE";
	/**
	 * 传给browserActivity的类型的ID
	 */
	public static final String KEY_BROWSER_ID = "KEY_BROWSER_ID";
	/**
	 * 传给browserActivity的商品价格类
	 */
	public static final String KEY_BROWSER_PRICEBO = "KEY_BROWSER_PRICEBO";
	/**
	 * 传给browserActivity的类型的ID
	 */
	public static final String KEY_COMMODITY_ID = "KEY_COMMODITY_ID";
	// 传给CommodityActivity的标题的key
	public static final String KEY_COMMODITY_TITLE = "KEY_COMMODITY_TITLE";
	/**
	 * 传给CommodityActivity的type是否获取商品 1:是 0:否
	 */
	public static final String KEY_COMMODITY_TYPE = "KEY_COMMODITY_TYPE";
	/**
	 * 传给CommodityActivity的商品类
	 */
	public static final String KEY_COMMODITY_COMMODITYBO = "KEY_COMMODITY_COMMODITYBO";
	// 搜索关键字的key
	public final static String KEY_SEARCH_KEYWORD = "KEY_SEARCH_KEYWORD";

	/**
	 * 传给ChangeInfoActivity的类型的key</br> 昵称：0 真名：1
	 */
	public static final String KEY_CHANGE_INFO_TYPE = "KEY_CHANGE_INFO_TYPE";

	/**
	 * 传给UpdateActivity的type是否获取商品 1:是 0:否
	 */
	public static final String KEY_UPDATE_TYPE = "KEY_UPDATE_TYPE";

	/**
	 * 传给ShowUsActivity的类型的ID
	 */
	public static final String KEY_SHOWUS_ID = "KEY_SHOWUS_ID";
}
