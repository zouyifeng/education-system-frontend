/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-31
 */
package com.chao.chaosearchapp.listener;

/**
 * @author chaoking
 *
 */
public interface OnLinkClickListener {
	
	public void onLinkClick(String link);

}
