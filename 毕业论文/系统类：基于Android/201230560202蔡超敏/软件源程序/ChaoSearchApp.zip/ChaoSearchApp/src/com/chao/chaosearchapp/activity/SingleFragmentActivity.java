/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-25
 */
package com.chao.chaosearchapp.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import com.chao.chaosearchapp.ChaoSearchApplication;
import com.chao.chaosearchapp.R;

/**
 * @author chaoking
 * 
 */
public abstract class SingleFragmentActivity extends ChaoBaseActivity {
	private TextView networkTip;

	abstract protected Fragment createFragment();

	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		getWindow().requestFeature(Window.FEATURE_PROGRESS);
		setContentView(R.layout.activity_single_fragment);
		FragmentManager fm = getSupportFragmentManager();
		Fragment mFragment = fm.findFragmentById(R.id.container);
		if (mFragment == null) {
			mFragment = createFragment();
			fm.beginTransaction().add(R.id.container, mFragment).commit();
		}
		networkTip = (TextView) findViewById(R.id.network_tip);
	}

	@Override
	public void setNetworkTip() {
		super.setNetworkTip();
		if (ChaoSearchApplication.networkTip.isShow()) {
			networkTip.setText(ChaoSearchApplication.networkTip.getTip());
			networkTip.setOnClickListener(ChaoSearchApplication.networkTip
					.getClickListener());
			networkTip.setVisibility(View.VISIBLE);
		} else {
			networkTip.setText(ChaoSearchApplication.networkTip.getTip());
			networkTip.setVisibility(View.GONE);
		}
	}

	@Override
	protected int setChaoActionBarId() {
		return R.id.chao_action_bar;
	}
}
