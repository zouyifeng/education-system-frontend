/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-29
 */
package com.chao.chaosearchapp.fragment;

import java.util.Iterator;
import java.util.List;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.activity.BrowserActivity;
import com.chao.chaosearchapp.activity.CommodityActivity;
import com.chao.chaosearchapp.activity.HistoryKeywordSearchActivity;
import com.chao.chaosearchapp.activity.LoginActivity;
import com.chao.chaosearchapp.adapter.CollectionListAdapter;
import com.chao.chaosearchapp.assembly.ChaoCustomDialog;
import com.chao.chaosearchapp.assembly.PullToRefreshSliderListView;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.listener.OnObjectClickListener;
import com.chao.chaosearchapp.manager.UserManager;
import com.chao.chaosearchapp.model.CommodityBO;
import com.chao.chaosearchapp.model.PriceBO;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.Mode;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2;

/**
 * @author chaoking
 * 
 */
public class CollectionFragment extends ChaoBaseFragment {

	private PullToRefreshSliderListView pullRefreshListView;
	private CollectionListAdapter collectionListAdapter;

	private int pageNum = 1;
	private int pageSize = 10;

	// 未登录和没数据界面组件
	private View emptyLayout;
	private Button btnEmpty;

	@Override
	protected View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_collection, container,
				false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		pullRefreshListView = (PullToRefreshSliderListView) view
				.findViewById(R.id.ptrflv_collection_list);

		emptyLayout = (View) view
				.findViewById(R.id.collection_list_empty_layout);
		btnEmpty = (Button) view.findViewById(R.id.collection_list_empty__btn);
	}

	@Override
	protected void initData() {
		collectionListAdapter = new CollectionListAdapter(mActivity);
		pullRefreshListView.setAdapter(collectionListAdapter);
		pullRefreshListView.setMode(Mode.BOTH);

	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case 0:
			CommodityBO commodityBO = (CommodityBO) data
					.getSerializableExtra(Constants.KEY_COMMODITY_COMMODITYBO);
			// makeToast(commodityBO.getName() + commodityBO.isCollected());
			if (!commodityBO.isCollected()) {
				// makeToast("remove"+commodityBO.getName());
				collectionListAdapter.getItems().remove(commodityBO);
				collectionListAdapter.notifyDataSetChanged();
			}
			break;
		case 1:
			PriceBO obj = (PriceBO) data
					.getSerializableExtra(Constants.KEY_BROWSER_PRICEBO);
			if (!obj.isCollected()) {
				for (Iterator<CommodityBO> iterator = collectionListAdapter
						.getItems().iterator(); iterator.hasNext();) {
					CommodityBO bo = iterator.next();
					if (bo.getPrices().size() == 1) {
						if (bo.getPrices().get(0).equals(obj)) {
							collectionListAdapter.getItems().remove(bo);
							collectionListAdapter.notifyDataSetChanged();
							break;
						}
					}
				}
			}
			break;
		default:
			break;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	protected void addListener() {
		pullRefreshListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				CommodityBO commodityBO = (CommodityBO) collectionListAdapter
						.getItem(position - 1);

				if (commodityBO.isCollected()) {
					Intent intent = new Intent(mActivity,
							CommodityActivity.class);
					intent.putExtra(Constants.KEY_COMMODITY_TYPE, 1);
					intent.putExtra(Constants.KEY_COMMODITY_ID,
							commodityBO.getId());
					intent.putExtra(Constants.KEY_COMMODITY_TITLE,
							commodityBO.getName());
					intent.putExtra(Constants.KEY_COMMODITY_COMMODITYBO,
							commodityBO);
					// intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivityForResult(intent, 0);
				} else {
					PriceBO obj = commodityBO.getPrices().get(0);
					if (obj != null && obj.getUrl() != null) {
						String link = obj.getUrl();
						if (Patterns.WEB_URL.matcher(link).matches()) {
							// makeToast("链接符合标准"+obj.getUrl());
							// 符合标准
							Intent webIntent = new Intent(mActivity,
									BrowserActivity.class);
							webIntent
									.putExtra(Constants.KEY_BROWSER_LINK, link);
							webIntent.putExtra(Constants.KEY_BROWSER_TITLE, obj
									.getStore().getName());
							webIntent.putExtra(Constants.KEY_BROWSER_TYPE, "0");
							webIntent.putExtra(Constants.KEY_BROWSER_PRICEBO,
									obj);
							// webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

							startActivityForResult(webIntent, 1);
						} else {
							// 不符合标准
							makeToast("链接不符合标准" + obj.getUrl());
						}
					}
				}
			}
		});
		pullRefreshListView.setOnRefreshListener(new OnRefreshListener2() {

			@Override
			public void onPullDownToRefresh(PullToRefreshBase refreshView) {
				pageNum = 1;
				refreshData();
			}

			@Override
			public void onPullUpToRefresh(PullToRefreshBase refreshView) {
				refreshData();
			}
		});
		collectionListAdapter
				.setOnDeleteClickListener(new OnObjectClickListener<CommodityBO>() {

					@Override
					public void OnClick(View view, final CommodityBO obj) {
						ChaoCustomDialog dialog = null;
						dialog = new ChaoCustomDialog.Builder(mActivity)
								.setMessage("确定取消收藏" + obj.getName())
								.setMessageColor(
										mActivity.getResources().getColor(
												R.color.theme_background_red))
								.setNegativeButton("否",
										new DialogInterface.OnClickListener() {
											@Override
											public void onClick(
													DialogInterface dialog,
													int which) {

											}
										})
								.setPositiveButton("是",
										new DialogInterface.OnClickListener() {
											@Override
											public void onClick(
													DialogInterface dialog,
													int which) {
												cancelCollectCommodity(obj);
											}

										}).create();
						dialog.show();
					}
				});
		collectionListAdapter
				.setOnPriceClickListener(new OnObjectClickListener<PriceBO>() {

					@Override
					public void OnClick(View view, PriceBO obj) {
						if (obj != null && obj.getUrl() != null) {
							String link = obj.getUrl();
							if (Patterns.WEB_URL.matcher(link).matches()) {
								// makeToast("链接符合标准"+obj.getUrl());
								// 符合标准
								Intent webIntent = new Intent(mActivity,
										BrowserActivity.class);
								webIntent.putExtra(Constants.KEY_BROWSER_LINK,
										link);
								webIntent.putExtra(Constants.KEY_BROWSER_TITLE,
										obj.getStore().getName());
								webIntent.putExtra(Constants.KEY_BROWSER_TYPE,
										"1");
								webIntent
										.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
								startActivity(webIntent);
							} else {
								// 不符合标准
								makeToast("链接不符合标准" + obj.getUrl());
							}
						}
					}
				});
	}

	/**
	 * 取消收藏商品
	 * 
	 * @param obj
	 */
	private void cancelCollectCommodity(final CommodityBO obj) {
		if (obj.isCollected()) {
			mActivity.appAction.cancelCollectCommodity(obj.getId(), 1,
					new ActionCallbackListener<Void>() {

						@Override
						public void onSuccess(Void data) {
							makeToast("已取消收藏");
							collectionListAdapter.getItems().remove(obj);
							collectionListAdapter.notifyDataSetChanged();
						}

						@Override
						public void onFailure(String errorEvent, String message) {
							makeToast(message);
						}
					});
		} else {
			mActivity.appAction.cancelCollectCommodity(obj.getPrices().get(0)
					.getId(), 2, new ActionCallbackListener<Void>() {

				@Override
				public void onSuccess(Void data) {
					makeToast("已取消收藏");
					collectionListAdapter.getItems().remove(obj);
					collectionListAdapter.notifyDataSetChanged();
				}

				@Override
				public void onFailure(String errorEvent, String message) {
					makeToast(message);
				}
			});
		}
	}

	/**
	 * 从网络加载数据并更新listview
	 */
	private void refreshData() {
		mActivity.appAction.listCollection(pageNum, pageSize,
				new ActionCallbackListener<List<CommodityBO>>() {
					@Override
					public void onSuccess(List<CommodityBO> data) {
						if (data != null && !data.isEmpty()) {
							if (pageNum == 1) { // 第一页
								collectionListAdapter.setItems(data);
							} else { // 分页数据
								collectionListAdapter.addItems(data);
							}
							pageNum++;
							Log.d("refreshData", "data" + data.size() + "data"
									+ data.get(0).getName());
						} else {
							if (pageNum != 1) {
								makeToast("没有更多数据了");
							} else {
								emptyLayout.setVisibility(View.VISIBLE);
								btnEmpty.setVisibility(View.VISIBLE);
								btnEmpty.setText("没收藏数据");
								btnEmpty.setOnClickListener(new OnClickListener() {

									@Override
									public void onClick(View v) {
										Intent intent = new Intent(
												getActivity(),
												HistoryKeywordSearchActivity.class);
										getActivity().startActivity(intent);
									}
								});
							}
						}
						pullRefreshListView.onRefreshComplete();
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						makeToast(message);
						pullRefreshListView.onRefreshComplete();
					}
				});
	}

	@Override
	public void onResume() {
		if (UserManager.isBingAccount() && pageNum == 1) {// 检测是否登录后

			// showLoadingDialog("加载数据");
			refreshData();

			emptyLayout.setVisibility(View.GONE);
			btnEmpty.setVisibility(View.GONE);
		} else if (UserManager.isBingAccount()) {
			emptyLayout.setVisibility(View.GONE);
			btnEmpty.setVisibility(View.GONE);
		} else {
			emptyLayout.setVisibility(View.VISIBLE);
			btnEmpty.setVisibility(View.VISIBLE);
			btnEmpty.setText("未登录");
			btnEmpty.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					Intent intent = new Intent(mActivity, LoginActivity.class);
					startActivity(intent);
				}
			});
		}
		super.onResume();
	}

}
