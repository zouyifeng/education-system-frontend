/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-12
 */
package com.chao.chaosearchapp;

import android.app.Activity;
import android.app.Application;
import android.content.Context;

import com.chao.chaosearchapp.core.AppAction;
import com.chao.chaosearchapp.core.AppActionImpl;
import com.chao.chaosearchapp.model.NetworkTipBO;
import com.iflytek.cloud.SpeechUtility;

/**
 * @author chaoking
 * 
 */
public class ChaoSearchApplication extends Application {

	private AppAction appAction;

	private static Context appContext;

	private static Activity mCurActivity;

	public static NetworkTipBO networkTip = new NetworkTipBO();

	@Override
	public void onCreate() {
		super.onCreate();
		appAction = new AppActionImpl(this);
		appContext = getApplicationContext();
		SpeechUtility.createUtility(ChaoSearchApplication.this,
				"appid=57277715");
	}

	public AppAction getAppAction() {
		return appAction;
	}

	public static Context getContext() {
		return appContext;
	}

	public static Activity getCurActivity() {
		return mCurActivity;
	}

	public static void setCurActivity(Activity activity) {
		mCurActivity = activity;
	}

}