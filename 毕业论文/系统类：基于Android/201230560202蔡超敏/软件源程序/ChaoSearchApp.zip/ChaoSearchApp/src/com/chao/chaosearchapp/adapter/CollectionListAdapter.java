/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-12
 */
package com.chao.chaosearchapp.adapter;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.SliderView;
import com.chao.chaosearchapp.listener.OnObjectClickListener;
import com.chao.chaosearchapp.model.CommodityBO;
import com.chao.chaosearchapp.model.PriceBO;
import com.chao.chaosearchapp.util.AsyncImageLoader;

/**
 * @author chaoking
 * 
 */
public class CollectionListAdapter extends ChaoBaseAdapter<CommodityBO> {

	private OnObjectClickListener<CommodityBO> onDeleteClickListener;

	public void setOnDeleteClickListener(
			OnObjectClickListener<CommodityBO> onDeleteClickListener) {
		this.onDeleteClickListener = onDeleteClickListener;
	}

	private OnObjectClickListener<PriceBO> onPriceClickListener;

	public void setOnPriceClickListener(
			OnObjectClickListener<PriceBO> onPriceClickListener) {
		this.onPriceClickListener = onPriceClickListener;
	}

	public CollectionListAdapter(Context context) {
		super(context);
		initImageLoader();
	}

	/**
	 * 初始化图片加载组件
	 */
	private void initImageLoader() {
		WindowManager wm = (WindowManager) context
				.getSystemService(Context.WINDOW_SERVICE);
		int width = wm.getDefaultDisplay().getWidth();
		mLoader.setIsUseMediaStoreThumbnails(false);
		mLoader.setRequiredSize(width / 3);
	}

	@Override
	public View getView(int i, View view, ViewGroup viewGroup) {
		SliderView sliderView;
		final ViewHolder holder;
		if (view == null) {
			view = inflater.inflate(R.layout.item_list_commodity, null);
			sliderView = new SliderView(context);
			sliderView.setContentView(view);

			holder = new ViewHolder(sliderView);
			holder.itemName = (TextView) view
					.findViewById(R.id.item_list_commodity_name);
			holder.itemIntroduce = (TextView) view
					.findViewById(R.id.item_list_commodity_introduce);
			holder.imageView = (ImageView) view
					.findViewById(R.id.item_list_commodity_pic);
			holder.layout = (LinearLayout) view
					.findViewById(R.id.item_list_commodity_price_info);
			sliderView.setTag(holder);
		} else {
			sliderView = (SliderView) view;
			holder = (ViewHolder) sliderView.getTag();
		}

		sliderView.shrink();
		final CommodityBO commodity = itemList.get(i);

		holder.itemName.setText(commodity.getName());
		holder.itemIntroduce.setText(commodity.getIntroduce());

		// AsyncImageLoader.getInstance().showImageAsyn(holder.imageView,
		// commodity.getPic(), R.drawable.ic_launcher);
		mLoader.DisplayImage(commodity.getPic(), holder.imageView,
				R.drawable.ic_launcher);
		if (commodity.getPrices() != null && !commodity.getPrices().isEmpty()) {
			holder.layout.setVisibility(View.VISIBLE);
			holder.layout.removeAllViews();
			if (holder.storesView == null) {
				holder.storesView = new ArrayList<View>();
			}
			holder.storesView.clear();

			int count = 0;
			boolean isFirst = true;
			int commodityPriceNum = commodity.getPrices().size();
			for (Iterator<PriceBO> iterator = commodity.getPrices().iterator(); iterator
					.hasNext();) {
				final PriceBO priceBO = iterator.next();
				View itemView = inflater.inflate(
						R.layout.item_list_commodity_store, viewGroup, false);

				PriceViewHolder priceViewHolder = new PriceViewHolder();

				priceViewHolder.line = itemView
						.findViewById(R.id.item_list_commodity_price_store_line);
				priceViewHolder.moreView = itemView
						.findViewById(R.id.item_list_commodity_price_more);
				priceViewHolder.infoView = itemView
						.findViewById(R.id.item_list_commodity_price_item);
				priceViewHolder.storeNameView = (TextView) itemView
						.findViewById(R.id.item_list_commodity_price_store_name);
				priceViewHolder.storePriceView = (TextView) itemView
						.findViewById(R.id.item_list_commodity_price_store_price);
				priceViewHolder.storePicView = (ImageView) itemView
						.findViewById(R.id.item_list_commodity_price_store_pic);

				AsyncImageLoader.getInstance().showImageAsyn(
						priceViewHolder.storePicView,
						priceBO.getStore().getPic(), R.drawable.ic_launcher);
				priceViewHolder.storeNameView.setText(priceBO.getStore()
						.getName());
				priceViewHolder.storePriceView.setText(String.format("¥%.2f",
						priceBO.getEstimateAmount()));

				itemView.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						if (priceBO != null) {
							if (onPriceClickListener != null)
								onPriceClickListener.OnClick(v, priceBO);
							// Toast.makeText(context, priceBO.getUrl(),
							// Toast.LENGTH_SHORT).show();
						}
					}
				});

				if (count == 0) {
					priceViewHolder.line.setVisibility(View.GONE);
					priceViewHolder.infoView.setVisibility(View.VISIBLE);
					priceViewHolder.moreView.setVisibility(View.GONE);
					itemView.setVisibility(View.VISIBLE);
				} else if (count <= 2) {
					priceViewHolder.line.setVisibility(View.GONE);
					priceViewHolder.infoView.setVisibility(View.VISIBLE);
					priceViewHolder.moreView.setVisibility(View.GONE);
					itemView.setVisibility(View.VISIBLE);
				} else {
					priceViewHolder.line.setVisibility(View.GONE);
					priceViewHolder.infoView.setVisibility(View.VISIBLE);
					priceViewHolder.moreView.setVisibility(View.GONE);
					itemView.setVisibility(View.GONE);
				}
				count++;

				itemView.setTag(priceBO);
				holder.storesView.add(itemView);
				holder.layout.addView(itemView);
			}
			if (commodityPriceNum > 3) {
				View itemView = inflater.inflate(
						R.layout.item_list_commodity_store, viewGroup, false);
				PriceViewHolder priceViewHolder = new PriceViewHolder();

				priceViewHolder.line = itemView
						.findViewById(R.id.item_list_commodity_price_store_line);
				priceViewHolder.moreView = itemView
						.findViewById(R.id.item_list_commodity_price_more);
				priceViewHolder.infoView = itemView
						.findViewById(R.id.item_list_commodity_price_item);
				priceViewHolder.line.setVisibility(View.GONE);
				priceViewHolder.moreView.setVisibility(View.VISIBLE);
				priceViewHolder.infoView.setVisibility(View.GONE);

				itemView.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						TextView moreView = ((TextView) v
								.findViewById(R.id.item_list_commodity_price_store_more_view));
						if (moreView.getText().equals("更多")) {
							int size = holder.storesView.size();
							for (int j = 3; j < size; j++) {
								View view = holder.storesView.get(j);
								view.setVisibility(View.VISIBLE);
							}
							moreView.setText("收起");
						} else {
							int size = holder.storesView.size();
							for (int j = 3; j < size; j++) {
								View view = holder.storesView.get(j);
								view.setVisibility(View.GONE);
							}
							moreView.setText("更多");
						}

					}
				});

				itemView.setTag(commodity.getPrices());
				holder.layout.addView(itemView);
			}

		} else {
			holder.layout.setVisibility(View.GONE);
		}

		holder.deleteHolder.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (onDeleteClickListener != null) {
					onDeleteClickListener.OnClick(v, commodity);
				}
			}
		});
		return sliderView;
	}

	static class ViewHolder {
		TextView itemName;
		TextView itemIntroduce;
		ImageView imageView;
		LinearLayout layout;
		List<View> storesView;
		ViewGroup deleteHolder;

		public ViewHolder(View view) {
			deleteHolder = (ViewGroup) view.findViewById(R.id.holder);
		}
	}

	static class PriceViewHolder {
		View line;
		View moreView;
		View infoView;
		ImageView storePicView;
		TextView storeNameView;
		TextView storePriceView;
	}

}
