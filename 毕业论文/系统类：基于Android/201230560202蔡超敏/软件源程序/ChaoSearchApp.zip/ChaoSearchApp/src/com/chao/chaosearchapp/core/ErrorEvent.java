/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-12
 */
package com.chao.chaosearchapp.core;

/**
 * 错误码
 * 
 * @author chaoking
 * 
 */
public class ErrorEvent {
	static final public String PARAM_NULL = "PARAM_NULL"; // 参数为空
	static final public String PARAM_ILLEGAL = "PARAM_ILLEGAL"; // 参数不合法
}
