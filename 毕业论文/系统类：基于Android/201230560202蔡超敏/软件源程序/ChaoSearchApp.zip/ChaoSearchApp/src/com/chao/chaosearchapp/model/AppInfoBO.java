/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-29
 */
package com.chao.chaosearchapp.model;

import java.io.Serializable;

/**
 * App配置信息,包括有服务器版本号,更新地址,资源文件,等
 * 
 * @author chaoking
 * 
 */
public class AppInfoBO implements Serializable {
	// {"isForce":0,"result":true,"clientDesc":"版本更新","resVersion":1
	// ,"clientURL":"http:\/\/test.1hhd.com\/TchyClientApp.apk","version":"1.37"}

	private static final long serialVersionUID = 2006973721923903125L;
	// -boolean 机型，客户端类型不正确时返回false
	private boolean result = false;
	// -String 错误描述
	private String errorDesc = "";
	// int 强制更新 0 是 1否
	private boolean isForce;
	// -String 当前版本
	private String version;
	// -String 强更客户端URL
	private String clientURL;
	// -String 更新客户端描述
	private String clientDesc;
	// -int 当前资源版本号
	private int resVersion;
	// -String 更新资源URL
	private String resURL;
	// -String 更新资源描述
	private String resDesc;

	public boolean isResult() {
		return result;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	/**
	 * @return the isForce
	 */
	public boolean isForce() {
		return isForce;
	}

	/**
	 * @param isForce
	 *            the isForce to set
	 */
	public void setForce(boolean isForce) {
		this.isForce = isForce;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getClientURL() {
		return clientURL;
	}

	public void setClientURL(String clientURL) {
		this.clientURL = clientURL;
	}

	public String getClientDesc() {
		return clientDesc;
	}

	public void setClientDesc(String clientDesc) {
		this.clientDesc = clientDesc;
	}

	public int getResVersion() {
		return resVersion;
	}

	public void setResVersion(int resVersion) {
		this.resVersion = resVersion;
	}

	public String getResURL() {
		return resURL;
	}

	public void setResURL(String resURL) {
		this.resURL = resURL;
	}

	public String getResDesc() {
		return resDesc;
	}

	public void setResDesc(String resDesc) {
		this.resDesc = resDesc;
	}

	@Override
	public String toString() {
		return "AppInfo [result=" + result + ", errorDesc=" + errorDesc
				+ ", isForce=" + isForce + ", version=" + version
				+ ", clientURL=" + clientURL + ", clientDesc=" + clientDesc
				+ ", resVersion=" + resVersion + ", resURL=" + resURL
				+ ", resDesc=" + resDesc + "]";
	}

	public AppInfoBO(boolean result, String errorDesc, boolean isForce,
			String version, String clientURL, String clientDesc,
			int resVersion, String resURL, String resDesc, String addressIP,
			String addressPort) {
		super();
		this.result = result;
		this.errorDesc = errorDesc;
		this.isForce = isForce;
		this.version = version;
		this.clientURL = clientURL;
		this.clientDesc = clientDesc;
		this.resVersion = resVersion;
		this.resURL = resURL;
		this.resDesc = resDesc;
	}

	public AppInfoBO() {
		super();
	}
}
