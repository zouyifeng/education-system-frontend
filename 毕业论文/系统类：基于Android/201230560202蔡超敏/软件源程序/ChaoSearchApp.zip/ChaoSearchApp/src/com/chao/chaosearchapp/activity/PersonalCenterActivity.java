/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-17
 */
package com.chao.chaosearchapp.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.manager.UserManager;

/**
 * @author chaoking
 * 
 */
public class PersonalCenterActivity extends ChaoBaseActivity {

	private View vLoginLayout, vUserName, vPhone;

	private View vReleaseLayout, vLogin;

	private View btnReleaseBound;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_personal_center);
	}

	/**
	 * 检测是否绑定及显示用户信息
	 */
	private void checkBindUserAndShowLayout() {
		Log.d("checkBindUserAndShowLayout", "UserManager.isBingAccount()"
				+ UserManager.isBingAccount());
		if (UserManager.isBingAccount()) {
			vReleaseLayout.setVisibility(View.GONE);
			vLoginLayout.setVisibility(View.VISIBLE);
			btnReleaseBound.setVisibility(View.VISIBLE);

			((TextView) vUserName).setText(UserManager.getUserName("chaoking"));
			((TextView) vPhone).setText(UserManager.getPhone("12345678901"));
		} else {
			vLoginLayout.setVisibility(View.GONE);
			vReleaseLayout.setVisibility(View.VISIBLE);
			btnReleaseBound.setVisibility(View.GONE);
		}
	}

	private void releaseBoundUser() {
		UserManager.clearBingAccountInfo();
		Intent i = getPackageManager().getLaunchIntentForPackage(
				getPackageName());
		i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(i);
		// overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
		android.os.Process.killProcess(android.os.Process.myPid());
	}

	@Override
	public void onResume() {
		checkBindUserAndShowLayout();
		super.onResume();
	}

	@Override
	protected void initViews() {
		vLoginLayout = findViewById(R.id.personal_center_info_layout);
		vUserName = findViewById(R.id.personal_center_name);
		vPhone = findViewById(R.id.personal_center_phone);

		vReleaseLayout = findViewById(R.id.personal_center_empty_layout);
		vLogin = findViewById(R.id.personal_center_empty_img_head);

		btnReleaseBound = findViewById(R.id.personal_center_release_bound);
	}

	@Override
	protected void initData() {
		checkBindUserAndShowLayout();

	}

	@Override
	protected void addListener() {
		vLogin.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(PersonalCenterActivity.this,
						LoginActivity.class);
				startActivity(intent);
			}
		});

		btnReleaseBound.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				releaseBoundUser();
			}
		});
	}

	/* (non-Javadoc)
	 * @see com.chao.chaosearchapp.activity.ChaoBaseActivity#setChaoActionBarId()
	 */
	@Override
	protected int setChaoActionBarId() {
		// TODO Auto-generated method stub
		return 0;
	}


	/* (non-Javadoc)
	 * @see com.chao.chaosearchapp.activity.ChaoBaseActivity#setNetworkTip(boolean, java.lang.String)
	 */
	@Override
	public void setNetworkTip() {
		// TODO Auto-generated method stub
		
	}
}
