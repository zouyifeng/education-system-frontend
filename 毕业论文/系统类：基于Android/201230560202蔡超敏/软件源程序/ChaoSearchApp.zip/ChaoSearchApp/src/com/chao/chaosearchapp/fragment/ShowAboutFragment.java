/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-5-4
 */
package com.chao.chaosearchapp.fragment;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * @author chaoking
 * 
 */
public class ShowAboutFragment extends ChaoBaseFragment {

	private TextView tvShow;

	@Override
	protected View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_show_about, container,
				false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		tvShow = (TextView) view.findViewById(R.id.show_us_content);
		tvShow.setMovementMethod(ScrollingMovementMethod.getInstance());
	}

	@Override
	protected void initData() {
		int type = mActivity.getIntent()
				.getIntExtra(Constants.KEY_SHOWUS_ID, 1);
		if (type == 1) {
		} else {
			tvShow.setText("   华南农业大学数学与信息学院办学优势突出，学科综合实力强，其前身为理学院和信息学院。人才培养方面，多年来学院超过6个专业平均就业薪酬位居全校高薪榜前十，各专业毕业生就业率均在98%以上，居广东省相同专业前列。\n"

					+ "   学院现有数学与应用数学（含金融数学方向）、信息与计算科学、统计学、计算机科学与技术、软件工程、网络工程、信息管理与信息系统、工业工程8个本科专业，应用数学为省级重点学科，计算机科学与技术专业为广东省名牌专业、软件工程是广东省特色专业；有数学、计算机科学与技术、管理科学与工程3个一级学科硕士学位授权点，有数学、应用数学、计算机应用技术、计算机系统结构、计算机软件与理论5个二级学科硕士学位授权点；有计算机技术、工业工程、农业信息化3个专业学位硕士研究生招生专业；有农业自动化与电气化博士招生专业。\n"

					+ "   2016年全日制在校生4121人，其中本科生4026人、硕士研究生85人、博士研究生10人；在职攻读专业学位硕士76人。\n"

					+ "   学院教职工197人，专任教师173人，其中教授20人、青年教授2人、副高职称60人、青年副教授1人，博士生导师5人、硕士生导师42人，具有博士学位教师人数92人，全国教学名师1人，广东省教学名师1人，农业部优秀教师1人，南粤优秀教师1人，广东省高校学校“千百十工程”省级培养对象2人、校级培养对象12人。\n"

					+ "   学院具有良好的教学科研条件。建设有教育部大学生校外实践教学基地（华南农业大学——四川华迪信息技术有限公司工程实践教育中心）、广东省应用型人才培养示范基地（华南农业大学——四川华迪信息技术有限公司）、广东省教育厅计算机工程与应用重点实验室、广东省大学生实践教学基地——“软件工程及计算机类专业工程实践教育中心”、广东省高等学校计算机基础课实验教学示范中心和校级“软件工程实验示范中心”，有国家级精品课程《大学数学（农科）》，省级精品课程《高等数学（理工科）》、《高级语言程序设计》、《大学计算机基础》、《计算机网络》，校级精品课程《线性代数》、《数据库原理与方法》、《计算机网络》、《管理信息系统》、《数据结构》、《程序设计》，有广东省农业养殖物联网工程技术研究中心和应用数学研究所、应用统计研究室、信息安全研究所、软件工程研究中心、图像图形研究中心、农业系统及管理工程研究所、农业遥感与信息技术中心、人机交互研究中心等8个科研机构，研究领域涵盖应用数学、应用统计、计算机技术应用、智能信息、图形图像、网络与信息安全、信息管理、数据库与数据挖掘等。学院另有数学、计算机网络、计算机硬件、信息技术、软件工程、信息管理技术、工业工程等7个专业实验中心及ACM创新实验室、机器人、云计算校企联合型创新实验室等6个学生专用创新实验室。学院在中软国际有限公司、四川华迪信息技术有限公司、深圳市金证科技有限公司等国内著名大型软件企业、国家级人才培训基地、软件上市公司等建立一批稳定的高质量校外教学实习基地。\n"

					+ "   学院高度重视培养学生创新精神，提高学生核心竞争力，积极开展大学生科技创新工作。2015年，我院ACM-ICPC代表队在第40届国际大学生程序设计竞赛亚洲区域赛中获得金牌3枚、银牌5枚、铜牌2枚；2014年，在第39届ACM国际大学生程序设计竞赛亚洲区域赛中，我校代表队勇夺季军杯1座、金牌2枚、银牌4枚、铜牌4枚，第三次晋级2015年在非洲摩洛哥举行的第39届ACM全球总决赛，成为唯一一所进入全球总决赛的农业院校，并在世界总决赛中晋升前20强，取得我校在该项赛事历年的最好成绩；2013年和2014年，我院学子连续两年参加Imagine Cup 微软“创新杯”中国区总决赛，分别荣获赛区总决赛一等奖、游戏组第一名和“游戏开发”特等奖。2015年，我院参加美国大学生数学建模竞赛，获得二等奖5项，三等奖7项，参加“高教社杯”全国大学生数学建模竞赛获得全国竞赛二等奖5项、广东赛区一等奖5项、二等奖17项、三等奖33项；在2014年“高教社杯”全国大学生数学建模竞赛中，我院荣获一等奖4项、二等奖3项；2012年，我院在美国大学生数学建模竞赛中斩获3项一等奖。2009年至今，我院学生在参加ACM-ICPC大学生程序设计大赛、大学生数学建模竞赛、Imagine Cup微软“创新杯”、Java程序员竞赛、大学生计算机作品赛等世界级、国家级和省级学科竞赛中，获得世界级奖励53项，国家级奖励98项，省级以上奖励378项。\n"

					+ "   在深化教育教学改革的大好形势下，随着师资力量的不断增强，教学和科研条件的日益改善，学院在人才培养、科研开发和社会服务等方面必将会做出更优异的成绩。\n");
		}
	}

	@Override
	protected void addListener() {
		// TODO Auto-generated method stub

	}

}
