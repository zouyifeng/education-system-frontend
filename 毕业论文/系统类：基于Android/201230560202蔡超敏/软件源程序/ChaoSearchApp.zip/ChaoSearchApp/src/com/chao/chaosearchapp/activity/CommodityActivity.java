/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-10
 */
package com.chao.chaosearchapp.activity;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.Button;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.ChaoActionBar;
import com.chao.chaosearchapp.assembly.ChaoActionBar.ChaoActionBarCallBack;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.fragment.CommodityFragment;
import com.chao.chaosearchapp.model.CommodityBO;
import com.chao.chaosearchapp.util.AppUtil;

/**
 * @author chaoking
 * 
 */
public class CommodityActivity extends SingleFragmentActivity {

	private CommodityBO commodityBO;

	private CommodityFragment commodityFragment;

	@Override
	protected Fragment createFragment() {
		commodityFragment = new CommodityFragment();
		return commodityFragment;
	}

	@Override
	protected void initViews() {
		ChaoActionBar chaoActionBar = getChaoActionBar();

		chaoActionBar.getTitleView().setVisibility(View.VISIBLE);
		chaoActionBar.setHomeIcon(R.drawable.arrow_left_circle);
		chaoActionBar.getHomeView().setPadding(
				AppUtil.dpToPx(10, getResources()), 0, 0, 0);
		chaoActionBar.setHomeVisibility(View.VISIBLE);

		chaoActionBar.getChaoSearchEditText().setVisibility(View.GONE);

		getChaoActionBar().setSubMenuVisibility(View.VISIBLE);
		getChaoActionBar().getSubMenuView().setPadding(0, 0,
				AppUtil.dpToPx(5, getResources()), 0);
	}

	@Override
	protected void initData() {
		int type = getIntent().getIntExtra(Constants.KEY_COMMODITY_TYPE, 0);

		if (type == 0) {
			commodityBO = (CommodityBO) getIntent().getSerializableExtra(
					Constants.KEY_COMMODITY_COMMODITYBO);

			getChaoActionBar().setTitleText(
					commodityBO.getName().length() > 18 ? commodityBO.getName()
							.substring(0, 16) + "..." : commodityBO.getName());
			if (commodityBO.isCollected()) {
				getChaoActionBar().setSubmenuIcon(
						R.drawable.collect_star_selected);
			} else {
				getChaoActionBar().setSubmenuIcon(
						R.drawable.collect_star_unselected);
			}
		} else {

			commodityBO = (CommodityBO) getIntent().getSerializableExtra(
					Constants.KEY_COMMODITY_COMMODITYBO);
			String title = getIntent().getStringExtra(
					Constants.KEY_COMMODITY_TITLE);
			getChaoActionBar().setTitleText(
					title.length() > 20 ? title.substring(0, 18) + "..."
							: title);

			getChaoActionBar().setSubmenuIcon(
					R.drawable.collect_star_unselected);

			int id = getIntent().getIntExtra(Constants.KEY_COMMODITY_ID, 0);

			appAction.getCommodity(id,
					new ActionCallbackListener<CommodityBO>() {

						@Override
						public void onSuccess(CommodityBO data) {
							if (data == null)
								return;
							commodityBO = data;
							getIntent().putExtra(
									Constants.KEY_COMMODITY_COMMODITYBO,
									commodityBO);
							commodityFragment.refreshLayout(commodityBO);
							getChaoActionBar()
									.setTitleText(
											commodityBO.getName().length() > 20 ? commodityBO
													.getName().substring(0, 18)
													+ "..." : commodityBO
													.getName());

							if (commodityBO.isCollected()) {
								getChaoActionBar().setSubmenuIcon(
										R.drawable.collect_star_selected);
							} else {
								getChaoActionBar().setSubmenuIcon(
										R.drawable.collect_star_unselected);
							}
						}

						@Override
						public void onFailure(String errorEvent, String message) {
							makeToast(message);
						}
					});
		}
	}

	@Override
	protected void addListener() {
		// TODO Auto-generated method stub

	}

	@Override
	public void finish() {
		Intent intent = new Intent();
		intent.putExtra(Constants.KEY_COMMODITY_COMMODITYBO, commodityBO);
		setResult(0, intent);
		super.finish();
	}

	@Override
	protected ChaoActionBarCallBack addChaoActionBarCallBack() {
		return new ChaoActionBarCallBack() {

			@Override
			public void onSubmenuClickCallBack(Button submenubtn) {
				// makeToast("是否收藏" + commodityBO.isCollected());
				if (commodityBO != null && commodityBO.isCollected()) {
					appAction.cancelCollectCommodity(commodityBO.getId(), 1,
							new ActionCallbackListener<Void>() {

								@Override
								public void onSuccess(Void data) {
									makeToast("已取消收藏");
									commodityBO.setIsCollected(0);
									getChaoActionBar().setSubmenuIcon(
											R.drawable.collect_star_unselected);
								}

								@Override
								public void onFailure(String errorEvent,
										String message) {
									makeToast(message);
								}
							});
				} else {
					appAction.collectCommodity(commodityBO.getId(), 1,
							new ActionCallbackListener<Void>() {

								@Override
								public void onSuccess(Void data) {
									makeToast("已收藏");
									commodityBO.setIsCollected(1);
									getChaoActionBar().setSubmenuIcon(
											R.drawable.collect_star_selected);
								}

								@Override
								public void onFailure(String errorEvent,
										String message) {
									makeToast(message);
								}
							});
				}
			}

			@Override
			public void onHomeClickCallBack(Button homebtn) {
				finish();
			}
		};
	}

}
