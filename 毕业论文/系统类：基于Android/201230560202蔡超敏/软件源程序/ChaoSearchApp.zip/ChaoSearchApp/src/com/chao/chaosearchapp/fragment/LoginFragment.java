/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-12
 */
package com.chao.chaosearchapp.fragment;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.InputFilter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import cn.jpush.android.api.JPushInterface;
import cn.jpush.android.api.TagAliasCallback;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.activity.RegisterActivity;
import com.chao.chaosearchapp.assembly.filter.CustomFilter;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.manager.UserManager;
import com.chao.chaosearchapp.model.HistoryKeywordBO;
import com.chao.chaosearchapp.model.UserBO;

/**
 * @author chaoking
 * 
 */
public class LoginFragment extends ChaoBaseFragment {

	private EditText phoneEdit;
	private EditText passwordEdit;
	private Button loginBtn;

	private TextView tvRegister, tvFindPassword;

	@Override
	protected View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.activity_login, container, false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		phoneEdit = (EditText) view.findViewById(R.id.login_phone);
		phoneEdit.setFilters(new InputFilter[] { new CustomFilter(11) });
		passwordEdit = (EditText) view.findViewById(R.id.login_password);
		loginBtn = (Button) view.findViewById(R.id.btn_login);
		tvRegister = (TextView) view.findViewById(R.id.login_register);
		tvFindPassword = (TextView) view.findViewById(R.id.login_find_password);
	}

	@Override
	protected void initData() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void addListener() {
		loginBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				toLogin(v);
			}
		});
		tvRegister.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mActivity, RegisterActivity.class);
				startActivity(intent);
			}
		});
		tvFindPassword.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				makeToast("功能未开通");
			}
		});
	}

	// 准备登录
	public void toLogin(View view) {
		String loginName = phoneEdit.getText().toString();
		String password = passwordEdit.getText().toString();
		loginBtn.setEnabled(false);
		mActivity.appAction.login(loginName, password,
				new ActionCallbackListener<UserBO>() {
					@Override
					public void onSuccess(UserBO data) {
						Log.d("toLogin-success", "username" + data.getName());
						makeToast(getResources().getString(
								R.string.toast_login_success));

						setUserInfo(data);

						mActivity.finish();
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						makeToast(message);
						loginBtn.setEnabled(true);
					}
				});
	}

	/**
	 * @param data
	 */
	protected void setUserInfo(UserBO user) {
		UserManager.setUserId(String.valueOf(user.getId()));
		UserManager.setUserName(user.getName());
		UserManager.setRealName(user.getRealName());
		UserManager.setBirthday(user.getBirthday());
		UserManager.setEmail(user.getEmail());
		UserManager.setPhone(user.getPhone());
		UserManager.setSex(user.getSex());
		UserManager.setStatus(String.valueOf(user.getStatus()));
		UserManager.setType(String.valueOf(user.getType()));

		TelephonyManager telephonyManager = (TelephonyManager) mActivity
				.getSystemService(Context.TELEPHONY_SERVICE);
		String imei = telephonyManager.getDeviceId();
		JPushInterface.setAlias(mActivity, String.valueOf(imei),
				new TagAliasCallback() {

					@Override
					public void gotResult(int arg0, String arg1,
							Set<String> arg2) {
						Log.d("setUserInfo", "chaoking-gotResult");
					}
				});

		mActivity.appAction
				.getHistorySearchKeyword(new ActionCallbackListener<List<HistoryKeywordBO>>() {

					@Override
					public void onSuccess(List<HistoryKeywordBO> data) {
						if (data == null || data.isEmpty())
							return;
						ArrayList<String> keywords = new ArrayList<String>();
						for (Iterator<HistoryKeywordBO> iterator = data
								.iterator(); iterator.hasNext();) {
							HistoryKeywordBO historyKeywordBO = iterator.next();
							keywords.add(historyKeywordBO.getSearchValue());
						}

						UserManager.setHistorySearchKeywords(keywords);
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						makeToast(message);
					}
				});
	}

}
