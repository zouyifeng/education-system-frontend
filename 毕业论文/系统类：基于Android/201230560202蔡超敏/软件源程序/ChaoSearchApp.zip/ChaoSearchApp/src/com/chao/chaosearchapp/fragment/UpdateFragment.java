/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-29
 */
package com.chao.chaosearchapp.fragment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.ChaoCustomDialog;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.manager.AppManager;
import com.chao.chaosearchapp.model.AppInfoBO;
import com.chao.chaosearchapp.util.PackageUtil;

/**
 * 检查更新版本activity
 * 
 * @author chaoking
 * 
 */
public class UpdateFragment extends ChaoBaseFragment {

	// 控件
	private TextView tvShowVersion, tvShowNewVersion;
	private Button btnCheck;
	private ProgressBar mProgress;
	private AlertDialog progressDialog;

	// app信息
	private AppInfoBO appInfo;
	private String version = "";
	private String newVersion = "";

	private int progress; // 下载进度
	private static final int DOWNLOADING = 1; // 表示正在下载
	private static final int DOWNLOADED = 2; // 下载完毕
	private static final int DOWNLOAD_FAILED = 3; // 下载失败
	private boolean cancelFlag = false;

	// 本地安装地址
	private String apkFilePath = Constants.APK_SAVE_PATH;
	private String apkFile = "update" + newVersion + ".apk";

	@Override
	protected View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater
				.inflate(R.layout.fragment_update, container, false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		tvShowVersion = (TextView) view.findViewById(R.id.update_show_version);
		tvShowNewVersion = (TextView) view
				.findViewById(R.id.update_show_new_version);
		btnCheck = (Button) view.findViewById(R.id.update_btn_check);
	}

	@Override
	protected void initData() {

		appInfo = AppManager.getAppInfo();
		if (appInfo != null)
			updateInitLayout(true);

		String strType = mActivity.getIntent().getStringExtra(
				Constants.KEY_UPDATE_TYPE);
		int type = 0;
		if (strType != null) {
			type = Integer.parseInt(strType);
		}

		if (type == 1) {
			checkVersion();
		}

	}

	@Override
	protected void addListener() {

	}

	/**
	 * 界面更新
	 */
	private void updateInitLayout(boolean flag) {
		version = PackageUtil.getVersionName(mActivity);
		newVersion = appInfo.getVersion();
		if (version != null && newVersion != null
				&& version.compareTo(newVersion) < 0) {// 检查是否已需要更新版本
			tvShowVersion.setText("当前版本号：" + version);
			tvShowNewVersion.setText("最新版本号：" + newVersion);

			apkFile = "update" + newVersion + ".apk";
			Log.d("UpdateActivity", apkFilePath + apkFile);
			final File apk = new File(apkFilePath + apkFile);
			if (apkFile == null || !apk.exists()) {
				btnCheck.setText("更新版本");
				btnCheck.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						updateVersion();
					}
				});
			} else {
				btnCheck.setText("安装最新版本");
				btnCheck.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						installAPK(apk);
					}
				});
			}
		} else {
			if (!flag) {
				makeToast("当前版本最新");
			}
			tvShowVersion.setText("当前版本号：" + version);
			tvShowNewVersion.setVisibility(View.GONE);
			btnCheck.setText("检查更新");
			btnCheck.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					checkVersion();
				}
			});
		}
	}

	/**
	 * 更新版本
	 */
	private void updateVersion() {
		apkFile = "update" + newVersion + ".apk";
		Log.d("UpdateActivity", apkFilePath + apkFile);
		final File apk = new File(apkFilePath + apkFile);
		if (apkFile != null && apk.exists()) {
			btnCheck.setText("安装最新版本");
			btnCheck.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					installAPK(apk);
				}
			});
			installAPK(apk);
			return;
		}
		if (appInfo.getClientURL() != null
				&& !"".equals(appInfo.getClientURL())) {
			showDownloadDialog();
			downloadAPK(appInfo.getClientURL());
		}
	}

	/**
	 * 获取最新版本信息返回信息 appInfo = new Gson().fromJson(json, AppInfo.class);
	 * updateInitLayout(false);
	 * 
	 * 检查服务器最新版本
	 */
	private void checkVersion() {
		String version = PackageUtil.getVersionName(mActivity);
		mActivity.appAction.getVersionInfo(version,
				new ActionCallbackListener<AppInfoBO>() {

					@Override
					public void onSuccess(AppInfoBO data) {
						if (data != null) {
							AppManager.putAppInfo(data);
							appInfo = data;
							if (appInfo != null)
								updateInitLayout(true);
						} else {
							makeToast("当前版本最新");
						}
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						makeToast(message);
					}
				});
	}

	/** 显示进度条对话框 */
	public void showDownloadDialog() {
		AlertDialog.Builder dialog = new AlertDialog.Builder(mActivity);
		dialog.setTitle("更新进度");
		final LayoutInflater inflater = LayoutInflater.from(mActivity);
		View v = inflater.inflate(R.layout.dialog_update, null);
		mProgress = (ProgressBar) v.findViewById(R.id.update_progress);
		dialog.setView(v);
		dialog.setNegativeButton("取消下载", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				showTipDialog();
			}
		});
		progressDialog = dialog.create();
		progressDialog.setCancelable(false);
		progressDialog.setCanceledOnTouchOutside(false);
		progressDialog.show();
	}

	/**
	 * 显示取消下载提示
	 */
	private void showTipDialog() {
		ChaoCustomDialog.Builder custombuilder = new ChaoCustomDialog.Builder(
				mActivity);
		custombuilder.setMessage("是否取消下载最新版本");

		custombuilder.setPositiveButton("确定",
				new android.content.DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						arg0.dismiss();
						progressDialog.dismiss();
						cancelFlag = true;
						apkFile = "update" + newVersion + ".apk";
						File apk = new File(apkFilePath + apkFile);
						if (apk.exists()) {
							apk.delete();
						}
					}
				});
		custombuilder.setNegativeButton("取消",
				new android.content.DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						progressDialog.show();
						arg0.dismiss();
					}
				});
		ChaoCustomDialog customDialog = custombuilder.create();

		customDialog.setCancelable(false);
		customDialog.setCanceledOnTouchOutside(false);
		customDialog.show();
	}

	/**
	 * 从URL中下载安装包
	 * 
	 * @param apkUrl
	 */
	private void downloadAPK(final String apkUrl) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					URL url = new URL(apkUrl);
					HttpURLConnection conn = (HttpURLConnection) url
							.openConnection();
					conn.connect();

					int length = conn.getContentLength();
					InputStream is = conn.getInputStream();

					File file = new File(apkFilePath);
					if (!file.exists()) {
						file.mkdir();
					}
					apkFile = "update" + newVersion + ".apk";
					File ApkFile = new File(apkFilePath + apkFile);

					Log.d("UpdateActivity", ApkFile.getAbsolutePath());
					FileOutputStream fos = new FileOutputStream(ApkFile);

					int count = 0;
					byte buf[] = new byte[1024];

					do {
						int numread = is.read(buf);
						count += numread;
						progress = (int) (((float) count / length) * 100);
						// 更新进度
						mHandler.sendEmptyMessage(DOWNLOADING);
						if (numread <= 0) {
							// 下载完成通知安装
							Message message = mHandler.obtainMessage();
							message.what = DOWNLOADED;
							// message.obj = ApkFile;
							mHandler.sendMessage(message);
							break;
						}
						fos.write(buf, 0, numread);
					} while (!cancelFlag); // 点击取消就停止下载.这里可以设置开关

					fos.close();
					is.close();
				} catch (Exception e) {
					mHandler.sendEmptyMessage(DOWNLOAD_FAILED);
					e.printStackTrace();
				}
			}
		}).start();
	}

	/** 更新UI的handler */
	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(final Message msg) {
			switch (msg.what) {
			case DOWNLOADING:
				mProgress.setProgress(progress);
				break;
			case DOWNLOADED:
				progressDialog.dismiss();
				File ApkFile = new File(apkFilePath + apkFile);
				apkFile = "update" + newVersion + ".apk";
				File newFileName = new File(apkFilePath + apkFile);
				ApkFile.renameTo(newFileName);
				installAPK(newFileName);
				break;
			case DOWNLOAD_FAILED:
				downloadFailed();
				break;
			default:
				break;
			}
		}

	};

	/**
	 * 下载失败后显示提示dialog
	 */
	private void downloadFailed() {
		progressDialog.dismiss();
		ChaoCustomDialog.Builder custombuilder = new ChaoCustomDialog.Builder(
				mActivity);
		custombuilder.setMessage("下载失败");

		custombuilder.setPositiveButton("重新下载",
				new android.content.DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						arg0.dismiss();
						updateVersion();
					}
				});
		custombuilder.setNegativeButton("取消下载",
				new android.content.DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						arg0.dismiss();
					}
				});
		ChaoCustomDialog customDialog = custombuilder.create();

		customDialog.setCancelable(false);
		customDialog.setCanceledOnTouchOutside(false);
		customDialog.show();
	}

	/**
	 * 安装apk安装包
	 * 
	 * @param apkFile
	 */
	private void installAPK(File apkFile) {
		if (apkFile == null || !apkFile.exists()) {
			makeToast("找不到更新文件");
			updateInitLayout(true);
			return;
		}
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.setDataAndType(Uri.parse("file://" + apkFile.toString()),
				"application/vnd.android.package-archive");
		startActivity(intent);
	}

}
