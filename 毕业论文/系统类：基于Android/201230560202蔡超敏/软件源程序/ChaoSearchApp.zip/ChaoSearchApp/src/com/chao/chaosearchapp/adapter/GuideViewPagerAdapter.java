/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-10
 */
package com.chao.chaosearchapp.adapter;

import java.util.List;

import android.content.Intent;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.activity.ChaoBaseActivity;
import com.chao.chaosearchapp.activity.ChaoMainActivity;

/**
 * GuideActivity的ViewPager的适配器
 * 
 * @author chaoking
 * 
 */
public class GuideViewPagerAdapter extends PagerAdapter {
	// 界面列表
	private List<View> views;
	private ChaoBaseActivity activity;

	public GuideViewPagerAdapter(List<View> views, ChaoBaseActivity activity) {
		this.views = views;
		this.activity = activity;
	}

	// 销毁arg1位置的界面
	@Override
	public void destroyItem(View arg0, int arg1, Object arg2) {
		((ViewPager) arg0).removeView(views.get(arg1));
	}

	@Override
	public void finishUpdate(View arg0) {
	}

	// 获得当前界面数
	@Override
	public int getCount() {
		if (views != null) {
			return views.size();
		}
		return 0;
	}

	// 初始化arg1位置的界面
	@Override
	public Object instantiateItem(View arg0, int arg1) {
		((ViewPager) arg0).addView(views.get(arg1), 0);
		if (arg1 == views.size() - 1) {
			Button mStartChaoImageButton = (Button) arg0
					.findViewById(R.id.btn_start);
			mStartChaoImageButton.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					toSkipMainActivity();
				}

			});
		}
		return views.get(arg1);
	}

	/**
	 * 跳转到主界面
	 */
	private void toSkipMainActivity() {
		Log.d("LoadActivity", "跳转到主界面");
		Intent mainIntent = new Intent(activity, ChaoMainActivity.class);
		activity.startActivity(mainIntent);
		activity.finish();
	}

	// 判断是否由对象生成界面
	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return (arg0 == arg1);
	}

	@Override
	public void restoreState(Parcelable arg0, ClassLoader arg1) {
	}

	@Override
	public Parcelable saveState() {
		return null;
	}

	@Override
	public void startUpdate(View arg0) {
	}

}
