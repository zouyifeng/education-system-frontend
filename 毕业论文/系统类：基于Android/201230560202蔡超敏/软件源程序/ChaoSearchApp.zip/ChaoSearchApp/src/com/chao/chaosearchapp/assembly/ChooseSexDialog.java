/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-11
 */
package com.chao.chaosearchapp.assembly;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RadioButton;

import com.chao.chaosearchapp.R;

/**
 * @author chaoking
 * 
 */
public class ChooseSexDialog extends Dialog {
	// 先调用构造方法在调用oncreate方法
	private static boolean isShow = true;
	private Context context;

	private static int type = 0;
	private static boolean isWait = false;

	private static RadioButton rbMale;
	private static RadioButton rbFemale;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	public ChooseSexDialog(Context context) {
		super(context);
		this.context = context;
	}

	public ChooseSexDialog(Context context, int theme) {
		super(context, theme);
		this.context = context;
	}

	public void setMale(boolean flag) {
		type = flag ? 0 : 1;
	}
	
	public void checkSex() {
		if (type == 0) {
			rbMale.setChecked(true);
			rbFemale.setChecked(false);
		} else {
			rbFemale.setChecked(true);
			rbMale.setChecked(false);
		}
	}

	public void setFemale(boolean flag) {
		type = flag ? 1 : 0;
	}

	@Override
	public void show() {
		super.show();
	}

	// 点击确定及取消按钮是否要等待消失还是默认消失
	public void showWait(boolean isWait) {
		this.isWait = isWait;
		super.show();
	}

	public static class Builder {
		private Context context;
		private DialogInterface.OnClickListener maleButtonClickListener,
				femaleButtonClickListener;

		public Builder setMaleButton(DialogInterface.OnClickListener listener) {
			this.maleButtonClickListener = listener;
			return this;
		}

		public Builder setFemaleButton(DialogInterface.OnClickListener listener) {
			this.femaleButtonClickListener = listener;
			return this;
		}

		public boolean setCancelable(boolean cancelable) {

			isShow = cancelable;
			return isShow;
		}


		public Builder(Context context) {
			this.context = context;
		}

		public ChooseSexDialog show() {
			ChooseSexDialog dialog = create();
			dialog.show();
			return dialog;
		}

		public Builder setMale(boolean flag) {
			type = flag ? 0 : 1;
			return this;
		}

		public Builder setFemale(boolean flag) {
			type = flag ? 1 : 0;
			return this;
		}

		public ChooseSexDialog create() {
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

			// instantiate the dialog with the custom Theme
			final ChooseSexDialog dialog = new ChooseSexDialog(context,
					R.style.AppTheme_DialogStyle);
			dialog.setCanceledOnTouchOutside(true);

			View layout = inflater.inflate(R.layout.dialog_choose_sex, null);

			View btnMale = layout
					.findViewById(R.id.dialog_choose_sex_male_layout);
			View btnFemale = layout
					.findViewById(R.id.dialog_choose_sex_female_layout);

			rbMale = (RadioButton) layout
					.findViewById(R.id.dialog_choose_sex_male);
			rbFemale = (RadioButton) layout
					.findViewById(R.id.dialog_choose_sex_female);

			if (type == 0) {
				rbMale.setChecked(true);
				rbFemale.setChecked(false);
			} else {
				rbFemale.setChecked(true);
				rbMale.setChecked(false);
			}

			// set the confirm button
			btnMale.setOnClickListener(new View.OnClickListener() {

				public void onClick(View v) {

					maleButtonClickListener.onClick(dialog,
							DialogInterface.BUTTON_POSITIVE);
					if (!isWait)
						dialog.dismiss();
				}
			});
			rbMale.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					maleButtonClickListener.onClick(dialog,
							DialogInterface.BUTTON_POSITIVE);
					if (!isWait)
						dialog.dismiss();
				}
			});
			btnFemale.setOnClickListener(new View.OnClickListener() {

				public void onClick(View v) {

					femaleButtonClickListener.onClick(dialog,
							DialogInterface.BUTTON_POSITIVE);
					if (!isWait)
						dialog.dismiss();
				}
			});
			rbFemale.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					femaleButtonClickListener.onClick(dialog,
							DialogInterface.BUTTON_POSITIVE);
					if (!isWait)
						dialog.dismiss();
				}
			});

			dialog.setContentView(layout);

			Window dialogWindow = dialog.getWindow();
			WindowManager.LayoutParams lp = dialogWindow.getAttributes();

			WindowManager wm = ((Activity) context).getWindowManager();

			int width = wm.getDefaultDisplay().getWidth();

			lp.width = width * 4 / 5;

			dialogWindow.setAttributes(lp);

			dialog.setContentView(layout);
			return dialog;
		}
	}
}
