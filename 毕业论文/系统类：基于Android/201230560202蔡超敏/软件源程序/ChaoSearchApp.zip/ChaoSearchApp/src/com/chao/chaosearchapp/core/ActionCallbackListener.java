/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-12
 */
package com.chao.chaosearchapp.core;

/**
 * @author chaoking
 * 
 */
public interface ActionCallbackListener<T> {
	/**
	 * 成功时调用
	 * 
	 * @param data
	 *            返回的数据
	 */
	public void onSuccess(T data);

	/**
	 * 失败时调用
	 * 
	 * @param errorEvemt
	 *            错误码
	 * @param message
	 *            错误信息
	 */
	public void onFailure(String errorEvent, String message);
}
