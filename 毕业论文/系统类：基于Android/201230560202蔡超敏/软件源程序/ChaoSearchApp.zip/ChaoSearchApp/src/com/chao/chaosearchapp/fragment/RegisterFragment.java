/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-13
 */
package com.chao.chaosearchapp.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.core.ActionCallbackListener;

/**
 * @author chaoking
 * 
 */
public class RegisterFragment extends ChaoBaseFragment {

	private EditText phoneEdit;
	private EditText codeEdit;
	private EditText passwordEdit;
	private Button btnSendCode;
	private Button btnRegister;

	@Override
	protected View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_register, container,
				false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		phoneEdit = (EditText) view.findViewById(R.id.edit_phone);
		codeEdit = (EditText) view.findViewById(R.id.edit_code);
		passwordEdit = (EditText) view.findViewById(R.id.edit_password);
		btnSendCode = (Button) view.findViewById(R.id.btn_send_code);
		btnRegister = (Button) view.findViewById(R.id.btn_register);
	}

	@Override
	protected void initData() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void addListener() {
		btnSendCode.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				toSendCode(v);
			}
		});
		btnRegister.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				toRegister(v);
			}
		});
	}

	// 准备注册
	public void toRegister(View view) {
		String phoneNum = phoneEdit.getText().toString();
		String code = codeEdit.getText().toString();
		String password = passwordEdit.getText().toString();
		btnRegister.setEnabled(false);
		mActivity.appAction.register(phoneNum, code, password,
				new ActionCallbackListener<Void>() {
					@Override
					public void onSuccess(Void data) {
						makeToast("注册成功");
						// Intent intent = new Intent(mActivity,
						// CommoditySearchActivity.class);
						// startActivity(intent);
						mActivity.finish();
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						makeToast(message);
						btnRegister.setEnabled(true);
					}
				});
	}

	// 准备发送验证码
	public void toSendCode(View view) {
		String phoneNum = phoneEdit.getText().toString();
		btnSendCode.setEnabled(false);
		mActivity.appAction.sendSmsCode(phoneNum,
				new ActionCallbackListener<Void>() {
					@Override
					public void onSuccess(Void data) {
						makeToast("验证码已发送");
						btnSendCode.setEnabled(true);
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						Toast.makeText(mActivity, message, Toast.LENGTH_SHORT)
								.show();
						btnSendCode.setEnabled(true);
					}
				});
	}
}
