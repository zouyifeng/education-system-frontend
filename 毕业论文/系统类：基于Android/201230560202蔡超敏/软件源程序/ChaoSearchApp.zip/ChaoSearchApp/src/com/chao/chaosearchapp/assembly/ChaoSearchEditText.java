/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-13
 */
package com.chao.chaosearchapp.assembly;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.widget.EditText;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.listener.OnTextChangedListener;

/**
 * @author chaoking
 * 
 */
public class ChaoSearchEditText extends EditText implements
		OnFocusChangeListener, TextWatcher {

	/**
	 * 搜索按钮的引用
	 */
	private Drawable searchDrawable;
	/**
	 * 删除按钮的引用
	 */
	private Drawable clearDrawable;
	/**
	 * 语音识别按钮的引用
	 */
	private Drawable voiceRecognitionDrawable;
	/**
	 * 控件是否有焦点
	 */
	private boolean hasFoucs;

	/**
	 * EditText里面字符改变时调用的监听器
	 */
	private OnTextChangedListener onTextChangedListener;

	/**
	 * EditText语音识别调用的监听器
	 */
	private OnClickListener onVoiceRecognitionClickListener;

	// /**
	// * EidtText焦点获取监听器
	// */
	// private OnFocusChangeListener onFocusChangeListener;

	public void setOnVoiceRecognitionClickListener(OnClickListener listener) {
		onVoiceRecognitionClickListener = listener;
	}

	public void setOnTextChangedListener(OnTextChangedListener listener) {
		onTextChangedListener = listener;
	}

	// public void setOnFocusChangeListener(OnFocusChangeListener listener) {
	// onFocusChangeListener = listener;
	// }

	public ChaoSearchEditText(Context context) {
		this(context, null);
	}

	public ChaoSearchEditText(Context context, AttributeSet attrs) {
		this(context, attrs, android.R.attr.editTextStyle);
	}

	public ChaoSearchEditText(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);

		initSetting();

		initUI();
	}

	/**
	 * 初始化设置
	 */
	private void initSetting() {
		// //消除多次调用textchanged
		// setInputType(InputType.TYPE_CLASS_TEXT
		// | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
		// | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
	}

	/**
	 * 初始化ui
	 */
	private void initUI() {
		// 设置右边删除按钮
		// 获取EditText的DrawableRight,假如没有设置我们就使用默认的图片
		if (clearDrawable == null) {
			clearDrawable = getResources().getDrawable(
					R.drawable.btn_clear_text);
		}

		clearDrawable.setBounds(0, 0,
				(int) (clearDrawable.getIntrinsicWidth()),
				(int) (clearDrawable.getIntrinsicHeight()));

		searchDrawable = getCompoundDrawables()[0];
		if (searchDrawable == null) {
			searchDrawable = getResources().getDrawable(R.drawable.search);
		}

		searchDrawable.setBounds(0, 0,
				(int) (searchDrawable.getIntrinsicWidth()),
				(int) (searchDrawable.getIntrinsicHeight()));

		voiceRecognitionDrawable = getCompoundDrawables()[2];
		if (voiceRecognitionDrawable == null) {
			voiceRecognitionDrawable = getResources().getDrawable(
					R.drawable.voice_search);
		}

		voiceRecognitionDrawable.setBounds(0, 0,
				(int) (voiceRecognitionDrawable.getIntrinsicWidth()),
				(int) (voiceRecognitionDrawable.getIntrinsicHeight()));

		setClearIconVisible(false);
		// 设置焦点改变的监听
		setOnFocusChangeListener(this);
		// 设置输入框里面内容发生改变的监听
		addTextChangedListener(this);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_UP) {
			if (getCompoundDrawables()[2] == clearDrawable) {

				boolean touchable = event.getX() > (getWidth() - getTotalPaddingRight())
						&& (event.getX() < ((getWidth() - getPaddingRight())));

				if (touchable) {
					this.setText("");
				}
			} else if (getCompoundDrawables()[2] == voiceRecognitionDrawable) {

				boolean touchable = event.getX() > (getWidth() - getTotalPaddingRight())
						&& (event.getX() < ((getWidth() - getPaddingRight())));

				if (touchable) {
					// 语音识别搜索
					voiceRecognition();
				}
			}
		}
		return super.onTouchEvent(event);
	}

	/**
	 * 语音识别搜索
	 */
	private void voiceRecognition() {
		// TODO Auto-generated method stub
		Log.d("ChaoSearchEditText", "voiceRecognition_语音识别搜索");
		if (onVoiceRecognitionClickListener != null) {
			onVoiceRecognitionClickListener.onClick(this);
		}
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
		// TODO Auto-generated method stub

	}

	/**
	 * 当输入框里面内容发生变化后回调的方法
	 */
	@Override
	public void afterTextChanged(Editable s) {
		if (hasFoucs) {
			setClearIconVisible(s.length() > 0);
		}

		if (onTextChangedListener != null)
			onTextChangedListener.onTextChange(s.toString());
	}

	/**
	 * 当EditText焦点发生变化的时候，判断里面字符串长度设置清除图标的显示与隐藏
	 */
	@Override
	public void onFocusChange(View v, boolean hasFocus) {
		this.hasFoucs = hasFocus;
		if (hasFocus) {
			setClearIconVisible(getText().length() > 0);
		} else {
			setClearIconVisible(false);
		}
		// if (this.onFocusChangeListener != null)
		// this.onFocusChangeListener.onFocusChange(v, hasFocus);
	}

	@Override
	public void onTextChanged(CharSequence text, int start, int lengthBefore,
			int lengthAfter) {
	}

	/**
	 * 设置清除图标的显示与隐藏，调用setCompoundDrawables为EditText绘制上去
	 * 
	 * @param visible
	 */
	protected void setClearIconVisible(boolean visible) {
		Drawable right = visible ? clearDrawable : voiceRecognitionDrawable;
		if (searchDrawable != null && right != null)
			setCompoundDrawables(searchDrawable, getCompoundDrawables()[1],
					right, getCompoundDrawables()[3]);
		setCompoundDrawablePadding(5);
	}
}
