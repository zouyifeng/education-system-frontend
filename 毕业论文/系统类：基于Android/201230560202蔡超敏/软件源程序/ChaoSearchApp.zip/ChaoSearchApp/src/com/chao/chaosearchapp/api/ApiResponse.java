/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-12
 */
package com.chao.chaosearchapp.api;

/**
 * @author chaoking
 * 
 */
public class ApiResponse<T> {
	
	private String event; 		// 返回码，0为成功
	private String msg; 		// 返回信息
	private T obj; 				// 单个对象
	private T objList; 			// 数组对象
	private int currentPage; 	// 当前页数
	private int pageSize; 		// 每页显示数量
	private int maxCount; 		// 总条数
	private int maxPage; 		// 总页数

	// 构造函数，初始化code和msg
	public ApiResponse(String event, String msg) {
		this.event = event;
		this.msg = msg;
	}

	// 判断结果是否成功
	public boolean isSuccess() {
		return event.equals("0");
	}

	/**
	 * @return the event
	 */
	public String getEvent() {
		return event;
	}

	/**
	 * @param event
	 *            the event to set
	 */
	public void setEvent(String event) {
		this.event = event;
	}

	/**
	 * @return the msg
	 */
	public String getMsg() {
		return msg;
	}

	/**
	 * @param msg
	 *            the msg to set
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}

	/**
	 * @return the obj
	 */
	public T getObj() {
		return obj;
	}

	/**
	 * @param obj
	 *            the obj to set
	 */
	public void setObj(T obj) {
		this.obj = obj;
	}

	/**
	 * @return the objList
	 */
	public T getObjList() {
		return objList;
	}

	/**
	 * @param objList
	 *            the objList to set
	 */
	public void setObjList(T objList) {
		this.objList = objList;
	}

	/**
	 * @return the currentPage
	 */
	public int getCurrentPage() {
		return currentPage;
	}

	/**
	 * @param currentPage
	 *            the currentPage to set
	 */
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	/**
	 * @return the pageSize
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * @param pageSize
	 *            the pageSize to set
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * @return the maxCount
	 */
	public int getMaxCount() {
		return maxCount;
	}

	/**
	 * @param maxCount
	 *            the maxCount to set
	 */
	public void setMaxCount(int maxCount) {
		this.maxCount = maxCount;
	}

	/**
	 * @return the maxPage
	 */
	public int getMaxPage() {
		return maxPage;
	}

	/**
	 * @param maxPage
	 *            the maxPage to set
	 */
	public void setMaxPage(int maxPage) {
		this.maxPage = maxPage;
	}

}
