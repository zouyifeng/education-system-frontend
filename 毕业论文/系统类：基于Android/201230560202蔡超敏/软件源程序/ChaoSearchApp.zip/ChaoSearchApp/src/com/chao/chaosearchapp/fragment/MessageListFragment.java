/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-5-3
 */
package com.chao.chaosearchapp.fragment;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.activity.BrowserActivity;
import com.chao.chaosearchapp.activity.CommodityActivity;
import com.chao.chaosearchapp.activity.UpdateActivity;
import com.chao.chaosearchapp.adapter.MessageListAdapter;
import com.chao.chaosearchapp.assembly.PullToRefreshSliderListView;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.listener.OnObjectClickListener;
import com.chao.chaosearchapp.manager.MessageManager;
import com.chao.chaosearchapp.model.FeedbackBO;
import com.chao.chaosearchapp.model.MessageBO;
import com.handmark.pulltorefresh.library.PullToRefreshBase.Mode;

/**
 * @author chaoking
 * 
 */
public class MessageListFragment extends ChaoBaseFragment {

	private PullToRefreshSliderListView pullRefreshListView;
	private MessageListAdapter messageListAdapter;

	private TextView tvEmpty;

	@Override
	protected View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_message_list, container,
				false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		pullRefreshListView = (PullToRefreshSliderListView) view
				.findViewById(R.id.ptrflv_message_list);

		tvEmpty = (TextView) view.findViewById(R.id.message_list_empty);
	}

	@Override
	protected void initData() {
		// 这几个刷新Label的设置
		pullRefreshListView.setMode(Mode.BOTH);
		pullRefreshListView.getLoadingLayoutProxy().setPullLabel(null);
		pullRefreshListView.getLoadingLayoutProxy().setRefreshingLabel(null);
		pullRefreshListView.getLoadingLayoutProxy().setReleaseLabel(null);
		pullRefreshListView.getLoadingLayoutProxy().setLoadingDrawable(null);
		pullRefreshListView.getLoadingLayoutProxy().setLastUpdatedLabel(null);

		messageListAdapter = new MessageListAdapter(mActivity);
		pullRefreshListView.setAdapter(messageListAdapter);
		pullRefreshListView.setMode(Mode.BOTH);

		messageListAdapter.setItems(MessageManager.getMessages());

		if (messageListAdapter.isEmpty()) {
			tvEmpty.setVisibility(View.VISIBLE);
		}
	}

	@Override
	protected void addListener() {
		messageListAdapter
				.setOnDeleteClickListener(new OnObjectClickListener<MessageBO>() {

					@Override
					public void OnClick(View view, MessageBO obj) {
						messageListAdapter.getItems().remove(obj);
						MessageManager
								.setMessages((ArrayList<MessageBO>) messageListAdapter
										.getItems());
						messageListAdapter.notifyDataSetChanged();
						if (messageListAdapter.isEmpty()) {
							tvEmpty.setVisibility(View.VISIBLE);
						}
					}
				});
		pullRefreshListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				MessageBO messageBO = (MessageBO) messageListAdapter
						.getItem(position - 1);
				// Intent intent = new Intent(mActivity,
				// CommodityActivity.class);
				// intent.putExtra(Constants.KEY_COMMODITY_COMMODITYBO,
				// commodityBO);
				// // intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				// startActivityForResult(intent, 0);
				goToActivity(mActivity, messageBO.getTypeId(),
						messageBO.getId(), messageBO.getTitle(),
						messageBO.getContent());
			}
		});
	}

	/**
	 * @param typeId
	 * @param id
	 * @param content
	 * @param title
	 */
	private void goToActivity(Context context, int typeId, int id,
			String title, String content) {
		switch (typeId) {
		case 1:
			// 广告
			Intent aIntent = new Intent(context, BrowserActivity.class);
			aIntent.putExtra(Constants.KEY_BROWSER_TYPE, 11);
			aIntent.putExtra(Constants.KEY_BROWSER_ID, id);
			aIntent.putExtra(Constants.KEY_BROWSER_TITLE, content);
			aIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(aIntent);
			break;
		case 2:
			// 品牌
			Intent bIntent = new Intent(context, BrowserActivity.class);
			bIntent.putExtra(Constants.KEY_BROWSER_TYPE, 12);
			bIntent.putExtra(Constants.KEY_BROWSER_ID, id);
			bIntent.putExtra(Constants.KEY_BROWSER_TITLE, content);
			bIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(bIntent);
			break;
		case 3:
			// 商品
			Intent cIntent = new Intent(context, CommodityActivity.class);
			cIntent.putExtra(Constants.KEY_COMMODITY_TYPE, 1);
			cIntent.putExtra(Constants.KEY_COMMODITY_ID, id);
			cIntent.putExtra(Constants.KEY_COMMODITY_TITLE, content);
			cIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(cIntent);
			break;
		case 4:
			// 检查更新
			Intent updateIntent = new Intent(context, UpdateActivity.class);
			updateIntent.putExtra(Constants.KEY_UPDATE_TYPE, 1);
			updateIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(updateIntent);
			break;
		case 5:
			// 反馈
			// makeToast("id" + id);
			mActivity.appAction.getFeedback(id,
					new ActionCallbackListener<FeedbackBO>() {

						@Override
						public void onSuccess(FeedbackBO data) {
							if (data != null)
								makeToast(data.getFeedbackComment());
						}

						@Override
						public void onFailure(String errorEvent, String message) {
							makeToast(message);
						}
					});
			break;
		default:
			break;
		}
	}

}
