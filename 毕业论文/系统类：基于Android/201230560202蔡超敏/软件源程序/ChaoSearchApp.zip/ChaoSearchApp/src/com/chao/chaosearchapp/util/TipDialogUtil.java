/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-29
 */
package com.chao.chaosearchapp.util;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;

import com.chao.chaosearchapp.ChaoSearchApplication;
import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.activity.LoginActivity;
import com.chao.chaosearchapp.assembly.ChaoCustomDialog;

/**
 * @author chaoking
 * 
 */
public class TipDialogUtil {
	/**
	 * always_finish_activities 检查是否设置不保留活动
	 * 
	 * @param mcontext
	 * @author chaoking
	 */
	public static void checkIsAlwaysFinishActivities(final Context mContext) {
		int alwaysFinish = Settings.System.getInt(
				mContext.getContentResolver(),
				Settings.System.ALWAYS_FINISH_ACTIVITIES, 0);
		if (alwaysFinish == 1) {
			ChaoCustomDialog dialog = null;
			dialog = new ChaoCustomDialog.Builder(mContext)
					.setTitle("\"不保留活动\"选项设置")
					.setTitleColor(
							mContext.getResources().getColor(
									R.color.theme_background_red))
					.setMessage("检测到系统设置中的\"不保留活动\"选项被开启，为保证软件的正常运行，请您关闭此选项")
					.setNegativeButton("现在就去设置",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									Intent intent = new Intent(
											Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS);
									mContext.startActivity(intent);
								}
							})
					.setPositiveButton("下次再说",
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									dialog.dismiss();
								}
							}).create();
			dialog.setCancelable(false);
			dialog.setCanceledOnTouchOutside(false);
			dialog.show();
		}
	}

	/**
	 * 是否拨打客服电话dialog
	 * 
	 * @param Context
	 */
	public static void showContactService(final Context mContext) {
		ChaoCustomDialog dialog = null;
		dialog = new ChaoCustomDialog.Builder(mContext)
				.setMessage("是否拨打客服电话" + Constants.CUSTOMER_SERVICE_PHONE)
				.setMessageColor(
						mContext.getResources().getColor(
								R.color.theme_background_red))
				.setNegativeButton("否", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {

					}
				})
				.setPositiveButton("是", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						Intent intent = new Intent(Intent.ACTION_CALL, Uri
								.parse("tel:"
										+ Constants.CUSTOMER_SERVICE_PHONE));
						mContext.startActivity(intent);
					}
				}).create();
		dialog.show();
	}

	// /**
	// * 登录冲突,异地登录
	// *
	// * @param midouHandler
	// */
	// public static void showLoginConflict(final MidouHandler midouHandler) {
	// ChaoCustomDialog dialog = null;
	// dialog = new ChaoCustomDialog.Builder(App.getCurActivity())
	// .setMessage("您已在其他设备登录,是否重新登录?")
	// .setNegativeButton("退出应用",
	// new DialogInterface.OnClickListener() {
	// @Override
	// public void onClick(DialogInterface dialog,
	// int which) {
	// // level 3 以上才可以用
	// // ActivityManager am = (ActivityManager)
	// // App.getCurActivity()
	// // .getSystemService(Context.ACTIVITY_SERVICE);
	// // am.restartPackage(App.getCurActivity().getPackageName());
	// if (App.getCurActivity() instanceof TchyMainActivity) {
	// App.getCurActivity().finish();
	// } else {
	// Intent intent = new Intent(App
	// .getCurActivity(),
	// TchyMainActivity.class);
	// intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // 注意本行的FLAG设置
	// App.getCurActivity().startActivity(intent);
	// }
	// }
	// })
	// .setPositiveButton("重新登录",
	// new DialogInterface.OnClickListener() {
	// @Override
	// public void onClick(DialogInterface dialog,
	// int which) {
	// midouHandler.connectService();
	// }
	// }).create();
	// dialog.setCancelable(false);
	// dialog.setCanceledOnTouchOutside(false);
	// dialog.show();
	// }

	public static void showUserBoundDialog() {
		ChaoCustomDialog dialog = null;
		dialog = new ChaoCustomDialog.Builder(
				ChaoSearchApplication.getCurActivity())
				.setMessage("绑定手机号,开放更多功能。是否绑定？")
				.setNegativeButton("是", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						ChaoSearchApplication.getCurActivity()
								.startActivity(
										new Intent(ChaoSearchApplication
												.getCurActivity(),
												LoginActivity.class));
						dialog.dismiss();
					}
				})
				.setPositiveButton("否", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				}).create();
		dialog.show();
	}

	// /**
	// * 展现是否设置GPS定位设置
	// *
	// * @param activity
	// */
	// public static void showSetingGPSDialog(final Context context) {
	// ChaoCustomDialog dialog = null;
	// dialog = new ChaoCustomDialog.Builder(App.getCurActivity())
	// .setMessage("是否开启GPS定位设置,使用GPS不会消耗流量？")
	// .setNegativeButton("否", new DialogInterface.OnClickListener() {
	// @Override
	// public void onClick(DialogInterface dialog, int which) {
	// dialog.dismiss();
	// }
	// })
	// .setPositiveButton("是", new DialogInterface.OnClickListener() {
	// @Override
	// public void onClick(DialogInterface dialog, int which) {
	// AppUtil.startToLocationSourceSettings((Activity) context);
	// dialog.dismiss();
	// }
	// }).create();
	// dialog.show();
	// }
}
