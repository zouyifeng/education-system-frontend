/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-26
 */
package com.chao.chaosearchapp.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.activity.LoginActivity;
import com.chao.chaosearchapp.assembly.ChaoActionBar.ChaoActionBarCallBack;
import com.chao.chaosearchapp.assembly.filter.CustomFilter;
import com.chao.chaosearchapp.assembly.filter.CustomFilter.onFullAndillegalListener;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.manager.UserManager;
import com.handmark.pulltorefresh.library.PullToRefreshScrollView;

/**
 * @author chaoking
 * 
 */
public class FeedbackFragment extends ChaoBaseFragment {

	private ViewHolder holder;

	@Override
	protected View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_feedback, container,
				false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		holder = new ViewHolder(view);
	}

	@Override
	protected void initData() {

		// 这几个刷新Label的设置
		holder.refreshScrollView.getLoadingLayoutProxy().setPullLabel(null);
		holder.refreshScrollView.getLoadingLayoutProxy().setRefreshingLabel(
				null);
		holder.refreshScrollView.getLoadingLayoutProxy().setReleaseLabel(null);
		holder.refreshScrollView.getLoadingLayoutProxy().setLoadingDrawable(
				null);

		CustomFilter commentFilter = new CustomFilter(200);
		holder.tvCommentSize.setText(String.valueOf(200));
		commentFilter
				.setOnFullAndillegalListener(new onFullAndillegalListener() {

					@Override
					public void onChange(int num) {
						holder.tvCommentSize.setText(String.valueOf(num));
					}

					@Override
					public void isIllegal() {
						// TODO Auto-generated method stub

					}

					@Override
					public void isFull() {
						// TODO Auto-generated method stub

					}
				});

		holder.evTitle.setFilters(new InputFilter[] { new CustomFilter(20) });
		holder.evComment.setFilters(new InputFilter[] { commentFilter });
	}

	@Override
	protected void addListener() {
		mActivity.getChaoActionBar().addChaoActionBarCallBack(
				new ChaoActionBarCallBack() {

					@Override
					public void onSubmenuClickCallBack(Button submenubtn) {
						if (!UserManager.isBingAccount()) {
							makeToast("请登录后反馈");
							Intent intent = new Intent(mActivity,
									LoginActivity.class);
							startActivity(intent);
							return;
						}
						mActivity.appAction.sendComment(holder.evTitle
								.getText().toString(), holder.evComment
								.getText().toString(),
								new ActionCallbackListener<Void>() {

									@Override
									public void onSuccess(Void data) {
										makeToast("提交成功");
										mActivity.finish();
									}

									@Override
									public void onFailure(String errorEvent,
											String message) {
										makeToast(message);
									}
								});
					}

					@Override
					public void onHomeClickCallBack(Button homebtn) {
						mActivity.finish();
					}
				});
	}

	static class ViewHolder {
		EditText evTitle;
		EditText evComment;
		TextView tvCommentSize;
		PullToRefreshScrollView refreshScrollView;

		public ViewHolder(View view) {
			evTitle = (EditText) view.findViewById(R.id.feedback_comment_title);
			evComment = (EditText) view.findViewById(R.id.feedback_comment);
			tvCommentSize = (TextView) view
					.findViewById(R.id.feedback_comment_size);
			refreshScrollView = (PullToRefreshScrollView) view
					.findViewById(R.id.feedback_scrollview);
		}
	}

}
