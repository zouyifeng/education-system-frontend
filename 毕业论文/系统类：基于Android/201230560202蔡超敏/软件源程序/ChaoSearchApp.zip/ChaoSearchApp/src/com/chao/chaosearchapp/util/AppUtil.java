/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-24
 */
package com.chao.chaosearchapp.util;

import java.io.UnsupportedEncodingException;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.util.TypedValue;
import android.view.inputmethod.InputMethodManager;

import com.chao.chaosearchapp.model.MessageBO;

/**
 * @author chaoking
 * 
 */
public class AppUtil {
	public static int dpToPx(int dp, Resources resources) {
		return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
				resources.getDisplayMetrics());
	}

	// 获得字母、数字、空格的个数
	public static int getCharacterBlankNumberCount(String s) {
		char ch;
		int character = 0, blank = 0, number = 0;
		for (int i = 0; i < s.length(); i++) {
			ch = s.charAt(i);
			if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))// 统计字母
				character++; // 等同于character=character+1
			else if (ch == ' ') // 统计空格
				blank++; // 等同于blank=blank+1
			else if (ch >= '0' && ch <= '9') // 统计数字
				number++; // 等同于number=number+1;
		}
		return character + blank + number;
	}

	// 获得汉字的长度
	public static int getChineseCount(String s) {
		char c;
		int chineseCount = 0;
		if (!"".equals("")) {// 判断是否为空
			try {
				s = new String(s.getBytes(), "GBK");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // 进行统一编码
		}
		for (int i = 0; i < s.length(); i++) {
			c = s.charAt(i); // 获得字符串中的每个字符
			try {
				if (isChineseChar(c)) {// 调用方法进行判断是否是汉字
					chineseCount++; // 等同于chineseCount=chineseCount+1
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return chineseCount; // 返回汉字个数
	}

	// 判断是否是一个汉字
	public static boolean isChineseChar(char c) throws Exception {
		return String.valueOf(c).getBytes("GBK").length > 1;// 汉字的字节数大于1
	}

	/**
	 * 关闭软键盘
	 * 
	 * @param activity
	 * @param flags
	 *            InputMethodManager 参数
	 */
	public static void hideSoftInputMethod(Activity activity) {
		if (activity != null) {
			InputMethodManager imm = (InputMethodManager) activity
					.getSystemService(Context.INPUT_METHOD_SERVICE);
			if (imm.isActive() && activity.getCurrentFocus() != null) {
				if (activity.getCurrentFocus().getWindowToken() != null) {
					imm.hideSoftInputFromWindow(activity.getCurrentFocus()
							.getWindowToken(),
							InputMethodManager.HIDE_IMPLICIT_ONLY);
				}
			}
		}
	}

	public static List<String> removeDuplicate(List<String> list) {
		Set<String> set = new LinkedHashSet<String>();
		set.addAll(list);
		list.clear();
		list.addAll(set);
		return list;
	}

	public static List<MessageBO> removeMessageBODuplicate(List<MessageBO> list) {
		Set<MessageBO> set = new LinkedHashSet<MessageBO>();
		set.addAll(list);
		list.clear();
		list.addAll(set);
		return list;
	}

	/**
	 * 是否为手机号
	 * 
	 * @param mobiles
	 * @return
	 */
	public static boolean isMobileNO(String mobiles) {

		Pattern p = Pattern
				.compile("^((13[0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$");

		Matcher m = p.matcher(mobiles);

		System.out.println(m.matches() + "---");

		return m.matches();
	}
}
