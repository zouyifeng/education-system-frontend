/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-29
 */
package com.chao.chaosearchapp.fragment;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore.Images;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.activity.FeedbackActivity;
import com.chao.chaosearchapp.activity.ShowAboutActivity;

/**
 * @author chaoking
 * 
 */
public class AboutFragment extends ChaoBaseFragment {

	private ViewHolder holder;

	@Override
	protected View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_about, container, false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		holder = new ViewHolder(view);
	}

	@Override
	protected void initData() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void addListener() {
		holder.vFeedback.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startActivity(new Intent(mActivity, FeedbackActivity.class));
			}
		});
		holder.vShareApp.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				shareMsg(
						"请选择",
						"分享",
						"http://test.fatwo.cn:8080/price/commodity/commodities",
						null);
			}
		});
		holder.vFunction.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mActivity, ShowAboutActivity.class);
				intent.putExtra(Constants.KEY_SHOWUS_ID, 1);
				startActivity(intent);

			}
		});
		holder.vAboutUs.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mActivity, ShowAboutActivity.class);
				intent.putExtra(Constants.KEY_SHOWUS_ID, 2);
				startActivity(intent);
			}
		});
	}

	/**
	 * 分享功能
	 * 
	 * @param context
	 *            上下文
	 * @param activityTitle
	 *            Activity的名字
	 * @param msgTitle
	 *            消息标题
	 * @param msgText
	 *            消息内容
	 * @param imgPath
	 *            图片路径，不分享图片则传null
	 */
	public void shareMsg(String title, String msgTitle, String msgText,
			String imgPath) {
		Intent intent = new Intent(Intent.ACTION_SEND);
		if (imgPath == null || imgPath.equals("")) {
			intent.setType("text/plain"); // 纯文本
		} else {
			if (imgPath != null && !"".equals(imgPath)) {
				Uri imageUri = null;
				Cursor c = mActivity.getContentResolver().query(
						Images.Media.EXTERNAL_CONTENT_URI, null, null, null,
						null);
				if (c != null) {
					if (c.moveToFirst()) {
						do {
							long id = c.getLong(c
									.getColumnIndex(Images.Media._ID));
							imageUri = Uri
									.parse(Images.Media.EXTERNAL_CONTENT_URI
											+ "/" + id);
							break;
						} while (c.moveToNext());
					}
				}
				c.close();
				c = null;

				intent.putExtra(Intent.EXTRA_STREAM, imageUri);
				intent.setType("image/*");
			} else {
				makeToast("找不到图片");
				intent.setType("text/plain"); // 纯文本
			}
		}
		intent.putExtra(Intent.EXTRA_SUBJECT, msgTitle);
		intent.putExtra(Intent.EXTRA_TEXT, msgText);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(Intent.createChooser(intent, title));
	}

	static class ViewHolder {
		View vFunction;
		View vFeedback;
		View vShareApp;
		View vAboutUs;

		public ViewHolder(View view) {
			vFunction = view.findViewById(R.id.about_show_function);
			vFeedback = view.findViewById(R.id.about_feedback);
			vShareApp = view.findViewById(R.id.about_share_app);
			vAboutUs = view.findViewById(R.id.about_show_us);
		}
	}

}
