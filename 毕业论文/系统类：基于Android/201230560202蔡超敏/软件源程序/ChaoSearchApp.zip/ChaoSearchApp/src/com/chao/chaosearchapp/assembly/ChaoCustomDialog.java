/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-29
 */
package com.chao.chaosearchapp.assembly;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.chao.chaosearchapp.R;

/**
 * @author chaoking
 * 
 */
public class ChaoCustomDialog extends Dialog {
	// 先调用构造方法在调用oncreate方法
	private static boolean isShow = true;
	private Context context;

	private static boolean isWait = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	public ChaoCustomDialog(Context context) {
		super(context);
		this.context = context;
	}

	public ChaoCustomDialog(Context context, int theme) {
		super(context, theme);
		this.context = context;
	}

	@Override
	public void show() {
		super.show();
	}

	// 点击确定及取消按钮是否要等待消失还是默认消失
	public void showWait(boolean isWait) {
		this.isWait = isWait;
		super.show();
	}

	public static class Builder {
		private Context context;
		private CharSequence title;
		private CharSequence message;
		private CharSequence positiveButtonText;
		private CharSequence negativeButtonText;
		private DialogInterface.OnClickListener positiveButtonClickListener,
				negativeButtonClickListener;

		private int titleColor, messageColor;

		// private TextView msg=(TextView)findViewById(R.id.message);
		public Builder(Context context) {
			this.context = context;
		}

		public Builder setTitle(CharSequence title) {
			this.title = title;
			return this;
		}

		public Builder setTitle(int title) {
			this.title = (CharSequence) context.getText(title);
			return this;
		}

		public Builder setTitleColor(int color) {
			this.titleColor = color;
			return this;
		}

		public Builder setMessage(CharSequence message) {
			this.message = message;
			return this;
		}

		public Builder setMessage(int message) {
			this.message = (CharSequence) context.getText(message);
			return this;
		}

		public Builder setMessageColor(int color) {
			this.messageColor = color;
			return this;
		}

		public Builder setPositiveButton(int positiveButtonText,
				DialogInterface.OnClickListener listener) {
			this.positiveButtonText = (CharSequence) context
					.getText(positiveButtonText);
			this.positiveButtonClickListener = listener;
			return this;
		}

		public Builder setPositiveButton(CharSequence positiveButtonText,
				DialogInterface.OnClickListener listener) {
			this.positiveButtonText = positiveButtonText;
			this.positiveButtonClickListener = listener;
			return this;
		}

		public boolean setCancelable(boolean cancelable) {

			isShow = cancelable;
			return isShow;
		}

		public Builder setNegativeButton(int negativeButtonText,
				DialogInterface.OnClickListener listener) {
			this.negativeButtonText = (CharSequence) context
					.getText(negativeButtonText);
			this.negativeButtonClickListener = listener;
			return this;
		}

		public Builder setNegativeButton(CharSequence negativeButtonText,
				DialogInterface.OnClickListener listener) {
			this.negativeButtonText = negativeButtonText;
			this.negativeButtonClickListener = listener;
			return this;
		}

		public ChaoCustomDialog show() {
			ChaoCustomDialog dialog = create();
			dialog.show();
			return dialog;
		}

		public ChaoCustomDialog create() {
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

			// instantiate the dialog with the custom Theme
			final ChaoCustomDialog dialog = new ChaoCustomDialog(context,
					R.style.AppTheme_DialogStyle);
			dialog.setCanceledOnTouchOutside(true);

			View layout = inflater.inflate(R.layout.dialog_custom, null);

			// SET TITLE 默认是gone
			if (title != null && !"".equals(title)) {
				layout.findViewById(R.id.custom_dialog_title_line)
						.setVisibility(View.VISIBLE);
				TextView tvTitle = ((TextView) layout
						.findViewById(R.id.custom_dialog_title));
				tvTitle.setVisibility(View.VISIBLE);
				tvTitle.setText(title);
				tvTitle.setTextColor(titleColor);
			}

			TextView tvContent = ((TextView) layout
					.findViewById(R.id.custom_dialog_text));
			Button btnOk = ((Button) layout
					.findViewById(R.id.custom_dialog_btn_left));
			Button btnCancel = ((Button) layout
					.findViewById(R.id.custom_dialog_btn_right));

			if (message != null && !"".equals(message)) {
				tvContent.setText(Html.fromHtml(String.valueOf(message)));
				if (messageColor != 0)
					tvContent.setTextColor(messageColor);
				tvContent.setVisibility(View.VISIBLE);
			}

			// set the confirm button
			if (positiveButtonText != null) {

				btnOk.setText(positiveButtonText);

				if (positiveButtonClickListener != null) {

					btnOk.setOnClickListener(new View.OnClickListener() {

						public void onClick(View v) {

							positiveButtonClickListener.onClick(dialog,
									DialogInterface.BUTTON_POSITIVE);
							if (!isWait)
								dialog.dismiss();
						}
					});
				}
			} else {
				btnOk.setVisibility(View.GONE);
			}
			if (negativeButtonText != null) {

				btnCancel.setText(negativeButtonText);
				if (negativeButtonClickListener != null) {
					btnCancel.setOnClickListener(new View.OnClickListener() {

						public void onClick(View v) {

							negativeButtonClickListener.onClick(dialog,
									DialogInterface.BUTTON_NEGATIVE);
							if (!isWait)
								dialog.dismiss();
						}
					});
				}
			} else {
				btnCancel.setVisibility(View.GONE);
			}

			dialog.setContentView(layout);

			Window dialogWindow = dialog.getWindow();
			WindowManager.LayoutParams lp = dialogWindow.getAttributes();

			WindowManager wm = ((Activity) context).getWindowManager();

			int width = wm.getDefaultDisplay().getWidth();
			int height = wm.getDefaultDisplay().getHeight();

			lp.width = width * 4 / 5;
			if (title != null && !"".equals(title)) {
				lp.height = height * 2 / 5;
			} else {
				lp.height = height * 1 / 4;
			}

			dialogWindow.setAttributes(lp);

			dialog.setContentView(layout);
			return dialog;
		}

	}
}
