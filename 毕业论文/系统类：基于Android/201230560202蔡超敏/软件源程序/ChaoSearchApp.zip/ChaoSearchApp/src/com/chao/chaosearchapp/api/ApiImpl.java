/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-12
 */
package com.chao.chaosearchapp.api;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.chao.chaosearchapp.model.AdvertisementBO;
import com.chao.chaosearchapp.model.AppInfoBO;
import com.chao.chaosearchapp.model.BrandBO;
import com.chao.chaosearchapp.model.CommodityBO;
import com.chao.chaosearchapp.model.FeedbackBO;
import com.chao.chaosearchapp.model.HistoryKeywordBO;
import com.chao.chaosearchapp.model.PriceBO;
import com.chao.chaosearchapp.model.RecommendKeywordBO;
import com.chao.chaosearchapp.model.UserBO;
import com.chao.chaosearchapp.util.EncryptUtil;
import com.chao.chaosearchapp.util.MD5Util;
import com.google.gson.reflect.TypeToken;

/**
 * @author chaoking
 * 
 */
public class ApiImpl implements Api {
	private final static String APP_KEY = "ANDROID_KCOMMODITY";
	private final static String TIME_OUT_EVENT = "CONNECT_TIME_OUT";
	private final static String TIME_OUT_EVENT_MSG = "连接服务器失败";
	// http引擎
	private HttpEngine httpEngine;

	public ApiImpl() {
		httpEngine = HttpEngine.getInstance();
	}

	@Override
	public ApiResponse<Void> sendSmsCode4Register(String phoneNum) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("appKey", APP_KEY);
		paramMap.put("method", SEND_SMS_CODE);
		paramMap.put("phoneNum", phoneNum);

		Type type = new TypeToken<ApiResponse<Void>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.SEND_SMS_CODE, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<Void> registerByPhone(String phoneNum, String code,
			String password) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("phone", phoneNum);
		paramMap.put("status", String.valueOf(1));
		paramMap.put("type", String.valueOf(2));
		// paramMap.put("code", code);
		paramMap.put("password", EncryptUtil.md5(password));

		Type type = new TypeToken<ApiResponse<Void>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.REGISTER, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<UserBO> loginByApp(String loginName, String password,
			String imei, int loginOS) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("phone", loginName);
		paramMap.put("password", password);
		paramMap.put("imei", imei);
		paramMap.put("loginos", String.valueOf(loginOS));
		Type type = new TypeToken<ApiResponse<UserBO>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.LOGIN, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse<UserBO>(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<List<CommodityBO>> listCommodity(int pageNum,
			int pageSize, String name, String introduce, String userId) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("pageNum", String.valueOf(pageNum));
		paramMap.put("pageSize", String.valueOf(pageSize));
		paramMap.put("name", name);
		paramMap.put("introduce", introduce);
		paramMap.put("userId", userId);

		Type type = new TypeToken<ApiResponse<List<CommodityBO>>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.LIST_COMMODITY, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<List<CommodityBO>> listRecommendCommodity(int pageNum,
			int pageSize, String userId) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("pageNum", String.valueOf(pageNum));
		paramMap.put("pageSize", String.valueOf(pageSize));
		paramMap.put("userId", userId);

		Type type = new TypeToken<ApiResponse<List<CommodityBO>>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.LIST_RECOMMEND_COMMODITY,
					paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<RecommendKeywordBO> getRecommendKeyword(String userId) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("userId", userId);

		Type type = new TypeToken<ApiResponse<RecommendKeywordBO>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.LIST_RECOMMEND_KEYWORD, paramMap,
					type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<List<HistoryKeywordBO>> getHistorySearchKeyword(
			String userId) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("userId", userId);

		Type type = new TypeToken<ApiResponse<List<HistoryKeywordBO>>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.LIST_HISTORY_SEARCH_KEYWORD,
					paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<List<CommodityBO>> listCollection(int pageNum,
			int pageSize, String userId) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("pageNum", String.valueOf(pageNum));
		paramMap.put("pageSize", String.valueOf(pageSize));
		paramMap.put("userId", userId);

		Type type = new TypeToken<ApiResponse<List<CommodityBO>>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.LIST_COLLECTION, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<Void> collectCommodity(String userId, int typeId,
			int type) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("userId", userId);
		paramMap.put("typeId", String.valueOf(typeId));
		paramMap.put("type", String.valueOf(type));

		Type typeToken = new TypeToken<ApiResponse<Void>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.COLLECT_COMMODITY, paramMap,
					typeToken);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<Void> cancelCollectCommodity(String userId, int typeId,
			int type) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("_method", "DELETE");
		paramMap.put("userId", userId);
		paramMap.put("typeId", String.valueOf(typeId));
		paramMap.put("type", String.valueOf(type));

		Type typeToken = new TypeToken<ApiResponse<Void>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.COLLECT_COMMODITY, paramMap,
					typeToken);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<List<AdvertisementBO>> listAdvertisement(int placeNum) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("_method", "GET");
		paramMap.put("placeNum", String.valueOf(placeNum));

		Type type = new TypeToken<ApiResponse<List<AdvertisementBO>>>() {
		}.getType();
		try {
			return httpEngine
					.postHandle(Api.LIST_ADVERTISEMENT, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<AppInfoBO> getVersionInfo(String imei, String version) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("_method", "GET");
		paramMap.put("imei", imei);
		paramMap.put("version", version);

		Type type = new TypeToken<ApiResponse<AppInfoBO>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.VERSION_INFO, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<Void> clearHistorySearchKeyword(String userId) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("_method", "DELETE");
		paramMap.put("userId", userId);

		Type type = new TypeToken<ApiResponse<Void>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.CLEAR_HISTORY_SEARCH_KEYWORD,
					paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<Void> changeUserInfo(UserBO user, int loginOS) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("_method", "PUT");
		if (user.getName() != null && !"".equals(user.getName())) {
			paramMap.put("name", user.getName());
		}
		if (user.getRealName() != null && !"".equals(user.getRealName())) {
			paramMap.put("realName", user.getRealName());
		}
		if (user.getEmail() != null && !"".equals(user.getEmail())) {
			paramMap.put("email", user.getEmail());
		}
		if (user.getBirthday() != null && !"".equals(user.getBirthday())) {
			paramMap.put("birthday", user.getBirthday());
		}
		if (user.getSex() != null && !"".equals(user.getSex())) {
			paramMap.put("sex", user.getSex());
		}
		paramMap.put("id", String.valueOf(user.getId()));
		paramMap.put("loginos", String.valueOf(loginOS));

		Type type = new TypeToken<ApiResponse<Void>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.CHANGE_USER_INFO, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<Void> changeUserPassword(String userId, String password,
			int loginOS) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("_method", "PUT");
		paramMap.put("password", password);
		paramMap.put("id", userId);
		paramMap.put("loginos", String.valueOf(loginOS));

		Type type = new TypeToken<ApiResponse<Void>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.CHANGE_USER_PASSWORD, paramMap,
					type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<Void> sendComment(String userId, String title,
			String comment) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("userId", userId);
		paramMap.put("title", title);
		paramMap.put("comment", comment);

		Type type = new TypeToken<ApiResponse<Void>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.SEND_COMMENT, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<AdvertisementBO> getAdvertisement(int id) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("_method", "GET");
		paramMap.put("id", String.valueOf(id));

		Type type = new TypeToken<ApiResponse<AdvertisementBO>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.ADVERTISEMENT_BY_ID, paramMap,
					type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<BrandBO> getBrand(int id) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("_method", "GET");
		paramMap.put("id", String.valueOf(id));

		Type type = new TypeToken<ApiResponse<BrandBO>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.ADVERTISEMENT_BY_ID, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<CommodityBO> getCommodity(String userId, int id) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("_method", "GET");
		paramMap.put("userId", userId);
		paramMap.put("id", String.valueOf(id));

		Type type = new TypeToken<ApiResponse<CommodityBO>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.COMMODITY_BY_ID, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<PriceBO> getPrice(String userId, int id) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("_method", "GET");
		paramMap.put("userId", userId);
		paramMap.put("priceId", String.valueOf(id));

		Type type = new TypeToken<ApiResponse<PriceBO>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.PRICE_BY_ID, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<FeedbackBO> getFeedback(int id) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("_method", "GET");
		paramMap.put("id", String.valueOf(id));

		Type type = new TypeToken<ApiResponse<FeedbackBO>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.FEEDBACK_BY_ID, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

	@Override
	public ApiResponse<List<BrandBO>> listBrand(int placeNum) {
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("_method", "GET");
		paramMap.put("placeNum", String.valueOf(placeNum));

		Type type = new TypeToken<ApiResponse<List<BrandBO>>>() {
		}.getType();
		try {
			return httpEngine.postHandle(Api.LIST_BRAND, paramMap, type);
		} catch (IOException e) {
			return new ApiResponse(TIME_OUT_EVENT, TIME_OUT_EVENT_MSG);
		}
	}

}
