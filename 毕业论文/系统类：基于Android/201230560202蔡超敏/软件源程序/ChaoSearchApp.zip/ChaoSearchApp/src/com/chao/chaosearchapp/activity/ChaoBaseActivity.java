/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-12
 */
package com.chao.chaosearchapp.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.chao.chaosearchapp.ChaoSearchApplication;
import com.chao.chaosearchapp.assembly.ChaoActionBar;
import com.chao.chaosearchapp.assembly.ChaoActionBar.ChaoActionBarCallBack;
import com.chao.chaosearchapp.assembly.ChaoLoadingDialog;
import com.chao.chaosearchapp.core.AppAction;
import com.chao.chaosearchapp.listener.OnAppActionSessionListener;
import com.iflytek.sunflower.FlowerCollector;
import com.litesuits.common.assist.Network;

/**
 * @author chaoking
 * 
 */
public abstract class ChaoBaseActivity extends FragmentActivity implements
		OnAppActionSessionListener {
	// 上下文实例
	public Context context;
	// 应用全局的实例
	public ChaoSearchApplication application;
	// 核心层的Action实例
	public AppAction appAction;

	// actionBar
	private ChaoActionBar chaoActionBar;

	private long curClickTimeMillis = 0;

	private ChaoLoadingDialog mLoadingDialog;

	public static boolean isForeground = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		context = getApplicationContext();
		application = (ChaoSearchApplication) this.getApplication();
		appAction = application.getAppAction();
		appAction.setOnAppActionSessionListener(this);

		if (mLoadingDialog == null) {
			mLoadingDialog = new ChaoLoadingDialog(this);
			mLoadingDialog
					.setOnDismissListener(getOnLoadingDialogDismissListener());
		}

	}

	@Override
	public void setContentView(int layoutResID) {
		super.setContentView(layoutResID);

		initChaoActionBar();
		initViews();
		initData();
		addListener();
	}

	/**
	 * 初始化组件
	 */
	protected abstract void initViews();

	/**
	 * 初始化数据
	 */
	protected abstract void initData();

	/**
	 * 添加监听器
	 */
	protected abstract void addListener();

	/**
	 * 设置网络提示
	 */
	public void setNetworkTip() {
		if (!ChaoSearchApplication.networkTip.isShow())
			if (Network.isConnectedOrConnecting(ChaoSearchApplication
					.getContext())) {
				ChaoSearchApplication.networkTip.setShow(false);
			} else {
				ChaoSearchApplication.networkTip.setShow(true);
				ChaoSearchApplication.networkTip.setTip("网络请求失败，请检查您的网络设置");
				ChaoSearchApplication.networkTip
						.setClickListener(new OnClickListener() {

							@Override
							public void onClick(View v) {
								Intent wifiSettingsIntent = new Intent(
										"android.settings.WIFI_SETTINGS");
								startActivity(wifiSettingsIntent);
							}
						});
			}
	}

	private void initChaoActionBar() {
		chaoActionBar = (ChaoActionBar) findViewById(setChaoActionBarId());
		if (chaoActionBar != null)
			chaoActionBar.addChaoActionBarCallBack(addChaoActionBarCallBack());
	}

	/**
	 * 增加导航栏回调点击事件
	 * 
	 * @return
	 */
	protected ChaoActionBarCallBack addChaoActionBarCallBack() {
		return null;
	}

	abstract protected int setChaoActionBarId();

	public ChaoActionBar getChaoActionBar() {
		return chaoActionBar;
	}

	/** 是否点击了多次 小于1秒当作是多次点击了 **/
	protected boolean isMultiplicationClick() {
		if (curClickTimeMillis == 0) {
			curClickTimeMillis = System.currentTimeMillis();
			return false;
		}
		boolean rs = System.currentTimeMillis() - curClickTimeMillis < 1000;
		curClickTimeMillis = System.currentTimeMillis();
		return rs;
	}

	/**
	 * 浮动显示信息
	 * 
	 * @param text
	 */
	public void makeToast(String text) {
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}

	public void showLoadingDialog(String text) {
		if (text != null && !"".equals(text) && mLoadingDialog != null
				&& !mLoadingDialog.isShowing())
			mLoadingDialog.show(text);
	}

	public void dismissLoadingDialog() {

		if (mLoadingDialog != null && mLoadingDialog.isShowing())
			mLoadingDialog.dismiss();
	}

	protected OnDismissListener getOnLoadingDialogDismissListener() {
		return new OnDismissListener() {

			@Override
			public void onDismiss(DialogInterface dialog) {
			}
		};
	}

	@Override
	public void onAppActionSessionOpen(String text) {
		if (getChaoActionBar() != null) {
			getChaoActionBar().showProgressBar(true);
		}
		showLoadingDialog(text);
	}

	@Override
	public void onAppActionSessionClose() {
		if (getChaoActionBar() != null) {
			getChaoActionBar().showProgressBar(false);
		}
		dismissLoadingDialog();
	}

	@Override
	protected void onResume() {

		isForeground = true;
		// 开放统计 移动数据统计分析
		FlowerCollector.onResume(ChaoBaseActivity.this);
		FlowerCollector.onPageStart("ChaoBaseActivity");
		super.onResume();
		ChaoSearchApplication.setCurActivity(this);

		setNetworkTip();
	}

	@Override
	protected void onPause() {
		// 开放统计 移动数据统计分析
		FlowerCollector.onPageEnd("ChaoBaseActivity");
		FlowerCollector.onPause(ChaoBaseActivity.this);
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		isForeground = false;
		super.onDestroy();
	}
}
