/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-9
 */
package com.chao.chaosearchapp.listener;

import android.view.View;


/**
 * @author chaoking
 *
 */
public interface OnObjectClickListener<T> {
	void OnClick(View view,T obj);
}
