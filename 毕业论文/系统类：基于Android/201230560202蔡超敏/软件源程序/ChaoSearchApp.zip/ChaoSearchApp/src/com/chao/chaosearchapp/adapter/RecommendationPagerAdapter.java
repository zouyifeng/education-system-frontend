/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-30
 */
package com.chao.chaosearchapp.adapter;

import java.util.List;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.PageIndicatorView;
import com.chao.chaosearchapp.listener.OnLinkClickListener;
import com.chao.chaosearchapp.listener.OnObjectClickListener;
import com.chao.chaosearchapp.model.AdvertisementBO;
import com.chao.chaosearchapp.util.imageLoader.ImageLoader;

/**
 * @author chaoking
 * 
 */
public class RecommendationPagerAdapter extends PagerAdapter {
	private Context context;// 上下文
	private List<AdvertisementBO> Advertisements;// 广告List，Adapter的数据源
	private LayoutInflater inflater;

	private PageIndicatorView circleIndicator;

	// 链接点击事件
	private OnObjectClickListener<AdvertisementBO> onAdvertisementClickListener;

	private ImageLoader mLoader;

	public void setOnAdvertisementClickListener(
			OnObjectClickListener<AdvertisementBO> listener) {
		this.onAdvertisementClickListener = listener;
	}

	/**
	 * 创建一个新的实例 RecommendationPagerAdapter.
	 * 
	 * @param context
	 * @param AdvertisementBOs
	 */

	public RecommendationPagerAdapter(Context context,
			List<AdvertisementBO> Advertisements) {
		super();
		this.context = context;
		this.Advertisements = Advertisements;
		this.inflater = LayoutInflater.from(context);

		WindowManager wm = (WindowManager) context
				.getSystemService(Context.WINDOW_SERVICE);
		int width = wm.getDefaultDisplay().getWidth();
		mLoader = new ImageLoader(context);
		mLoader.setIsUseMediaStoreThumbnails(false);
		mLoader.setRequiredSize(width / 3);
	}

	@Override
	public int getCount() {
		if (Advertisements == null || Advertisements.isEmpty())
			return 0;
		return Advertisements.size();
	}

	@Override
	public Object instantiateItem(ViewGroup container, final int position) {

		/*
		 * ImageView banner = new ImageView(context);
		 * 
		 * //banner.setScaleType(ImageView.ScaleType.CENTER_CROP);
		 * 
		 * 
		 * banner.setAdjustViewBounds(true); // banner.setLayoutParams(new
		 * LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
		 * // banner.setMaxHeight(280); banner.setLayoutParams(new
		 * LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
		 * banner.setMaxHeight(280); //
		 * banner.setScaleType(ImageView.ScaleType.CENTER_CROP);
		 */
		ImageView banner = (ImageView) inflater.inflate(
				R.layout.item_viewpager_advertisement, null);

		String tempUrl = Advertisements.get(position).getPic();
		banner.setTag(tempUrl);

		// AsyncImageLoader.getInstance().showImageAsyn(banner, tempUrl,
		// R.drawable.ic_launcher);
		mLoader.DisplayImage(tempUrl, banner, R.drawable.ic_launcher);

		banner.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Log.d("RecommendationPagerAdapter", "link"
						+ Advertisements.get(position).getLink());
				onAdvertisementClickListener.OnClick(v,
						Advertisements.get(position));
			}
		});

		container.addView(banner, 0);
		return banner;
	}

	@Override
	public boolean isViewFromObject(View view, Object object) {
		// TODO Auto-generated method stub
		return (view == object);
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		((ViewPager) container).removeView((ImageView) object);
	}

	/**
	 * @param circleIndicator
	 */
	public void setCircleIndicator(PageIndicatorView circleIndicator) {
		this.circleIndicator = circleIndicator;
		this.circleIndicator.setTotalPage(getCount());
		this.circleIndicator.setCurrentPage(0);
	}

	@Override
	public void notifyDataSetChanged() {
		super.notifyDataSetChanged();
		circleIndicator.setTotalPage(getCount());
		circleIndicator.setCurrentPage(0);
	}

}