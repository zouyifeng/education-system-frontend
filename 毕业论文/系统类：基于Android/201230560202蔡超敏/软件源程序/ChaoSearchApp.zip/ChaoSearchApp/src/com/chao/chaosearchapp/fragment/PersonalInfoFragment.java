/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-11
 */
package com.chao.chaosearchapp.fragment;

import java.util.Date;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.activity.ChangeInfoActivity;
import com.chao.chaosearchapp.assembly.ChooseSexDialog;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.fragment.TimePickerFragment.onSelectedDateListener;
import com.chao.chaosearchapp.manager.UserManager;
import com.chao.chaosearchapp.model.UserBO;
import com.handmark.pulltorefresh.library.PullToRefreshScrollView;

/**
 * @author chaoking
 * 
 */
public class PersonalInfoFragment extends ChaoBaseFragment {

	private ViewHolder viewHolder;

	private ChooseSexDialog dialog = null;

	private TimePickerFragment timePickerFragment;

	@Override
	protected View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_personal_info,
				container, false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		viewHolder = new ViewHolder(view);

		PullToRefreshScrollView refreshScrollView = (PullToRefreshScrollView) view
				.findViewById(R.id.personal_info_scrollview);
		// 这几个刷新Label的设置
		refreshScrollView.getLoadingLayoutProxy().setPullLabel(null);
		refreshScrollView.getLoadingLayoutProxy().setRefreshingLabel(null);
		refreshScrollView.getLoadingLayoutProxy().setReleaseLabel(null);
		refreshScrollView.getLoadingLayoutProxy().setLoadingDrawable(null);
	}

	@Override
	protected void initData() {
		viewHolder.tvName.setText(UserManager.getUserName(""));
		viewHolder.tvRealName.setText(UserManager.getRealName(""));
		viewHolder.tvEmail.setText(UserManager.getEmail(""));
		viewHolder.tvBirth.setText(UserManager.getBirthday(""));
		viewHolder.tvSex.setText(UserManager.getSex(""));
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case 0:
			viewHolder.tvName.setText(UserManager.getUserName(""));
			break;
		case 1:
			viewHolder.tvRealName.setText(UserManager.getRealName(""));
			break;
		case 2:
			viewHolder.tvEmail.setText(UserManager.getEmail(""));
			break;

		default:
			break;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	protected void addListener() {
		viewHolder.vName.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mActivity, ChangeInfoActivity.class);
				intent.putExtra(Constants.KEY_CHANGE_INFO_TYPE, 0);
				// intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivityForResult(intent, 0);
			}
		});
		viewHolder.vRealName.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mActivity, ChangeInfoActivity.class);
				intent.putExtra(Constants.KEY_CHANGE_INFO_TYPE, 1);
				// intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivityForResult(intent, 1);
			}
		});
		viewHolder.vEmail.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mActivity, ChangeInfoActivity.class);
				intent.putExtra(Constants.KEY_CHANGE_INFO_TYPE, 2);
				// intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivityForResult(intent, 2);
			}
		});
		viewHolder.vBirth.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (timePickerFragment == null) {
					timePickerFragment = new TimePickerFragment();
					timePickerFragment
							.setOnSelectedDateListener(getSelectedDateListener());
				}
				timePickerFragment.show(mActivity.getSupportFragmentManager(),
						"");
				try {
					if (!timePickerFragment.setDate(viewHolder.tvBirth
							.getText().toString())) {
						makeToast("初始化时间失败");
					}
				} catch (Exception e) {
					makeToast("初始化时间失败");
				}

			}
		});
		viewHolder.vSex.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String sex = UserManager.getSex("男");
				Boolean isMale = sex.equals("男");
				if (dialog == null) {
					dialog = new ChooseSexDialog.Builder(mActivity)
							.setMale(isMale)
							.setMaleButton(
									new DialogInterface.OnClickListener() {

										@Override
										public void onClick(
												DialogInterface dialog,
												int which) {
											chooseSex("男");
										}
									})
							.setFemaleButton(
									new DialogInterface.OnClickListener() {

										@Override
										public void onClick(
												DialogInterface dialog,
												int which) {
											chooseSex("女");
										}
									}).create();
					dialog.show();
				} else {
					dialog.setMale(isMale);
					dialog.checkSex();
					dialog.show();
				}

			}
		});
		viewHolder.vPassword.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mActivity, ChangeInfoActivity.class);
				intent.putExtra(Constants.KEY_CHANGE_INFO_TYPE, 3);
				// intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivityForResult(intent, 3);
			}
		});
	}

	private onSelectedDateListener getSelectedDateListener() {
		return new onSelectedDateListener() {

			@Override
			public void onGetDate(final String dateStr, Date date) {
				// makeToast(dateStr + date.toGMTString());
				UserBO user = new UserBO();
				user.setId(Integer.parseInt(UserManager.getUserId("0")));
				user.setBirthday(dateStr);
				mActivity.appAction.changeUserInfo(user,
						new ActionCallbackListener<Void>() {

							@Override
							public void onSuccess(Void data) {
								UserManager.setBirthday(dateStr);
								viewHolder.tvBirth.setText(dateStr);
							}

							@Override
							public void onFailure(String errorEvent,
									String message) {
								makeToast(message);
							}
						});
			}
		};
	}

	private void chooseSex(final String sex) {
		UserBO user = new UserBO();
		user.setId(Integer.parseInt(UserManager.getUserId("0")));
		user.setSex(sex);
		mActivity.appAction.changeUserInfo(user,
				new ActionCallbackListener<Void>() {

					@Override
					public void onSuccess(Void data) {
						UserManager.setSex(sex);
						viewHolder.tvSex.setText(sex);
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						makeToast(message);
					}
				});
	}

	static class ViewHolder {
		public ViewHolder(View view) {
			tvName = (TextView) view.findViewById(R.id.personal_info_nickname);
			tvRealName = (TextView) view
					.findViewById(R.id.personal_info_realname);
			tvEmail = (TextView) view.findViewById(R.id.personal_info_email);
			tvBirth = (TextView) view.findViewById(R.id.personal_info_birth);
			tvSex = (TextView) view.findViewById(R.id.personal_info_sex);

			vName = view.findViewById(R.id.personal_info_nickname_layout);
			vRealName = view.findViewById(R.id.personal_info_realname_layout);
			vEmail = view.findViewById(R.id.personal_info_email_layout);
			vBirth = view.findViewById(R.id.personal_info_birth_layout);
			vSex = view.findViewById(R.id.personal_info_sex_layout);
			vPassword = view.findViewById(R.id.personal_info_password_layout);

		}

		TextView tvName;
		TextView tvRealName;
		TextView tvEmail;
		TextView tvBirth;
		TextView tvSex;

		View vName;
		View vRealName;
		View vEmail;
		View vBirth;
		View vSex;
		View vPassword;
	}

}
