/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-12
 */
package com.chao.chaosearchapp.core;

import java.util.List;

import com.chao.chaosearchapp.api.ApiResponse;
import com.chao.chaosearchapp.listener.OnAppActionSessionListener;
import com.chao.chaosearchapp.model.AdvertisementBO;
import com.chao.chaosearchapp.model.AppInfoBO;
import com.chao.chaosearchapp.model.BrandBO;
import com.chao.chaosearchapp.model.CommodityBO;
import com.chao.chaosearchapp.model.FeedbackBO;
import com.chao.chaosearchapp.model.HistoryKeywordBO;
import com.chao.chaosearchapp.model.PriceBO;
import com.chao.chaosearchapp.model.RecommendKeywordBO;
import com.chao.chaosearchapp.model.UserBO;

/**
 * @author chaoking
 * 
 */
public interface AppAction {
	// 设置action事件
	public void setOnAppActionSessionListener(
			OnAppActionSessionListener listener);

	// 发送手机验证码
	public void sendSmsCode(String phoneNum,
			ActionCallbackListener<Void> listener);

	// 注册
	public void register(String phoneNum, String code, String password,
			ActionCallbackListener<Void> listener);

	// 登录
	public void login(String loginName, String password,
			ActionCallbackListener<UserBO> listener);

	// 按分页获取商品列表
	public void listCommodity(int pageNum, int pageSize, String name,
			String introduce, ActionCallbackListener<List<CommodityBO>> listener);

	// 按分页获取商品列表
	public void listRecommendCommodity(int pageNum, int pageSize,
			ActionCallbackListener<List<CommodityBO>> listener);

	public void getRecommendKeyword(
			ActionCallbackListener<RecommendKeywordBO> listener);

	public void getHistorySearchKeyword(
			ActionCallbackListener<List<HistoryKeywordBO>> listener);

	// 按分页获取收藏列表
	public void listCollection(int pageNum, int pageSize,
			ActionCallbackListener<List<CommodityBO>> listener);

	// 收藏商品
	public void collectCommodity(int typeId, int type,
			ActionCallbackListener<Void> listener);

	// 取消收藏商品
	public void cancelCollectCommodity(int typeId, int type,
			ActionCallbackListener<Void> listener);

	// 获取广告列表
	public void listAdvertisement(int placeNum,
			ActionCallbackListener<List<AdvertisementBO>> listener);

	// 获取广告列表
	public void listBrand(int placeNum,
			ActionCallbackListener<List<BrandBO>> listener);

	// 获取广告列表
	public void getVersionInfo(String version,
			ActionCallbackListener<AppInfoBO> listener);

	// 清除用户历史搜索数据
	public void clearHistorySearchKeyword(ActionCallbackListener<Void> listener);

	// 修改用户信息
	public void changeUserInfo(UserBO user,
			ActionCallbackListener<Void> listener);

	// 修改用户密码
	public void changeUserPassword(String password,
			ActionCallbackListener<Void> listener);

	// 提交反馈
	public void sendComment(String title, String comment,
			ActionCallbackListener<Void> listener);

	// 通过id获取广告
	public void getAdvertisement(int id,
			ActionCallbackListener<AdvertisementBO> listener);

	// 通过id获取品牌
	public void getBrand(int id, ActionCallbackListener<BrandBO> listener);

	// 通过id获取商品
	public void getCommodity(int id,
			ActionCallbackListener<CommodityBO> listener);

	// 通过id获取商品
	public void getPrice(int id, ActionCallbackListener<PriceBO> listener);

	// 通过id获取反馈
	public void getFeedback(int id, ActionCallbackListener<FeedbackBO> listener);
}
