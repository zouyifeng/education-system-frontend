/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-12
 */
package com.chao.chaosearchapp.core;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.content.Context;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import com.chao.chaosearchapp.api.Api;
import com.chao.chaosearchapp.api.ApiImpl;
import com.chao.chaosearchapp.api.ApiResponse;
import com.chao.chaosearchapp.listener.OnAppActionSessionListener;
import com.chao.chaosearchapp.manager.UserManager;
import com.chao.chaosearchapp.model.AdvertisementBO;
import com.chao.chaosearchapp.model.AppInfoBO;
import com.chao.chaosearchapp.model.BrandBO;
import com.chao.chaosearchapp.model.CommodityBO;
import com.chao.chaosearchapp.model.FeedbackBO;
import com.chao.chaosearchapp.model.HistoryKeywordBO;
import com.chao.chaosearchapp.model.PriceBO;
import com.chao.chaosearchapp.model.RecommendKeywordBO;
import com.chao.chaosearchapp.model.UserBO;
import com.chao.chaosearchapp.util.AppUtil;
import com.chao.chaosearchapp.util.MD5Util;

/**
 * @author chaoking
 * 
 */
public class AppActionImpl implements AppAction {
	private final static int LOGIN_OS = 1; // 表示Android
	private final static int PAGE_SIZE = 20; // 默认每页20条

	private Context context;
	private Api api;

	private OnAppActionSessionListener onAppActionSessionListener;

	public void setOnAppActionSessionListener(
			OnAppActionSessionListener listener) {
		this.onAppActionSessionListener = listener;
	}

	public AppActionImpl(Context context) {
		this.context = context;
		this.api = new ApiImpl();
	}

	@Override
	public void sendSmsCode(final String phoneNum,
			final ActionCallbackListener<Void> listener) {
		// 参数为空检查
		if (TextUtils.isEmpty(phoneNum)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_NULL, "手机号为空");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}
		// 参数合法性检查
		Pattern pattern = Pattern.compile("1\\d{10}");
		Matcher matcher = pattern.matcher(phoneNum);
		if (!matcher.matches()) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "手机号不正确");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<Void>>() {
			@Override
			protected ApiResponse<Void> doInBackground(Void... voids) {
				return api.sendSmsCode4Register(phoneNum);
			}

			@Override
			protected void onPostExecute(ApiResponse<Void> response) {
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(null);
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void register(final String phoneNum, final String code,
			final String password, final ActionCallbackListener<Void> listener) {
		// 参数为空检查
		if (TextUtils.isEmpty(phoneNum)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_NULL, "手机号为空");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}
		if (TextUtils.isEmpty(code)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_NULL, "验证码为空");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}
		if (TextUtils.isEmpty(password)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_NULL, "密码为空");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		// 参数合法性检查
		if (!AppUtil.isMobileNO(phoneNum)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "手机号不正确");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		// TODO 长度检查，密码有效性检查等

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<Void>>() {
			@Override
			protected ApiResponse<Void> doInBackground(Void... voids) {
				return api.registerByPhone(phoneNum, code,
						MD5Util.GetMD5Code32Bit(password));
			}

			@Override
			protected void onPostExecute(ApiResponse<Void> response) {
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(null);
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void login(final String loginName, final String password,
			final ActionCallbackListener<UserBO> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);
		// 参数为空检查
		if (TextUtils.isEmpty(loginName)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_NULL, "登录名为空");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}
		if (TextUtils.isEmpty(password)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_NULL, "密码为空");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}
		// 参数合法性检查
		if (!AppUtil.isMobileNO(loginName)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "手机号不正确");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		// TODO 长度检查，密码有效性检查等

		// 请求Api
		TelephonyManager telephonyManager = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		final String imei = telephonyManager.getDeviceId();
		new AsyncTask<Void, Void, ApiResponse<UserBO>>() {
			@Override
			protected ApiResponse<UserBO> doInBackground(Void... voids) {
				return api.loginByApp(loginName,
						MD5Util.GetMD5Code32Bit(password), imei, LOGIN_OS);
			}

			@Override
			protected void onPostExecute(ApiResponse<UserBO> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObj());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void listCommodity(final int pageNum, final int pageSize,
			final String name, final String introduce,
			final ActionCallbackListener<List<CommodityBO>> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);
		// 参数检查
		if (pageNum < 0) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "当前页数小于零");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		if (pageSize < 0) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "当前页总数小于零");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		// TODO 添加缓存

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<List<CommodityBO>>>() {
			@Override
			protected ApiResponse<List<CommodityBO>> doInBackground(
					Void... voids) {
				return api.listCommodity(pageNum, pageSize, name, introduce,
						UserManager.getUserId("-1"));
			}

			@Override
			protected void onPostExecute(ApiResponse<List<CommodityBO>> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObjList());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void listRecommendCommodity(final int pageNum, final int pageSize,
			final ActionCallbackListener<List<CommodityBO>> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);
		// 参数检查
		if (pageNum < 0) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "当前页数小于零");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		if (pageSize < 0) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "当前页总数小于零");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		// TODO 添加缓存

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<List<CommodityBO>>>() {
			@Override
			protected ApiResponse<List<CommodityBO>> doInBackground(
					Void... voids) {
				return api.listRecommendCommodity(pageNum, pageSize,
						UserManager.getUserId("-1"));
			}

			@Override
			protected void onPostExecute(ApiResponse<List<CommodityBO>> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObjList());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void getRecommendKeyword(
			final ActionCallbackListener<RecommendKeywordBO> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<RecommendKeywordBO>>() {
			@Override
			protected ApiResponse<RecommendKeywordBO> doInBackground(
					Void... voids) {
				return api.getRecommendKeyword(UserManager.getUserId("-1"));
			}

			@Override
			protected void onPostExecute(
					ApiResponse<RecommendKeywordBO> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				Log.d("onPostExecute", "onPostExecute" + response);
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObj());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void getHistorySearchKeyword(
			final ActionCallbackListener<List<HistoryKeywordBO>> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<List<HistoryKeywordBO>>>() {
			@Override
			protected ApiResponse<List<HistoryKeywordBO>> doInBackground(
					Void... voids) {
				return api.getHistorySearchKeyword(UserManager.getUserId("-1"));
			}

			@Override
			protected void onPostExecute(
					ApiResponse<List<HistoryKeywordBO>> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				Log.d("onPostExecute", "onPostExecute" + response);
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObjList());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void listCollection(final int pageNum, final int pageSize,
			final ActionCallbackListener<List<CommodityBO>> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);
		// 参数检查
		if (pageNum < 0) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "当前页数小于零");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		if (pageSize < 0) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "当前页总数小于零");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		final String userId = UserManager.getUserId("-1");

		if (userId == null || "".equals(userId)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "请登陆才能查看收藏信息");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		// TODO 添加缓存

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<List<CommodityBO>>>() {
			@Override
			protected ApiResponse<List<CommodityBO>> doInBackground(
					Void... voids) {
				return api.listCollection(pageNum, pageSize, userId);
			}

			@Override
			protected void onPostExecute(ApiResponse<List<CommodityBO>> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObjList());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void collectCommodity(final int typeId, final int type,
			final ActionCallbackListener<Void> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);
		final String userId = UserManager.getUserId("-1");

		// 参数为空检查
		if ("-1".equals(userId)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_NULL, "还没有登陆");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<Void>>() {
			@Override
			protected ApiResponse<Void> doInBackground(Void... voids) {
				return api.collectCommodity(userId, typeId, type);
			}

			@Override
			protected void onPostExecute(ApiResponse<Void> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(null);
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void cancelCollectCommodity(final int typeId, final int type,
			final ActionCallbackListener<Void> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);
		final String userId = UserManager.getUserId("-1");

		// 参数为空检查
		if (TextUtils.isEmpty(userId)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_NULL, "还没有登陆");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<Void>>() {
			@Override
			protected ApiResponse<Void> doInBackground(Void... voids) {
				return api.cancelCollectCommodity(userId, typeId, type);
			}

			@Override
			protected void onPostExecute(ApiResponse<Void> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(null);
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void listAdvertisement(final int placeNum,
			final ActionCallbackListener<List<AdvertisementBO>> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);
		if (placeNum < 0) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "广告不能少");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}
		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<List<AdvertisementBO>>>() {
			@Override
			protected ApiResponse<List<AdvertisementBO>> doInBackground(
					Void... voids) {
				return api.listAdvertisement(placeNum);
			}

			@Override
			protected void onPostExecute(
					ApiResponse<List<AdvertisementBO>> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObjList());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void getVersionInfo(final String version,
			final ActionCallbackListener<AppInfoBO> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);
		if (version == null || "".equals(version)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "版本号不能为空");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		TelephonyManager telephonyManager = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		final String imei = telephonyManager.getDeviceId();
		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<AppInfoBO>>() {
			@Override
			protected ApiResponse<AppInfoBO> doInBackground(Void... voids) {
				return api.getVersionInfo(imei, version);
			}

			@Override
			protected void onPostExecute(ApiResponse<AppInfoBO> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObj());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}

			}
		}.execute();
	}

	@Override
	public void clearHistorySearchKeyword(
			final ActionCallbackListener<Void> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);
		final String userId = UserManager.getUserId("-1");
		if (userId == null || "-1".equals(userId)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "用户名不能为空");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}
		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<Void>>() {
			@Override
			protected ApiResponse<Void> doInBackground(Void... voids) {
				return api.clearHistorySearchKeyword(userId);
			}

			@Override
			protected void onPostExecute(ApiResponse<Void> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObj());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}

			}
		}.execute();
	}

	@Override
	public void changeUserInfo(final UserBO user,
			final ActionCallbackListener<Void> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);
		if (user == null || user.getId() == 0) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "用户未登陆");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}
		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<Void>>() {
			@Override
			protected ApiResponse<Void> doInBackground(Void... voids) {
				return api.changeUserInfo(user, LOGIN_OS);
			}

			@Override
			protected void onPostExecute(ApiResponse<Void> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObj());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}

			}
		}.execute();
	}

	@Override
	public void changeUserPassword(final String password,
			final ActionCallbackListener<Void> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);
		if (password == null || "".equals(password.trim())) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "密码不能为空");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}
		final String userId = UserManager.getUserId("-1");
		if (userId == null || "-1".equals(userId)) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "用户未登陆");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}
		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<Void>>() {
			@Override
			protected ApiResponse<Void> doInBackground(Void... voids) {
				return api.changeUserPassword(userId,
						MD5Util.GetMD5Code32Bit(password), LOGIN_OS);
			}

			@Override
			protected void onPostExecute(ApiResponse<Void> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObj());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}

			}
		}.execute();
	}

	public void sendComment(final String title, final String comment,
			final ActionCallbackListener<Void> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);

		if (title == null || "".equals(title.trim())) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "题目不能为空");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}

		if (comment == null || "".equals(comment.trim())) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "意见不能为空");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}
		final String userId = UserManager.getUserId("-1");
		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<Void>>() {
			@Override
			protected ApiResponse<Void> doInBackground(Void... voids) {
				return api.sendComment(userId, title, comment);
			}

			@Override
			protected void onPostExecute(ApiResponse<Void> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObj());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}

			}
		}.execute();

	}

	@Override
	public void getAdvertisement(final int id,
			final ActionCallbackListener<AdvertisementBO> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<AdvertisementBO>>() {
			@Override
			protected ApiResponse<AdvertisementBO> doInBackground(Void... voids) {
				return api.getAdvertisement(id);
			}

			@Override
			protected void onPostExecute(ApiResponse<AdvertisementBO> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObj());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void getBrand(final int id,
			final ActionCallbackListener<BrandBO> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<BrandBO>>() {
			@Override
			protected ApiResponse<BrandBO> doInBackground(Void... voids) {
				return api.getBrand(id);
			}

			@Override
			protected void onPostExecute(ApiResponse<BrandBO> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObj());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void getCommodity(final int id,
			final ActionCallbackListener<CommodityBO> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<CommodityBO>>() {
			@Override
			protected ApiResponse<CommodityBO> doInBackground(Void... voids) {
				return api.getCommodity(UserManager.getUserId("-1"), id);
			}

			@Override
			protected void onPostExecute(ApiResponse<CommodityBO> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObj());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void getPrice(final int id,
			final ActionCallbackListener<PriceBO> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<PriceBO>>() {
			@Override
			protected ApiResponse<PriceBO> doInBackground(Void... voids) {
				return api.getPrice(UserManager.getUserId("-1"), id);
			}

			@Override
			protected void onPostExecute(ApiResponse<PriceBO> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObj());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void getFeedback(final int id,
			final ActionCallbackListener<FeedbackBO> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);

		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<FeedbackBO>>() {
			@Override
			protected ApiResponse<FeedbackBO> doInBackground(Void... voids) {
				return api.getFeedback(id);
			}

			@Override
			protected void onPostExecute(ApiResponse<FeedbackBO> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObj());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

	@Override
	public void listBrand(final int placeNum,
			final ActionCallbackListener<List<BrandBO>> listener) {
		this.onAppActionSessionListener.onAppActionSessionOpen(null);
		if (placeNum < 0) {
			if (listener != null) {
				listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "广告不能少");
			}
			onAppActionSessionListener.onAppActionSessionClose();
			return;
		}
		// 请求Api
		new AsyncTask<Void, Void, ApiResponse<List<BrandBO>>>() {
			@Override
			protected ApiResponse<List<BrandBO>> doInBackground(Void... voids) {
				return api.listBrand(placeNum);
			}

			@Override
			protected void onPostExecute(ApiResponse<List<BrandBO>> response) {
				onAppActionSessionListener.onAppActionSessionClose();
				if (listener != null && response != null) {
					if (response.isSuccess()) {
						listener.onSuccess(response.getObjList());
					} else {
						listener.onFailure(response.getEvent(),
								response.getMsg());
					}
				} else {
					listener.onFailure(ErrorEvent.PARAM_ILLEGAL, "响应为空");
				}
			}
		}.execute();
	}

}
