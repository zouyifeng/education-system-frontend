/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-24
 */
package com.chao.chaosearchapp.fragment;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.activity.CommodityListActivity;
import com.chao.chaosearchapp.adapter.RecommendWordAdapter;
import com.chao.chaosearchapp.adapter.SearchKeywordAdapter;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.manager.UserManager;
import com.chao.chaosearchapp.model.RecommendKeywordBO;
import com.handmark.pulltorefresh.library.PullToRefreshBase.Mode;
import com.handmark.pulltorefresh.library.PullToRefreshListView;

/**
 * @author chaoking
 * 
 */
public class HistoryKeywordSearchFragment extends ChaoBaseFragment {

	// listview显示热搜和历史关键字
	private PullToRefreshListView lvSearchKeyword;

	private SearchKeywordAdapter searchKeywordAdapter;

	private RecommendWordAdapter recommendWordAdapter;

	@Override
	public View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_history_keyword_search,
				container, false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		lvSearchKeyword = (PullToRefreshListView) view
				.findViewById(R.id.history_keyword_search_list);

	}

	/**
	 * 1、从本地拿回历史数据； 2、同步网络数据未执行
	 * 
	 * @return List<String>
	 */
	private List<String> getHistoryKeyword() {
		List<String> itemList = new ArrayList<String>();
		itemList.addAll(UserManager.getHistorySearchKeywords());
		Log.d("getHistoryKeyword", "getHistoryKeyword-size" + itemList.size()
				+ "userid" + UserManager.getUserId("-1"));
		if (!itemList.isEmpty()) {
			itemList.add(0, "历史搜索");
		}
		return itemList;
	}

	@Override
	protected void initData() {
		List<String> itemList = getHistoryKeyword();

		initDataByList(itemList);
	}

	/**
	 * 使用listview显示热搜和历史关键字
	 * 
	 * @param itemList
	 */
	private void initDataByList(List<String> itemList) {
		lvSearchKeyword.setMode(Mode.BOTH);
		lvSearchKeyword.getLoadingLayoutProxy().setPullLabel(null);
		lvSearchKeyword.getLoadingLayoutProxy().setRefreshingLabel(null);
		lvSearchKeyword.getLoadingLayoutProxy().setReleaseLabel(null);
		lvSearchKeyword.getLoadingLayoutProxy().setLoadingDrawable(null);

		searchKeywordAdapter = new SearchKeywordAdapter(mActivity);
		lvSearchKeyword.setAdapter(searchKeywordAdapter);
		recommendWordAdapter = new RecommendWordAdapter(mActivity);
		searchKeywordAdapter.setRecommendWordAdapter(recommendWordAdapter);

		mActivity.appAction
				.getRecommendKeyword(new ActionCallbackListener<RecommendKeywordBO>() {

					@Override
					public void onSuccess(RecommendKeywordBO data) {
						Log.d("getRecommendKeyword", "itemList.size"
								+ data.getRecommendKeywords().size());
						Log.d("getRecommendKeyword",
								"itemList.sizesearchKeywordAdapter"
										+ searchKeywordAdapter.getCount());
						recommendWordAdapter.clearItems();
						recommendWordAdapter.addItems(data
								.getRecommendKeywords());
						searchKeywordAdapter.notifyDataSetChanged();
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						makeToast(message);
					}
				});
		if (itemList != null && !itemList.isEmpty())
			searchKeywordAdapter.addItems(itemList);
	}

	@Override
	public void onResume() {
		List<String> itemList = getHistoryKeyword();
		if (itemList != null && !itemList.isEmpty()) {
			searchKeywordAdapter.clearItems();
			searchKeywordAdapter.addItems(itemList);
		}

		super.onResume();
	}

	@Override
	protected void addListener() {
		mActivity.getChaoActionBar().getChaoSearchEditText()
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						Log.d("addListener-onFocusChange", "onClick");
						// refreshActionBar();
					}
				});
		searchKeywordAdapter.setOnClickListener(btnClickListener);
		searchKeywordAdapter.setOnClearClickListener(onClearClickListener);
	}

	// 清除关键字监听器
	private OnClickListener onClearClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			Log.d("onClearClickListener", "onClick");
			mActivity.appAction
					.clearHistorySearchKeyword(new ActionCallbackListener<Void>() {

						@Override
						public void onSuccess(Void data) {
							makeToast("删除搜索历史记录");
							UserManager.clearHistorySearchKeywords();
							searchKeywordAdapter.clearItems();
							recommendWordAdapter.setChange(true);
							searchKeywordAdapter
									.setRecommendWordAdapter(recommendWordAdapter);
						}

						@Override
						public void onFailure(String errorEvent, String message) {
							makeToast(message);
						}
					});
		}
	};

	// 关键字点击事件
	private OnClickListener btnClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			String item = (String) ((TextView) v).getText();
			if (item == null || "".equals(item.trim()))
				return;
			Log.d("btnClickListener", "onClick_item=" + item);
			getChaoActionBar().getChaoSearchEditText().setText(item);
			getChaoActionBar().getChaoSearchEditText().setSelection(
					item.length());

			Intent intent = new Intent(mActivity, CommodityListActivity.class);
			Bundle bundle = new Bundle();
			bundle.putString(Constants.KEY_SEARCH_KEYWORD, item);
			intent.putExtras(bundle);
			startActivity(intent);
		}
	};

}