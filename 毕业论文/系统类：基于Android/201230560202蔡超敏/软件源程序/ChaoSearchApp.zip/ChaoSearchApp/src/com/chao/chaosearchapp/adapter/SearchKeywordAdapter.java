/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-25
 */
package com.chao.chaosearchapp.adapter;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.HorizontalListView;
import com.chao.chaosearchapp.util.AppUtil;

/**
 * @author chaoking
 * 
 */
public class SearchKeywordAdapter extends ChaoBaseAdapter<String> {

	// 热搜关键字监听器
	private OnClickListener onClickListener;

	public void setOnClickListener(OnClickListener listener) {
		onClickListener = listener;
	}

	// 清除历史记录监听器
	private OnClickListener onClearClickListener;

	public void setOnClearClickListener(OnClickListener listener) {
		onClearClickListener = listener;
	}

	/**
	 * 推荐关键字
	 */
	private RecommendWordAdapter recommendWordAdapter;

	/**
	 * @param context
	 */
	public SearchKeywordAdapter(Context context) {
		super(context);
	}

	@Override
	public View getView(int i, View view, ViewGroup viewGroup) {
		Log.d("getView", "itemList.size()=" + itemList.size() + "i=" + i);
		if (recommendWordAdapter != null && i == 0) {
			Log.d("getView", "recommendWordAdapter");
			if (getCount() == 1) {
				view = initRecommendLayout(view, viewGroup);
			} else {
				HeadHolder holder;
				if (view == null) {
					holder = new HeadHolder();
					view = inflater.inflate(
							R.layout.item_list_history_keyword_head, viewGroup,
							false);
					holder.recommendLayout = view
							.findViewById(R.id.item_list_history_keyword_recommend);
					holder.horizontalListView = (HorizontalListView) view
							.findViewById(R.id.home_horizontal_list_search_keyword_history);
					view.setTag(holder);
				} else {
					try {
						holder = (HeadHolder) view.getTag();
					} catch (ClassCastException e) {
						holder = new HeadHolder();
						view = inflater.inflate(
								R.layout.item_list_history_keyword_head,
								viewGroup, false);
						holder.recommendLayout = view
								.findViewById(R.id.item_list_history_keyword_recommend);
						holder.horizontalListView = (HorizontalListView) view
								.findViewById(R.id.home_horizontal_list_search_keyword_history);
						view.setTag(holder);
					}
				}

				if (recommendWordAdapter.isEmpty()) {
					holder.recommendLayout.setVisibility(View.GONE);
				} else {
					holder.recommendLayout.setVisibility(View.VISIBLE);
				}
				holder.horizontalListView.setAdapter(recommendWordAdapter);
				holder.horizontalListView
						.setOnItemClickListener(new OnItemClickListener() {

							@Override
							public void onItemClick(AdapterView<?> parent,
									View view, int position, long id) {
								onClickListener.onClick(view
										.findViewById(R.id.item_list_recommend_word));
							}
						});
			}

		} else if (i == getCount() - 1) {
			Log.d("getView", "TailHolder");
			TailHolder holder;
			if (view == null) {
				holder = new TailHolder();
				view = inflater.inflate(
						R.layout.item_list_history_keyword_tail, viewGroup,
						false);
				holder.btnClear = (Button) view
						.findViewById(R.id.item_list_history_keyword_btn_clear);
				view.setTag(holder);
			} else {
				try {

					holder = (TailHolder) view.getTag();
				} catch (Exception e) {
					holder = new TailHolder();
					view = inflater.inflate(
							R.layout.item_list_history_keyword_tail, viewGroup,
							false);
					holder.btnClear = (Button) view
							.findViewById(R.id.item_list_history_keyword_btn_clear);
					view.setTag(holder);
				}
			}

			holder.btnClear.setOnClickListener(onClearClickListener);
		} else {
			Log.d("getView", "ViewHolder");
			ViewHolder holder;
			if (view == null) {
				holder = new ViewHolder();
				view = inflater.inflate(R.layout.item_list_history_keyword,
						viewGroup, false);
				holder.itemView = (TextView) view
						.findViewById(R.id.item_list_history_keyword_item);
				view.setTag(holder);
			} else {
				try {
					holder = (ViewHolder) view.getTag();
				} catch (Exception e) {
					holder = new ViewHolder();
					view = inflater.inflate(R.layout.item_list_history_keyword,
							viewGroup, false);
					holder.itemView = (TextView) view
							.findViewById(R.id.item_list_history_keyword_item);
					view.setTag(holder);
				}
			}
			holder.itemView.setText((String) getItem(i));
			holder.itemView.setOnClickListener(onClickListener);
		}
		return view;
	}

	/**
	 * 使用table显示热搜数据
	 * 
	 * @param view
	 * @param viewGroup
	 * @return
	 * 
	 */
	private View initRecommendLayout(View view, ViewGroup viewGroup) {
		
		TableHolder holder;
		if (view == null) {
			holder = new TableHolder();
			view = inflater.inflate(R.layout.item_list_history_keyword_table,
					viewGroup, false);
			holder.titleView = (TextView) view
					.findViewById(R.id.history_keyword_search_table_title);
			holder.tableLayout = (LinearLayout) view
					.findViewById(R.id.history_keyword_search_table);
			view.setTag(holder);
		} else {
			try {
				holder = (TableHolder) view.getTag();
				
				// 如果数据没有改变，则不用重新绘制，如果数据改变了则消除之前的数据
				if (recommendWordAdapter.isChange()) {
					// 消除之前的数据的界面
					holder.tableLayout.removeAllViews();
					recommendWordAdapter.setChange(false);
				} else {
					return view;
				}
			} catch (ClassCastException e) {
				holder = new TableHolder();
				view = inflater.inflate(
						R.layout.item_list_history_keyword_table, viewGroup,
						false);
				holder.titleView = (TextView) view
						.findViewById(R.id.history_keyword_search_table_title);
				holder.tableLayout = (LinearLayout) view
						.findViewById(R.id.history_keyword_search_table);
				view.setTag(holder);
			}
		}

		List<String> recommendKeywords = recommendWordAdapter.getItems();

		if (recommendKeywords != null & !recommendKeywords.isEmpty()) {

			LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
					LinearLayout.LayoutParams.MATCH_PARENT,
					LinearLayout.LayoutParams.WRAP_CONTENT); // 每行的水平LinearLayout
			layoutParams.setMargins(20, 8, 20, 8);

			ArrayList<Button> childBtns = new ArrayList<Button>();
			int totoalBtns = 0;
			boolean isFirst = true;
			for (Iterator<String> iterator = recommendKeywords.iterator(); iterator
					.hasNext();) {
				String keyword = iterator.next();
				if (isFirst) {
					holder.titleView.setText(keyword);
					isFirst = false;
					continue;
				}
				LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.WRAP_CONTENT,
						LinearLayout.LayoutParams.WRAP_CONTENT);
				int length = AppUtil.getChineseCount(keyword) * 2
						+ AppUtil.getCharacterBlankNumberCount(keyword);

				// 设置权重，字数越多，权重越大
				if (length < 4) {
					itemParams.weight = 1;
					totoalBtns++;
				} else if (length < 8) {
					itemParams.weight = 2;
					totoalBtns += 2;
				} else {
					itemParams.weight = 3;
					totoalBtns += 3;
				}

				itemParams.width = 0;
				itemParams.setMargins(10, 15, 10, 15);
				Button childBtn = (Button) LayoutInflater.from(context)
						.inflate(R.layout.item_btn_recommend_word, null);
				childBtn.setText(keyword);
				childBtn.setOnClickListener(onClickListener);
				childBtn.setTag(keyword);
				childBtn.setLayoutParams(itemParams);

				childBtns.add(childBtn);
				if (totoalBtns >= 4) {
					LinearLayout horizLL = new LinearLayout(context);
					horizLL.setOrientation(LinearLayout.HORIZONTAL);
					horizLL.setLayoutParams(layoutParams);

					for (Button addBtn : childBtns) {
						horizLL.addView(addBtn);
					}
					holder.tableLayout.addView(horizLL);
					childBtns.clear();
					totoalBtns = 0;
				}

			}

			// 最后一行添加一下
			if (!childBtns.isEmpty()) {
				LinearLayout horizLL = new LinearLayout(context);
				horizLL.setOrientation(LinearLayout.HORIZONTAL);
				horizLL.setLayoutParams(layoutParams);

				for (Button addBtn : childBtns) {
					horizLL.addView(addBtn);
				}
				holder.tableLayout.addView(horizLL);
				childBtns.clear();
				totoalBtns = 0;
			}
		}
		return view;
	}

	/**
	 * @return the recommendWordAdapter
	 */
	public RecommendWordAdapter getRecommendWordAdapter() {
		return recommendWordAdapter;
	}

	/**
	 * @param recommendWordAdapter
	 *            the recommendWordAdapter to set
	 */
	public void setRecommendWordAdapter(
			RecommendWordAdapter recommendWordAdapter) {
		this.recommendWordAdapter = recommendWordAdapter;
		addItem(0, "热搜");
	}

	@Override
	public void addItems(List<String> itemList) {
		super.addItems(itemList);
		addItem("清除");
	}

	static class HeadHolder {
		View recommendLayout;
		HorizontalListView horizontalListView;
	}

	static class TailHolder {
		Button btnClear;
	}

	static class ViewHolder {
		TextView itemView;
	}

	static class TableHolder {
		TextView titleView;
		LinearLayout tableLayout;
	}

}
