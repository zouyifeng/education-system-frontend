/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-24
 */
package com.chao.chaosearchapp.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.chao.chaosearchapp.activity.ChaoBaseActivity;
import com.chao.chaosearchapp.assembly.ChaoActionBar;

/**
 * @author chaoking
 * 
 */
public abstract class ChaoBaseFragment extends Fragment {

	protected ChaoBaseActivity mActivity;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if (getActivity() instanceof ChaoBaseActivity) {
			mActivity = (ChaoBaseActivity) getActivity();
		}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		return init(initFragment(inflater, container, savedInstanceState));
	}

	private View init(View view) {
		initViews(view);
		initData();
		addListener();
		return view;
	}

	protected abstract View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState);

	protected ChaoActionBar getChaoActionBar() {
		return mActivity == null ? null : mActivity.getChaoActionBar();
	}

	protected void makeToast(String text) {
		if (mActivity != null) {
			mActivity.makeToast(text);
		}
	}

	protected void showLoadingDialog(String text) {
		if (mActivity != null) {
			mActivity.showLoadingDialog(text);
		}
	}

	protected void dismissLoadingDialog() {
		if (mActivity != null) {
			mActivity.dismissLoadingDialog();
		}
	}

	private long curClickTimeMillis = 0;

	/** 是否点击了多次 小于1秒当作是多次点击了 **/
	protected boolean isMultiplicationClick() {
		if (curClickTimeMillis == 0) {
			curClickTimeMillis = System.currentTimeMillis();
			return false;
		}
		boolean rs = System.currentTimeMillis() - curClickTimeMillis < 1000;
		curClickTimeMillis = System.currentTimeMillis();
		return rs;
	}

	/**
	 * 初始化组件
	 */
	protected abstract void initViews(View view);

	/**
	 * 初始化数据
	 */
	protected abstract void initData();

	/**
	 * 添加监听器
	 */
	protected abstract void addListener();
}
