/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-24
 */
package com.chao.chaosearchapp.assembly;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.util.AppUtil;

/**
 * @author chaoking
 * 
 */
public class ChaoActionBar extends LinearLayout {

	// private String TAG = "ChaoActionBar";
	private LayoutParams lp;
	private Button mHomeBtn;
	private Button mSubMenuBtn;
	private ChaoActionBarCallBack mBarCallBack;
	private ProgressBar mProgressBar;
	private TextView mTitle;

	private ChaoSearchEditText searchEditText;

	public interface ChaoActionBarCallBack {
		public void onHomeClickCallBack(Button homebtn);

		public void onSubmenuClickCallBack(Button submenubtn);
	}

	public void addChaoActionBarCallBack(ChaoActionBarCallBack callBack) {
		this.mBarCallBack = callBack;
	}

	public void setDefaultBackgroundColor() {
		findViewById(R.id.bar_layout).setBackgroundColor(
				getResources().getColor(R.color.actionbar_background));
	}

	public void setGrayBackgroundColor() {
		findViewById(R.id.bar_layout).setBackgroundColor(
				getResources().getColor(R.color.theme_background_light_gray));
	}

	/**
	 * View.VISIBLE
	 * 
	 * @param visibility
	 */
	public void setHomeVisibility(int visibility) {
		mHomeBtn.setVisibility(visibility);
	}

	/**
	 * View.VISIBLE
	 * 
	 * @param visibility
	 */
	public void setSubMenuVisibility(int visibility) {
		mSubMenuBtn.setVisibility(visibility);
		if (visibility == View.INVISIBLE) {
			setSubmenuIcon(0);
		}
	}

	/**
	 * setText(Html.fromHtml(text));
	 * 
	 * @param text
	 */
	public void setHomeText(String text) {
		mHomeBtn.setText(Html.fromHtml(text));
	}

	public void setHomeIcon(Bitmap bitmap) {
		if (bitmap == null) {
			mHomeBtn.setCompoundDrawablesWithIntrinsicBounds(null, null, null,
					null);
			return;
		}

		Drawable drawable = new BitmapDrawable(bitmap);
		mHomeBtn.setCompoundDrawablesWithIntrinsicBounds(drawable, null, null,
				null);
	}

	public void setHomeIcon(int drawersrc) {
		mHomeBtn.setCompoundDrawablesWithIntrinsicBounds(drawersrc, 0, 0, 0);
	}

	/**
	 * setText(Html.fromHtml(text));
	 * 
	 * @param text
	 */
	public void setSubmenuText(String text) {
		mSubMenuBtn.setText(Html.fromHtml(text));
	}

	/**
	 * setText(Html.fromHtml(text));
	 * 
	 * @param text
	 */
	public void setTitleText(String text) {
		if (text != null && !"".equals(text))
			mTitle.setText(Html.fromHtml(text));
	}

	public void setSubmenuIcon(Bitmap bitmap) {
		if (bitmap == null)
			return;
		Drawable drawable = new BitmapDrawable(bitmap);
		mSubMenuBtn.setCompoundDrawablesWithIntrinsicBounds(null, null,
				drawable, null);
	}

	public void setSubmenuIcon(int drawersrc) {
		mSubMenuBtn.setCompoundDrawablesWithIntrinsicBounds(0, 0, drawersrc, 0);
	}

	public void setSubmenuTopText(int topdrawersrc, String text) {
		mSubMenuBtn.setCompoundDrawablesWithIntrinsicBounds(0, topdrawersrc, 0,
				0);
		mSubMenuBtn.setCompoundDrawablePadding(2);

		int left = AppUtil.dpToPx(16, getResources());
		int top = AppUtil.dpToPx(8, getResources());
		int right = AppUtil.dpToPx(16, getResources());
		int bottom = AppUtil.dpToPx(1, getResources());
		mSubMenuBtn.setPadding(left, top, right, bottom);
		setSubmenuText(text);
	}

	private void init() {
		if (isInEditMode())
			return;

		lp = new LayoutParams(LayoutParams.MATCH_PARENT, AppUtil.dpToPx(48,
				getResources()));
		setLayoutParams(lp);

		View view = LayoutInflater.from(getContext()).inflate(
				R.layout.action_bar_chao, this);

		searchEditText = (ChaoSearchEditText) view
				.findViewById(R.id.edit_search);
		mTitle = (TextView) view.findViewById(R.id.bar_title);
		mHomeBtn = (Button) view.findViewById(R.id.bar_home);
		mSubMenuBtn = (Button) view.findViewById(R.id.bar_submenu);
		mProgressBar = (ProgressBar) view
				.findViewById(R.id.progressBarCircularIndetermininate);
		// mProgressBar.setBackgroundColor(getContext().getResources().getColor(R.color.midou_font_white));
		// mProgressBar.setBackgroundDrawable(getContext().getResources().getDrawable(R.drawable.ic_launcher));
		showProgressBar(false);

		mHomeBtn.setOnClickListener(mClickListener);
		mSubMenuBtn.setOnClickListener(mClickListener);

		// if(!Network.isConnectedOrConnecting(getContext())){
		// setGrayBackgroundColor();
		// }
	}

	public ChaoSearchEditText getChaoSearchEditText() {
		return searchEditText;
	}

	public View getTitleView() {
		return mTitle;
	}

	public View getHomeView() {
		return mHomeBtn;
	}

	public ProgressBar getProgressBar() {
		return mProgressBar;
	}

	public View getSubMenuView() {
		return mSubMenuBtn;
	}

	public void showProgressBar(boolean show) {
		if (mProgressBar != null)
			mProgressBar.setVisibility(show ? View.VISIBLE : View.GONE);
	}

	private OnClickListener mClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			int id = v.getId();
			switch (id) {
			case R.id.bar_home:
				if (mBarCallBack != null) {
					mBarCallBack.onHomeClickCallBack(mHomeBtn);
				} else {
					((Activity) getContext()).finish();
				}
				break;
			case R.id.bar_submenu:
				if (mBarCallBack != null) {
					mBarCallBack.onSubmenuClickCallBack(mSubMenuBtn);
				} else {
					Toast.makeText(getContext(), "未设置", Toast.LENGTH_SHORT)
							.show();
				}
				break;
			default:
				break;
			}
		}
	};

	@SuppressLint("NewApi")
	public ChaoActionBar(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}

	public ChaoActionBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public ChaoActionBar(Context context) {
		super(context);
		init();
	}

}
