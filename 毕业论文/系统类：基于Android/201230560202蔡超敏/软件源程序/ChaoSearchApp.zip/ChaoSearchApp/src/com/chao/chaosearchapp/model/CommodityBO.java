/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-12
 */
package com.chao.chaosearchapp.model;

import java.io.Serializable;
import java.util.List;

/**
 * @author chaoking
 * 
 */
public class CommodityBO implements Serializable {
	private static final long serialVersionUID = -554436400873352846L;

	private int id; // 商品id
	private String name; // 商品名称
	private String introduce; // 商品简介

	private String pic; // 商品图片

	private List<PriceBO> prices; // 商品价格

	private int isCollected; // 是否被收藏,0没有，1有

	public boolean isCollected() {
		return isCollected == 1;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the introduce
	 */
	public String getIntroduce() {
		return introduce;
	}

	/**
	 * @param introduce
	 *            the introduce to set
	 */
	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}

	/**
	 * @return the pic
	 */
	public String getPic() {
		return pic;
	}

	/**
	 * @param pic
	 *            the pic to set
	 */
	public void setPic(String pic) {
		this.pic = pic;
	}

	/**
	 * @return the prices
	 */
	public List<PriceBO> getPrices() {
		return prices;
	}

	/**
	 * @param prices
	 *            the prices to set
	 */
	public void setPrices(List<PriceBO> prices) {
		this.prices = prices;
	}

	/**
	 * @return the isCollected
	 */
	public int getIsCollected() {
		return isCollected;
	}

	/**
	 * @param isCollected
	 *            the isCollected to set
	 */
	public void setIsCollected(int isCollected) {
		this.isCollected = isCollected;
	}

	@Override
	public String toString() {
		String introduce = "[name:" + name + "]";
		return introduce;
	}

	@Override
	public boolean equals(Object o) {
		if (getId() == ((CommodityBO) o).getId()) {
			if (getPrices() == ((CommodityBO) o).getPrices())
				return true;
			if (getPrices() == null || ((CommodityBO) o).getPrices() == null)
				return false;
			if (getPrices().size() == ((CommodityBO) o).getPrices().size()) {
				for (int i = 0; i < getPrices().size(); i++) {
					if (!getPrices().get(i).equals(
							((CommodityBO) o).getPrices().get(i))) {
						return false;
					}
				}
				return true;
			}
		}

		return super.equals(o);
	}

}
