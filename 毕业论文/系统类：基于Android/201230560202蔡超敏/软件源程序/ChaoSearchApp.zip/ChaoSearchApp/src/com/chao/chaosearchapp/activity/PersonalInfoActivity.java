/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-4-11
 */
package com.chao.chaosearchapp.activity;

import android.support.v4.app.Fragment;
import android.view.View;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.ChaoActionBar;
import com.chao.chaosearchapp.fragment.PersonalInfoFragment;
import com.chao.chaosearchapp.util.AppUtil;

/**
 * @author chaoking
 * 
 */
public class PersonalInfoActivity extends SingleFragmentActivity {

	@Override
	protected Fragment createFragment() {
		return new PersonalInfoFragment();
	}

	@Override
	protected void initViews() {
		ChaoActionBar chaoActionBar = getChaoActionBar();

		chaoActionBar.getTitleView().setVisibility(View.VISIBLE);
		chaoActionBar.setHomeIcon(R.drawable.arrow_left_circle);
		chaoActionBar.getHomeView().setPadding(
				AppUtil.dpToPx(10, getResources()), 0, 0, 0);
		chaoActionBar.setHomeVisibility(View.VISIBLE);

		chaoActionBar.setSubMenuVisibility(View.GONE);

		chaoActionBar.getChaoSearchEditText().setVisibility(View.GONE);

		chaoActionBar.setTitleText("个人信息");
	}

	@Override
	protected void initData() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void addListener() {
		// TODO Auto-generated method stub

	}

}
