package com.chao.chaosearchapp.listener;

public interface OnDownloadZIPListener {
	void onFinish();

	void onError();
}