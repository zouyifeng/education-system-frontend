/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-31
 */
package com.chao.chaosearchapp.fragment;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;

/**
 * @author chaoking
 * 
 */
public class BrowserFragment extends ChaoBaseFragment {

	private WebView webView;
	private GestureDetector gestureDetector;
	// private Window window;
	private String url;

	private int width;

	@Override
	protected View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_browser, container,
				false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		// window = mActivity.getWindow();
		// window.requestFeature(Window.FEATURE_PROGRESS);
		webView = (WebView) view.findViewById(R.id.browser_webview);

	}

	@Override
	protected void initData() {
		mActivity.getWindow().setFeatureInt(Window.FEATURE_PROGRESS,
				Window.PROGRESS_VISIBILITY_ON);
		url = mActivity.getIntent().getStringExtra(Constants.KEY_BROWSER_LINK);
		// 打开内嵌浏览器
		Log.d("Browser", "Browser" + url);
		if (url != null && !"".equals(url))
			openBrowser(url);
		// 设置WebView属性
		webView.getSettings().setJavaScriptEnabled(true);// 可用JavaScript
		webView.setWebChromeClient(new WebChromeClient() {
			@Override
			public void onProgressChanged(WebView view, int newProgress) {// 当网页的加载进度发生变化时
				// 重写方法 设置Activity的进度条
				if (getChaoActionBar() != null) {
					if (newProgress != 100) {
						getChaoActionBar().showProgressBar(true);
						getChaoActionBar().getProgressBar().setProgress(
								newProgress);
					} else {
						getChaoActionBar().showProgressBar(false);
						getChaoActionBar().getProgressBar().setProgress(
								newProgress);
					}
				}
				// makeToast(newProgress + "");
				mActivity.setProgress(newProgress);
				super.onProgressChanged(view, newProgress);
			}

			public void onReceivedTitle(WebView view, String title) {// 当网页的标题发生改变时
				// mActivity.getChaoActionBar().setTitleText(title);
			}

			public void onReceivedIcon(WebView view, Bitmap icon) {// 当网页的图标发生改变时

			}
		});

		// 可用JavaScript对话框
		webView.setWebViewClient(new WebViewClient() {
			@Override
			public void onReceivedError(WebView view, int errorCode,
					String description, String failingUrl) {
				// TODO Auto-generated method stub
				super.onReceivedError(view, errorCode, description, failingUrl);
				makeToast("错误啦~ " + description);
			}
		});// 处理各种相应事件
		webView.getSettings().setSupportZoom(true);// 设置是否支持变焦
		webView.getSettings().setBuiltInZoomControls(true);// 可缩放

		// 左右事件的处理
		gestureDetector = new GestureDetector(mActivity, onGestureListener);
		gestureDetector.setIsLongpressEnabled(true);

		WindowManager wm1 = mActivity.getWindowManager();
		width = wm1.getDefaultDisplay().getWidth();
	}

	@Override
	protected void addListener() {
		// webView.setOnTouchListener(onTouchListener);
	}

	public GestureDetector.OnGestureListener onGestureListener = new GestureDetector.SimpleOnGestureListener() {

		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
				float velocityY) {
			float x = e2.getX() - e1.getX();
			float y = e2.getY() - e1.getY();
			if (x > width * 3 / 4) {
				doResult(0);
				return true;
			} else if (x < -width * 3 / 4) {
				doResult(1);
				return true;
			}
			return false;
		}
	};

	/**
	 * 手势前进后退
	 * 
	 * @param action
	 *            1表示后退，0表示前进
	 */
	public void doResult(int action) {

		switch (action) {
		case 0:
			if (webView.canGoBack()) {
				// 进行后退跳转
				webView.goBack();
			} else {
				makeToast("对不起，您现在不能后退哦~");
			}
			break;
		case 1:
			if (webView.canGoForward()) {
				// 进行前进跳转
				webView.goForward();
			} else {
				makeToast("对不起，您现在不能前进哦~");
			}
			break;

		}
	}

	/**
	 * 
	 * 按键实现网站前进后退功能 当无法后退了，就会关闭当前activity
	 * 
	 * @param keyCode
	 * @param event
	 * @return
	 */
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (webView.canGoBack()) {
				webView.goBack();
				return true;
			} else {
				mActivity.finish();
				return false;
			}
		} else if (keyCode == KeyEvent.KEYCODE_HOME) {
			webView.stopLoading();
			return true;
		}
		return false;
	}

	/**
	 * 先判断url是否是空 打开web,自动加上http
	 * 
	 * @param url
	 */
	public void openBrowser(String url) {
		/*
		 * if (!"".equals(url)) { String subUrl = url.substring(0, 7); if
		 * (subUrl.compareTo("http://") != 0) { url = "http://" + url; }
		 */
		// if (url.indexOf("http://") == -1 || url.indexOf("http://") != 0) {
		// url = "http://" + url;
		// Log.e("Browser", "ADD http");
		// }
		if (URLUtil.isNetworkUrl(url)) {
			webView.loadUrl(url);
		} else {
			makeToast("对不起，网址有错误哦~~");
		}
	}

	public void dispatchTouchEvent(MotionEvent event) {
		gestureDetector.onTouchEvent(event);
		webView.onTouchEvent(event);
	}

}
