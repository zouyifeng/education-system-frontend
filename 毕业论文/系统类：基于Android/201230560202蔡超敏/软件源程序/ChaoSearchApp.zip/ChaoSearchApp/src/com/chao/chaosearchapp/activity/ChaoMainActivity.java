/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-24
 */
package com.chao.chaosearchapp.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;
import cn.jpush.android.api.BasicPushNotificationBuilder;
import cn.jpush.android.api.JPushInterface;

import com.chao.chaosearchapp.ChaoSearchApplication;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.assembly.ChaoActionBar;
import com.chao.chaosearchapp.assembly.ChaoActionBar.ChaoActionBarCallBack;
import com.chao.chaosearchapp.fragment.ChaoBaseFragment;
import com.chao.chaosearchapp.fragment.CollectionFragment;
import com.chao.chaosearchapp.fragment.HomeFragment;
import com.chao.chaosearchapp.fragment.PersonalCenterFragment;
import com.chao.chaosearchapp.manager.UserManager;

/**
 * @author chaoking
 * 
 */
public class ChaoMainActivity extends ChaoBaseActivity {

	private TextView networkTip;

	private String TAG = "ChaoMainActivity.TAG";
	// private MidouSubmenu mSubmenu;
	private RadioGroup mRadioGroup;
	private ChaoBaseFragment mCurFragment;

	// private AdvertisingFragment advertisingFragment;

	@Override
	protected int setChaoActionBarId() {
		return R.id.chao_action_bar;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_chao_main);
	}

	@Override
	protected void onStart() {
		super.onStart();
	}

	@Override
	protected void onResume() {
		JPushInterface.onResume(this);
		super.onResume();

		// reSetAdvertisingFragment();
	}

	// private void reSetAdvertisingFragment() {
	// if(advertisingFragment != null){
	// Dialog tDialog = advertisingFragment.getDialog();
	// WindowManager m = getWindowManager();
	// Display d = m.getDefaultDisplay(); // 获取屏幕宽、高用
	// int height = (int) (d.getHeight() * 0.6);
	// int width = (int) (d.getWidth() * 0.9);
	// tDialog.getWindow().setLayout(width, width);
	// tDialog.setOnDismissListener(new OnDismissListener() {
	//
	// @Override
	// public void onDismiss(DialogInterface dialog) {
	// advertisingFragment = null;
	// }
	// });
	// }
	// }

	@Override
	public void onStop() {
		super.onStop();
	}

	private OnCheckedChangeListener getOnCheckedChangeListener() {
		return new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				radioGroupCheckedChanged(group, checkedId);
			}
		};
	}

	private void radioGroupCheckedChanged(RadioGroup group, int checkedId) {
		View view = group.findViewById(checkedId);
		Object object = view.getTag();
		if (object instanceof ChaoBaseFragment) {
			ChaoBaseFragment fragment = (ChaoBaseFragment) object;
			replaceFragment(fragment, "");
		} else if (object instanceof String) {
			String fragmentStr = String.valueOf(object);
			try {
				Class<?> fragmentCls = Class.forName(fragmentStr);
				ChaoBaseFragment tFragment = (ChaoBaseFragment) fragmentCls
						.newInstance();
				view.setTag(tFragment);
				replaceFragment(tFragment, fragmentStr);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}
	}

	private void replaceFragment(ChaoBaseFragment fragment, String tag) {
		FragmentManager fragmentManager = getSupportFragmentManager();
		if (mCurFragment != null)
			fragmentManager.beginTransaction().hide(mCurFragment).commit();

		mCurFragment = fragment;
		if (mCurFragment.isAdded()) {
			fragmentManager.beginTransaction().show(mCurFragment).commit();
		} else {
			fragmentManager.beginTransaction()
					.add(R.id.container, mCurFragment, tag).commit();
		}
		if (mCurFragment instanceof HomeFragment) {
			getChaoActionBar().getTitleView().setVisibility(View.GONE);
			getChaoActionBar().setTitleText("首页");
			getChaoActionBar().getHomeView().setVisibility(View.VISIBLE);
			getChaoActionBar().getSubMenuView().setVisibility(View.VISIBLE);
			getChaoActionBar().getChaoSearchEditText().setVisibility(
					View.VISIBLE);
		} else if (mCurFragment instanceof CollectionFragment) {
			getChaoActionBar().getTitleView().setVisibility(View.VISIBLE);
			getChaoActionBar().setTitleText("收藏");
			getChaoActionBar().getHomeView().setVisibility(View.VISIBLE);
			getChaoActionBar().getSubMenuView().setVisibility(View.VISIBLE);
			getChaoActionBar().getChaoSearchEditText().setVisibility(View.GONE);
		} else if (mCurFragment instanceof PersonalCenterFragment) {
			getChaoActionBar().getTitleView().setVisibility(View.VISIBLE);
			getChaoActionBar().setTitleText("我的");
			getChaoActionBar().getHomeView().setVisibility(View.VISIBLE);
			getChaoActionBar().getSubMenuView().setVisibility(View.VISIBLE);
			getChaoActionBar().getChaoSearchEditText().setVisibility(View.GONE);
		}

		// if (mCurFragment instanceof OrderListFragment) {
		// getChaoActionBar().setTitleText("我的订单");
		// getChaoActionBar().getHomeView().setVisibility(View.GONE);
		// getChaoActionBar().getSubMenuView().setVisibility(View.GONE);
		// } else if (mCurFragment instanceof PersonalCenterFragment) {
		// getChaoActionBar().setTitleText("");
		// getChaoActionBar().getHomeView().setVisibility(View.GONE);
		// getChaoActionBar().getSubMenuView().setVisibility(View.GONE);
		// } else if (mCurFragment instanceof HomeFragment) {
		// getChaoActionBar().setTitleText("1号货的");
		// getChaoActionBar().getHomeView().setVisibility(View.VISIBLE);
		// getChaoActionBar().getSubMenuView().setVisibility(View.VISIBLE);
		// }
	}

	@Override
	protected ChaoActionBarCallBack addChaoActionBarCallBack() {
		return new ChaoActionBarCallBack() {

			@Override
			public void onSubmenuClickCallBack(Button submenubtn) {
				// if (mSubmenu == null)
				// mSubmenu = new MidouSubmenu(getApplication(), null,
				// getSubmenuCallBack());
				// if (!mSubmenu.isShowing()) {
				// mSubmenu.showAsDropDown(submenubtn);
				// } else {
				// mSubmenu.dismiss();
				// }
				// startActivity(MessageActivty.class, null);

				Intent intent = new Intent(context, MessageListActivity.class);
				// intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intent);
			}

			@Override
			public void onHomeClickCallBack(Button homebtn) {
				if (UserManager.isBingAccount()) {
					Intent intent = new Intent(context,
							PersonalInfoActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(intent);
				} else {
					makeToast("用户未登录");
					Intent intent = new Intent(context, LoginActivity.class);
					startActivity(intent);
				}
			}
		};
	}

	// private OnItemClickCallBack getSubmenuCallBack() {
	// return new OnItemClickCallBack() {
	//
	// /**
	// * ("我的订单" 1) ; ("常用地址" 2); ("常用司机" 3);
	// */
	// @Override
	// public void menuItemCallBack(SubmenuItem item) {
	// if (mSubmenu.isShowing()) {
	// mSubmenu.dismiss();
	// }
	// if (item.getItemId() == 1) {
	// startActivity(UserBoundActivity.class, null);
	// } else if (item.getItemId() == 2) {
	// startActivity(PlaceAnOrderActivity.class, null);
	// } else {
	// makeToast(item.getItemTitle());
	// userLogin();
	// }
	// }
	// };
	// }

	// // .........广告处理 ..........
	// private void showAdvertising(){
	// advertisingFragment = new AdvertisingFragment();
	// advertisingFragment.show(getSupportFragmentManager(), "");
	// }

	@Override
	protected void onDestroy() {
		super.onDestroy();

		// try {
		// if(advertisingFragment != null){
		// advertisingFragment.dismiss();
		// advertisingFragment = null;
		// }
		// } catch (Exception e) { }

		FragmentManager fragmentManager = getSupportFragmentManager();
		fragmentManager.getFragments().clear();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (isMultiplicationClick()) {
				finish();
			} else {
				makeToast("再按一次退出程序");
			}
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		// 退出
		if ((Intent.FLAG_ACTIVITY_CLEAR_TOP & intent.getFlags()) != 0) {
			finish();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

	}

	@Override
	protected void initViews() {
		ChaoActionBar tActionBar = getChaoActionBar();
		tActionBar.showProgressBar(false);
		tActionBar.setSubmenuTopText(R.drawable.message, "消息");

		mRadioGroup = (RadioGroup) findViewById(R.id.radioGroup);
		mRadioGroup.setOnCheckedChangeListener(getOnCheckedChangeListener());
		radioGroupCheckedChanged(mRadioGroup,
				mRadioGroup.getCheckedRadioButtonId());

		// showAdvertising();

		networkTip = (TextView) findViewById(R.id.network_tip);
	}

	@Override
	protected void initData() {
		// TODO Auto-generated method stub

		JPushInterface.init(getApplicationContext());
		BasicPushNotificationBuilder builder = new BasicPushNotificationBuilder(
				this);
		// builder.statusBarDrawable=R.drawable.
	}

	@Override
	protected void onPause() {
		JPushInterface.onPause(this);
		super.onPause();
	}

	@Override
	protected void addListener() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setNetworkTip() {
		super.setNetworkTip();
		if (ChaoSearchApplication.networkTip.isShow()) {
			networkTip.setText(ChaoSearchApplication.networkTip.getTip());
			networkTip.setOnClickListener(ChaoSearchApplication.networkTip
					.getClickListener());
			networkTip.setVisibility(View.VISIBLE);
		} else {
			networkTip.setText(ChaoSearchApplication.networkTip.getTip());
			networkTip.setVisibility(View.GONE);
		}
	}

}
