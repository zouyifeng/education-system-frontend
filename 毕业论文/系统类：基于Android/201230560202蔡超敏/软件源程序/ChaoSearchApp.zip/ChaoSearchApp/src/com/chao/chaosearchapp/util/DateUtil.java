/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-5-3
 */
package com.chao.chaosearchapp.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * @author chaoking
 * 
 */
public class DateUtil {

	public static String longToString(long time) {

		DateFormat simpleFormatNowDay = new SimpleDateFormat("HH:mm");
		DateFormat simpleFormatNowWeek = new SimpleDateFormat("EEEE");
		DateFormat simpleFormatNowYear = new SimpleDateFormat("MM/dd");
		DateFormat simpleFormat = new SimpleDateFormat("yyyy/MM/dd");

		Calendar date = Calendar.getInstance();
		date.setTimeInMillis(time);
		Calendar now = Calendar.getInstance();
		now.setTimeInMillis(System.currentTimeMillis());

		if (date.get(Calendar.YEAR) == now.get(Calendar.YEAR)) {
			if (date.get(Calendar.WEEK_OF_YEAR) == now
					.get(Calendar.WEEK_OF_YEAR)) {
				if (date.get(Calendar.DAY_OF_WEEK) == now
						.get(Calendar.DAY_OF_WEEK)) {
					return simpleFormatNowDay.format(date.getTime());
				} else {
					return simpleFormatNowWeek.format(date.getTime());
				}
			} else {
				return simpleFormatNowYear.format(date.getTime());
			}
		} else {
			return simpleFormat.format(date.getTime());
		}

	}
}
