/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-5-3
 */
package com.chao.chaosearchapp.manager;

import java.util.ArrayList;

import org.afinal.simplecache.SimplceCache;

import com.chao.chaosearchapp.ChaoSearchApplication;
import com.chao.chaosearchapp.model.MessageBO;
import com.chao.chaosearchapp.util.AppUtil;

/**
 * @author chaoking
 * 
 */
public class MessageManager {
	private static SimplceCache userCache = SimplceCache.get(
			ChaoSearchApplication.getContext(), "chao_app_message");

	private static String returnDefaultValue(String value, String defaultValue) {
		if (value != null && !"".equals(value))
			return value;
		return defaultValue;
	};

	/**
	 * 从本地获取消息
	 * 
	 * @return ArrayList<MessageBO>
	 */
	public static ArrayList<MessageBO> getMessages() {
		Object object = userCache.getAsObject(UserManager.getUserId("-1")
				+ "_messages");
		if (object == null) {
			object = new ArrayList<MessageBO>();
		}
		return (ArrayList<MessageBO>) object;
	}

	/**
	 * 存储多个消息
	 * 
	 * @param MessageBO
	 *            ArrayList<MessageBO>
	 */
	public static void setMessages(ArrayList<MessageBO> massage) {
		userCache.put(UserManager.getUserId("-1") + "_messages", massage);
	}

	/**
	 * 存储消息
	 * 
	 * @param MessageBO
	 *            MessageBO
	 */
	public static void setMessage(MessageBO message) {
		Object object = userCache.getAsObject(UserManager.getUserId("-1")
				+ "_messages");
		if (object != null) {
			ArrayList<MessageBO> list = (ArrayList<MessageBO>) object;
			list.add(0, message);
			setMessages((ArrayList<MessageBO>) AppUtil
					.removeMessageBODuplicate(list));
		} else {
			ArrayList<MessageBO> list = new ArrayList<MessageBO>();
			list.add(message);
			setMessages(list);
		}
	}
}
