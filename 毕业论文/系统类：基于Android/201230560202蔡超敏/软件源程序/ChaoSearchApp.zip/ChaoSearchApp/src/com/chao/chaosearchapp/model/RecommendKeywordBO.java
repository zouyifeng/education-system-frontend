/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-25
 */
package com.chao.chaosearchapp.model;

import java.io.Serializable;
import java.util.List;

/**
 * @author chaoking
 *
 */
public class RecommendKeywordBO implements Serializable{

	private static final long serialVersionUID = -91128115727207528L;

	private int id;							// 推荐关键字id
	private int userId;						// 被推荐人id
	private List<String> recommendKeywords;	// 推荐关键字list
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the userId
	 */
	public int getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}
	/**
	 * @return the recommendKeywords
	 */
	public List<String> getRecommendKeywords() {
		return recommendKeywords;
	}
	/**
	 * @param recommendKeywords the recommendKeywords to set
	 */
	public void setRecommendKeywords(List<String> recommendKeywords) {
		this.recommendKeywords = recommendKeywords;
	}
	

}
