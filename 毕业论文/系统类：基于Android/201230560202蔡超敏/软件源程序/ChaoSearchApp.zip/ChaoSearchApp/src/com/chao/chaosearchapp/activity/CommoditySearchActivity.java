/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-13
 */
package com.chao.chaosearchapp.activity;

import java.util.LinkedList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.adapter.CommodityListAdapter;
import com.chao.chaosearchapp.assembly.ChaoSearchEditText;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.listener.OnTextChangedListener;
import com.chao.chaosearchapp.model.CommodityBO;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.Mode;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener;
import com.handmark.pulltorefresh.library.PullToRefreshListView;

/**
 * @author chaoking
 * 
 */
public class CommoditySearchActivity extends ChaoBaseActivity {

	private static final int VOICE_RECOGNITION_REQUEST_CODE = 1001;
	private static final String KEY_VOICE_RECOGNITION_STRING = "VOICE_RECOGNITION_STRING";
	private ChaoSearchEditText etSearch;
	private Button btnSearch;

	private String keyWord = "";
	private int pageNum = 1;
	private int pageSize = 10;

	private LinkedList<Object> listCommodity;
	private PullToRefreshListView pullRefreshListView;
	private CommodityListAdapter commodityListAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_commodity_search);
	}

	/**
	 * 语音识别
	 */
	private void voiceRecognition() {
		Intent intent = new Intent(this, VoiceRecognitionActivity.class);
		startActivityForResult(intent, VOICE_RECOGNITION_REQUEST_CODE);
	}

	@Override
	protected void initViews() {
		if (pullRefreshListView != null)
			return;

		etSearch = (ChaoSearchEditText) findViewById(R.id.edit_search);
		btnSearch = (Button) findViewById(R.id.btn_search);

		pullRefreshListView = (PullToRefreshListView) findViewById(R.id.ptrflv_search_commodity);
	}

	@Override
	protected void initData() {
		commodityListAdapter = new CommodityListAdapter(this);
		pullRefreshListView.setAdapter(commodityListAdapter);
		pullRefreshListView.setMode(Mode.PULL_FROM_END);

	}

	@Override
	protected void addListener() {
		etSearch.setOnVoiceRecognitionClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Log.d("CommoditySearchActivity",
						"searchEditText_VoiceRecognitionClick");
				voiceRecognition();
			}
		});
		etSearch.setOnTextChangedListener(new OnTextChangedListener() {

			@Override
			public boolean onTextChange(String text) {
				Log.d("CommoditySearchActivity", "TextChanged_" + text);
				commodityListAdapter.clearItems();
				pageNum = 1;
				return false;
			}
		});


		btnSearch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				keyWord = etSearch.getText().toString();
				refreshData();
			}
		});

		pullRefreshListView
				.setOnRefreshListener(new OnRefreshListener<ListView>() {

					@Override
					public void onRefresh(
							PullToRefreshBase<ListView> pullToRefreshBase) {
						refreshData();
					}

				});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_OK)
			switch (requestCode) { // resultCode为回传的标记，我在B中回传的是RESULT_OK
			case VOICE_RECOGNITION_REQUEST_CODE:
				Bundle b = data.getExtras();
				String str = b.getString(KEY_VOICE_RECOGNITION_STRING);
				Log.d("onActivityResult", "str" + str);
				break;
			default:
				break;
			}
	}

	private void refreshData() {
		this.appAction.listCommodity(pageNum, pageSize, keyWord, "",
				new ActionCallbackListener<List<CommodityBO>>() {
					@Override
					public void onSuccess(List<CommodityBO> data) {
						if (!data.isEmpty()) {
							if (pageNum == 1) { // 第一页
								commodityListAdapter.setItems(data);
							} else { // 分页数据
								commodityListAdapter.addItems(data);
							}
							pageNum++;
							Log.d("refreshData", "data" + data.size() + "data"
									+ data.get(0).getName());
						}
						pullRefreshListView.onRefreshComplete();
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						Toast.makeText(context, message, Toast.LENGTH_SHORT)
								.show();
						pullRefreshListView.onRefreshComplete();
					}
				});
	}

	@Override
	protected int setChaoActionBarId() {
		return 0;
	}


	/* (non-Javadoc)
	 * @see com.chao.chaosearchapp.activity.ChaoBaseActivity#setNetworkTip(boolean, java.lang.String)
	 */
	@Override
	public void setNetworkTip() {
		// TODO Auto-generated method stub
		
	}
}
