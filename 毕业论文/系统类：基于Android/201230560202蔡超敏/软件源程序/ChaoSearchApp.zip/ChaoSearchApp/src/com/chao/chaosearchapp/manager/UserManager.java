/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-17
 */
package com.chao.chaosearchapp.manager;

import java.util.ArrayList;

import org.afinal.simplecache.SimplceCache;

import com.chao.chaosearchapp.ChaoSearchApplication;
import com.chao.chaosearchapp.util.AppUtil;

/**
 * @author chaoking
 * 
 */
public class UserManager {

	private static SimplceCache userCache = SimplceCache.get(
			ChaoSearchApplication.getContext(), "chao_app_user");

	private static String returnDefaultValue(String value, String defaultValue) {
		if (value != null && !"".equals(value))
			return value;
		return defaultValue;
	};

	/**
	 * 是否绑定
	 * 
	 * @return boolean
	 */
	public static boolean isBingAccount() {
		String isBing = getUserId("-1");
		return !"-1".equals(isBing);
	}

	/**
	 * @return the id
	 */
	public static String getUserId(String defaultValue) {
		return returnDefaultValue(userCache.getAsString("userid"), defaultValue);
	}

	/**
	 * 只保存一定时间
	 * 
	 * @param id
	 *            the id to set
	 */
	public static void setUserId(String userId) {
		userCache.put("userid", userId, SimplceCache.TIME_DAY);
	}

	/**
	 * @return the name
	 */
	public static String getUserName(String defaultValue) {
		return returnDefaultValue(userCache.getAsString("username"),
				defaultValue);
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public static void setUserName(String userName) {
		if (userName != null && !"".equals(userName))
			userCache.put("username", userName);
		else
			userCache.put("username", "");
	}

	/**
	 * @return the realName
	 */
	public static String getRealName(String defaultValue) {
		return returnDefaultValue(userCache.getAsString("realname"),
				defaultValue);
	}

	/**
	 * @param realName
	 *            the realName to set
	 */
	public static void setRealName(String realName) {
		if (realName != null && !"".equals(realName))
			userCache.put("realname", realName);
		else
			userCache.put("realname", "");
	}

	/**
	 * @return the email
	 */
	public static String getEmail(String defaultValue) {
		return returnDefaultValue(userCache.getAsString("email"), defaultValue);
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public static void setEmail(String email) {
		if (email != null && !"".equals(email))
			userCache.put("email", email);
		else
			userCache.put("email", "");
	}

	/**
	 * @return the phone
	 */
	public static String getPhone(String defaultValue) {
		return returnDefaultValue(userCache.getAsString("phone"), defaultValue);
	}

	/**
	 * @param phone
	 *            the phone to set
	 */
	public static void setPhone(String phone) {
		if (phone != null && !"".equals(phone))
			userCache.put("phone", phone);
		else
			userCache.put("phone", "");
	}

	/**
	 * @return the birthday
	 */
	public static String getBirthday(String defaultValue) {
		return returnDefaultValue(userCache.getAsString("birthday"),
				defaultValue);
	}

	/**
	 * @param birthday
	 *            the birthday to set
	 */
	public static void setBirthday(String birthday) {
		if (birthday != null && !"".equals(birthday))
			userCache.put("birthday", birthday);
		else
			userCache.put("birthday", "");
	}

	/**
	 * @return the sex
	 */
	public static String getSex(String defaultValue) {
		return returnDefaultValue(userCache.getAsString("sex"), defaultValue);
	}

	/**
	 * @param sex
	 *            the sex to set
	 */
	public static void setSex(String sex) {
		if (sex != null && !"".equals(sex))
			userCache.put("sex", sex);
		else
			userCache.put("sex", "");
	}

	/**
	 * @return the status
	 */
	public static String getStatus(String defaultValue) {
		return returnDefaultValue(userCache.getAsString("status"), defaultValue);
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public static void setStatus(String status) {
		if (status != null && !"".equals(status))
			userCache.put("status", status);
		else
			userCache.put("status", "");
	}

	/**
	 * @return the type
	 */
	public static String getType(String defaultValue) {
		return returnDefaultValue(userCache.getAsString("type"), defaultValue);
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public static void setType(String type) {
		if (type != null && !"".equals(type))
			userCache.put("type", type);
		else
			userCache.put("type", "");
	}

	/**
	 * 清除本地用户信息
	 */
	public static void clearBingAccountInfo() {
		setBirthday("");
		setEmail("");
		setPhone("");
		setRealName("");
		setSex("");
		setStatus("");
		setType("");
		setUserId("-1");
		setUserName("");
	}

	/**
	 * 从本地获取历史搜索关键字
	 * 
	 * @return ArrayList<String>
	 */
	public static ArrayList<String> getHistorySearchKeywords() {
		Object object = userCache.getAsObject(UserManager.getUserId("-1")
				+ "_historySearchKeywords");
		if (object == null) {
			object = new ArrayList<String>();
		}
		return (ArrayList<String>) object;
	}

	/**
	 * 存储多个历史搜索关键字
	 * 
	 * @param historySearchKeywords
	 *            ArrayList<String>
	 */
	public static void setHistorySearchKeywords(
			ArrayList<String> historySearchKeywords) {
		userCache.put(UserManager.getUserId("-1") + "_historySearchKeywords",
				historySearchKeywords);
	}

	/**
	 * 存储历史搜索关键字
	 * 
	 * @param historySearchKeyword
	 *            String
	 */
	public static void setHistorySearchKeyword(String historySearchKeyword) {
		Object object = userCache.getAsObject(UserManager.getUserId("-1")
				+ "_historySearchKeywords");
		if (object != null) {
			ArrayList<String> list = (ArrayList<String>) object;
			list.add(0, historySearchKeyword);
			setHistorySearchKeywords((ArrayList<String>) AppUtil
					.removeDuplicate(list));
		} else {
			ArrayList<String> list = new ArrayList<String>();
			list.add(historySearchKeyword);
			setHistorySearchKeywords(list);
		}
	}

	/**
	 * 从本地清除历史搜索关键字
	 * 
	 * @return ArrayList<String>
	 */
	public static void clearHistorySearchKeywords() {
		setHistorySearchKeywords(null);
	}

}
