package com.chao.chaosearchapp.receiver;

import java.util.Iterator;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import cn.jpush.android.api.JPushInterface;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.activity.BrowserActivity;
import com.chao.chaosearchapp.activity.ChaoMainActivity;
import com.chao.chaosearchapp.activity.CommodityActivity;
import com.chao.chaosearchapp.activity.MessageListActivity;
import com.chao.chaosearchapp.activity.UpdateActivity;
import com.chao.chaosearchapp.manager.MessageManager;
import com.chao.chaosearchapp.manager.UserManager;
import com.chao.chaosearchapp.model.MessageBO;

/**
 * 自定义接收器
 * 
 * 如果不定义这个 Receiver，则： 1) 默认用户会打开主界面 2) 接收不到自定义消息
 */
public class MessageReceiver extends BroadcastReceiver {
	private static final String TAG = "JPush";

	@Override
	public void onReceive(Context context, Intent intent) {
		Bundle bundle = intent.getExtras();
		Log.d(TAG, "[MyReceiver] onReceive - " + intent.getAction()
				+ ", extras: " + printBundle(bundle));

		if (JPushInterface.ACTION_REGISTRATION_ID.equals(intent.getAction())) {
			String regId = bundle
					.getString(JPushInterface.EXTRA_REGISTRATION_ID);
			Log.d(TAG, "[MyReceiver] 接收Registration Id : " + regId);
			// send the Registration Id to your server...

		} else if (JPushInterface.ACTION_MESSAGE_RECEIVED.equals(intent
				.getAction())) {
			Log.d(TAG,
					"[MyReceiver] 接收到推送下来的自定义消息: "
							+ bundle.getString(JPushInterface.EXTRA_MESSAGE));
			// openCustomActivity(context, bundle);

		} else if (JPushInterface.ACTION_NOTIFICATION_RECEIVED.equals(intent
				.getAction())) {
			Log.d(TAG, "[MyReceiver] 接收到推送下来的通知");
			int notifactionId = bundle
					.getInt(JPushInterface.EXTRA_NOTIFICATION_ID);
			Log.d(TAG, "[MyReceiver] 接收到推送下来的通知的ID: " + notifactionId);
			saveMessage(bundle);
		} else if (JPushInterface.ACTION_NOTIFICATION_OPENED.equals(intent
				.getAction())) {
			Log.d(TAG, "[MyReceiver] 用户点击打开了通知");

			openCustomActivity(context, bundle);

		} else if (JPushInterface.ACTION_RICHPUSH_CALLBACK.equals(intent
				.getAction())) {
			Log.d(TAG,
					"[MyReceiver] 用户收到到RICH PUSH CALLBACK: "
							+ bundle.getString(JPushInterface.EXTRA_EXTRA));
			// 在这里根据 JPushInterface.EXTRA_EXTRA 的内容处理代码，比如打开新的Activity，
			// 打开一个网页等..

		} else if (JPushInterface.ACTION_CONNECTION_CHANGE.equals(intent
				.getAction())) {
			boolean connected = intent.getBooleanExtra(
					JPushInterface.EXTRA_CONNECTION_CHANGE, false);
			Log.w(TAG, "[MyReceiver]" + intent.getAction()
					+ " connected state change to " + connected);
		} else {
			Log.d(TAG, "[MyReceiver] Unhandled intent - " + intent.getAction());
		}
	}

	/**
	 * @param bundle
	 */
	private void saveMessage(Bundle bundle) {
		MessageBO message = new MessageBO();

		for (String key : bundle.keySet()) {
			if (key.equals(JPushInterface.EXTRA_EXTRA)) {
				if (bundle.getString(JPushInterface.EXTRA_EXTRA).isEmpty()) {
					Log.i(TAG, "This message has no Extra data");
					continue;
				}
				try {
					JSONObject json = new JSONObject(
							bundle.getString(JPushInterface.EXTRA_EXTRA));
					Iterator<String> it = json.keys();

					while (it.hasNext()) {
						String myKey = it.next().toString();
						String myValue = json.optString(myKey);

						if (myKey != null && myKey.equals("typeId")) {
							message.setTypeId(Integer.parseInt(myValue));
						} else if (myKey != null && myKey.equals("id")) {
							message.setId(Integer.parseInt(myValue));
						}
					}
				} catch (JSONException e) {
					Log.e(TAG, "Get message extra JSON error!");
				}

			} else if (key.equals(JPushInterface.EXTRA_ALERT)) {
				message.setContent(bundle.getString(key));
			} else if (key.equals(JPushInterface.EXTRA_NOTIFICATION_TITLE)) {
				message.setTitle(bundle.getString(key));
			}
		}

		if (message.getTypeId() == 6) {
			UserManager.clearBingAccountInfo();
		} else {
			message.setTime(System.currentTimeMillis());
			// 保存消息
			MessageManager.setMessage(message);
		}
	}

	/**
	 * 
	 // 打开自定义的Activity Intent i = new Intent(context, LoginActivity.class);
	 * i.putExtras(bundle); // i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	 * i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
	 * Intent.FLAG_ACTIVITY_CLEAR_TOP); context.startActivity(i);
	 * 
	 * @param bundle
	 */
	private void openCustomActivity(Context context, Bundle bundle) {

		int typeId = 0;
		int id = 0;
		String content = "";
		String title = "";

		for (String key : bundle.keySet()) {
			if (key.equals(JPushInterface.EXTRA_EXTRA)) {
				if (bundle.getString(JPushInterface.EXTRA_EXTRA).isEmpty()) {
					Log.i(TAG, "This message has no Extra data");
					continue;
				}
				try {
					JSONObject json = new JSONObject(
							bundle.getString(JPushInterface.EXTRA_EXTRA));
					Iterator<String> it = json.keys();

					while (it.hasNext()) {
						String myKey = it.next().toString();
						String myValue = json.optString(myKey);

						if (myKey != null && myKey.equals("typeId")) {
							typeId = Integer.parseInt(myValue);
						} else if (myKey != null && myKey.equals("id")) {
							id = Integer.parseInt(myValue);
						}
					}
				} catch (JSONException e) {
					Log.e(TAG, "Get message extra JSON error!");
				}

			} else if (key.equals(JPushInterface.EXTRA_ALERT)) {
				content = bundle.getString(key);
			} else if (key.equals(JPushInterface.EXTRA_NOTIFICATION_TITLE)) {
				title = bundle.getString(key);
			}
		}
		if (typeId != 0)
			goToActivity(context, typeId, id, title, content);
	}

	/**
	 * @param typeId
	 * @param id
	 * @param content
	 * @param title
	 */
	private void goToActivity(Context context, int typeId, int id,
			String title, String content) {
		Log.d(TAG, "跳转到typeId：" + typeId + "id：" + id + "title:" + title
				+ "content:" + content);
		switch (typeId) {
		case 1:
			// 广告
			Intent aIntent = new Intent(context, BrowserActivity.class);
			aIntent.putExtra(Constants.KEY_BROWSER_TYPE, 11);
			aIntent.putExtra(Constants.KEY_BROWSER_ID, id);
			aIntent.putExtra(Constants.KEY_BROWSER_TITLE, content);
			aIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(aIntent);
			break;
		case 2:
			// 品牌
			Intent bIntent = new Intent(context, BrowserActivity.class);
			bIntent.putExtra(Constants.KEY_BROWSER_TYPE, 12);
			bIntent.putExtra(Constants.KEY_BROWSER_ID, id);
			bIntent.putExtra(Constants.KEY_BROWSER_TITLE, content);
			bIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(bIntent);
			break;
		case 3:
			// 商品
			Intent cIntent = new Intent(context, CommodityActivity.class);
			cIntent.putExtra(Constants.KEY_COMMODITY_TYPE, 1);
			cIntent.putExtra(Constants.KEY_COMMODITY_ID, id);
			cIntent.putExtra(Constants.KEY_COMMODITY_TITLE, content);
			cIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(cIntent);
			break;
		case 4:
			// 检查更新
			Intent updateIntent = new Intent(context, UpdateActivity.class);
			updateIntent.putExtra(Constants.KEY_UPDATE_TYPE, 1);
			updateIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(updateIntent);
			break;
		case 5:
			// 反馈
			Intent fIntent = new Intent(context, MessageListActivity.class);
			fIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(fIntent);
			break;
		default:
			break;
		}
	}

	// 打印所有的 intent extra 数据
	private static String printBundle(Bundle bundle) {
		StringBuilder sb = new StringBuilder();
		for (String key : bundle.keySet()) {
			if (key.equals(JPushInterface.EXTRA_NOTIFICATION_ID)) {
				sb.append("\nkey1:" + key + ", value:" + bundle.getInt(key));
			} else if (key.equals(JPushInterface.EXTRA_CONNECTION_CHANGE)) {
				sb.append("\nkey2:" + key + ", value:" + bundle.getBoolean(key));
			} else if (key.equals(JPushInterface.EXTRA_EXTRA)) {
				if (bundle.getString(JPushInterface.EXTRA_EXTRA).isEmpty()) {
					Log.i(TAG, "This message has no Extra data");
					continue;
				}

				try {
					JSONObject json = new JSONObject(
							bundle.getString(JPushInterface.EXTRA_EXTRA));
					Iterator<String> it = json.keys();

					while (it.hasNext()) {
						String myKey = it.next().toString();
						sb.append("\nkey3:" + key + ", value: [" + myKey
								+ " - " + json.optString(myKey) + "]");
					}
				} catch (JSONException e) {
					Log.e(TAG, "Get message extra JSON error!");
				}

			} else {
				sb.append("\nkey4:" + key + ", value:" + bundle.getString(key));
			}
		}
		return sb.toString();
	}

	// send msg to MainActivity
	private void processCustomMessage(Context context, Bundle bundle) {
		if (ChaoMainActivity.isForeground) {
			// String message = bundle.getString(JPushInterface.EXTRA_MESSAGE);
			// String extras = bundle.getString(JPushInterface.EXTRA_EXTRA);
			// Intent msgIntent = new Intent(
			// "ChaoMainActivity.MESSAGE_RECEIVED_ACTION");
			// msgIntent.putExtra(ChaoMainActivity.KEY_MESSAGE, message);
			// if (!ExampleUtil.isEmpty(extras)) {
			// try {
			// JSONObject extraJson = new JSONObject(extras);
			// if (null != extraJson && extraJson.length() > 0) {
			// msgIntent.putExtra(ChaoMainActivity.KEY_EXTRAS, extras);
			// }
			// } catch (JSONException e) {
			//
			// }
			//
			// }
			// context.sendBroadcast(msgIntent);
		}
	}
}
