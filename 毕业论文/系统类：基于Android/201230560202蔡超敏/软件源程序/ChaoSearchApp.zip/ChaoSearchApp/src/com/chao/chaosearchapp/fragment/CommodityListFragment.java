/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-27
 */
package com.chao.chaosearchapp.fragment;

import java.util.Iterator;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.chao.chaosearchapp.Constants;
import com.chao.chaosearchapp.R;
import com.chao.chaosearchapp.activity.BrowserActivity;
import com.chao.chaosearchapp.activity.CommodityActivity;
import com.chao.chaosearchapp.adapter.CommodityListAdapter;
import com.chao.chaosearchapp.core.ActionCallbackListener;
import com.chao.chaosearchapp.listener.OnObjectClickListener;
import com.chao.chaosearchapp.model.CommodityBO;
import com.chao.chaosearchapp.model.PriceBO;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.Mode;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener;
import com.handmark.pulltorefresh.library.PullToRefreshListView;

/**
 * @author chaoking
 * 
 */
public class CommodityListFragment extends ChaoBaseFragment {

	private String keyWord = "";
	private int pageNum = 1;
	private int pageSize = 10;

	private PullToRefreshListView pullRefreshListView;
	private CommodityListAdapter commodityListAdapter;

	@Override
	protected View initFragment(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_commodity_list,
				container, false);
		return view;
	}

	@Override
	protected void initViews(View view) {
		pullRefreshListView = (PullToRefreshListView) view
				.findViewById(R.id.ptrflv_commodity_list);
	}

	@Override
	protected void initData() {
		commodityListAdapter = new CommodityListAdapter(mActivity);
		pullRefreshListView.setAdapter(commodityListAdapter);
		pullRefreshListView.setMode(Mode.PULL_FROM_END);

		keyWord = mActivity.getChaoActionBar().getChaoSearchEditText()
				.getText().toString();
		showLoadingDialog("加载数据");
		refreshData();
	}

	@Override
	protected void addListener() {
		pullRefreshListView
				.setOnRefreshListener(new OnRefreshListener<ListView>() {

					@Override
					public void onRefresh(
							PullToRefreshBase<ListView> pullToRefreshBase) {
						refreshData();
					}

				});
		commodityListAdapter
				.setOnPriceClickListener(new OnObjectClickListener<PriceBO>() {

					@Override
					public void OnClick(View view, PriceBO obj) {
						if (obj != null && obj.getUrl() != null) {
							String link = obj.getUrl();
							if (Patterns.WEB_URL.matcher(link).matches()) {
								// makeToast("链接符合标准"+obj.getUrl());
								// 符合标准
								Intent webIntent = new Intent(mActivity,
										BrowserActivity.class);
								webIntent.putExtra(Constants.KEY_BROWSER_LINK,
										link);
								webIntent.putExtra(Constants.KEY_BROWSER_TITLE,
										obj.getStore().getName());
								webIntent.putExtra(Constants.KEY_BROWSER_TYPE,
										0);
								webIntent.putExtra(
										Constants.KEY_BROWSER_PRICEBO, obj);
								// webIntent
								// .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
								startActivity(webIntent);
							} else {
								// 不符合标准
								makeToast("链接不符合标准" + obj.getUrl());
							}
						}
					}
				});
		pullRefreshListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				CommodityBO commodityBO = (CommodityBO) commodityListAdapter
						.getItem(position - 1);
				Intent intent = new Intent(mActivity, CommodityActivity.class);
				intent.putExtra(Constants.KEY_COMMODITY_TYPE, 1);
				intent.putExtra(Constants.KEY_COMMODITY_ID, commodityBO.getId());
				intent.putExtra(Constants.KEY_COMMODITY_TITLE,
						commodityBO.getName());
				intent.putExtra(Constants.KEY_COMMODITY_COMMODITYBO,
						commodityBO);
				// intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intent);
			}
		});
	}

	// @Override
	// public void onActivityResult(int requestCode, int resultCode, Intent
	// data) {
	// switch (requestCode) {
	// case 0:
	// CommodityBO commodityBO = (CommodityBO) data
	// .getSerializableExtra(Constants.KEY_COMMODITY_COMMODITYBO);
	// int index = commodityListAdapter.getItems().indexOf(commodityBO);
	// CommodityBO commodityBO2 = commodityListAdapter.getItems().get(
	// index);
	//
	// if (commodityBO2.isCollected() && !commodityBO.isCollected()) {
	// commodityBO2.setIsCollected(0);
	// } else if (!commodityBO2.isCollected() && commodityBO.isCollected()) {
	// commodityBO2.setIsCollected(1);
	// }
	// // makeToast(commodityBO2.getName());
	// break;
	// case 1:
	// PriceBO priceBO = (PriceBO) data
	// .getSerializableExtra(Constants.KEY_BROWSER_PRICEBO);
	// for (Iterator<CommodityBO> iterator = commodityListAdapter
	// .getItems().iterator(); iterator.hasNext();) {
	// CommodityBO bo = iterator.next();
	// int index2 = bo.getPrices().indexOf(priceBO);
	// if (bo.getPrices() != null && index2 != -1) {
	// PriceBO priceBO2 = bo.getPrices().get(index2);
	// if (priceBO2.isCollected() && !priceBO.isCollected()) {
	// priceBO2.setIsCollected(0);
	// } else if (!priceBO2.isCollected() && priceBO.isCollected()) {
	// priceBO2.setIsCollected(1);
	// }
	// }
	// }
	// // makeToast(commodityBO2.getName());
	// break;
	// default:
	// break;
	// }
	// super.onActivityResult(requestCode, resultCode, data);
	// }

	/**
	 * 从网络加载数据并更新listview
	 */
	private void refreshData() {
		mActivity.appAction.listCommodity(pageNum, pageSize, keyWord, "",
				new ActionCallbackListener<List<CommodityBO>>() {
					@Override
					public void onSuccess(List<CommodityBO> data) {
						if (data != null && !data.isEmpty()) {
							if (pageNum == 1) { // 第一页
								commodityListAdapter.setItems(data);
							} else { // 分页数据
								commodityListAdapter.addItems(data);
							}
							pageNum++;
							Log.d("refreshData", "data" + data.size() + "data"
									+ data.get(0).getName());
						} else {
							makeToast("没有更多数据了");
						}
						pullRefreshListView.onRefreshComplete();
					}

					@Override
					public void onFailure(String errorEvent, String message) {
						makeToast(message);
						pullRefreshListView.onRefreshComplete();
					}
				});
	}

}
