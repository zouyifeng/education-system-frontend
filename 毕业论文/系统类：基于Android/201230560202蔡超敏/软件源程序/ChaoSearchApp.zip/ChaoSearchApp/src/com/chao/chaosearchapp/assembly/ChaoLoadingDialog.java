/**
 * Copyright (c) 华南农业大学数学与信息学院蔡超敏2016版权所有
 * 
 * 文件创建时间：2016-3-24
 */
package com.chao.chaosearchapp.assembly;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.chao.chaosearchapp.R;

/**
 * @author chaoking
 *
 */
public class ChaoLoadingDialog extends Dialog {

	private TextView tvLoading;
	private ImageView loading;

	public ChaoLoadingDialog(Context context) {
		super(context);
		
		getContext().setTheme(R.style.AppTheme_DialogStyle);
		setContentView(R.layout.dialog_loading);
		setCanceledOnTouchOutside(true);
		tvLoading = (TextView) this.findViewById(R.id.tv_loading);
		loading = (ImageView) this.findViewById(R.id.loading);
	}

	private void start() {
		AnimationDrawable rocketAnimation = (AnimationDrawable) loading.getBackground();
		rocketAnimation.start();
	}
	
	public void show(String text) {
		setLoadText(text);
		show();
	}
	
	@Override
	public void show() {
		start();
		super.show();
	}
	
	private void setLoadText(String text) {
		tvLoading.setVisibility(View.GONE);
		if (text != null && !"".equals(text)){
			tvLoading.setText(text);
			tvLoading.setVisibility(View.VISIBLE);
		}
	}

}