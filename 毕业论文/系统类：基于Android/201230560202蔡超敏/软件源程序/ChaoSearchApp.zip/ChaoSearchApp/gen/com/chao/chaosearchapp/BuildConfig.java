/** Automatically generated file. DO NOT MODIFY */
package com.chao.chaosearchapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}