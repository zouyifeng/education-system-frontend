package action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import model.UploadFileInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import pageModel.BStudent;
import pageModel.CodeNode;
import pageModel.DataGrid;
import pageModel.JsonResult;
import pageModel.TStudent;
import service.StudentServiceI;
import service.TcrelationServiceI;

/**
 * TODO 类/接口描述信息
 * 
 * @author LevenGuo
 * 
 */
@Controller("studentAction")
@RequestMapping("/studentAction")
public class StudentAction {

	@Autowired
	private StudentServiceI studentService;
	
	@Autowired
	private TcrelationServiceI tcrelationService;

	@InitBinder
	private void dateBinder(WebDataBinder binder) {
		// The date format to parse or output your dates
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		// Create a new CustomDateEditor
		CustomDateEditor editor = new CustomDateEditor(dateFormat, true);
		// Register it as custom editor for the Date type
		binder.registerCustomEditor(Date.class, editor);
	}

	@RequestMapping(value = "/datagrid")
	@ResponseBody
	public DataGrid datagrid(TStudent tstudent) {
		// 注意前台与后台Date类型的绑定,String类型默认NULL,但StudentService层的值为空值
		// @RequestBody接收对象型标准JSON字符串装填Bean,不是接收对象
		return studentService.datagrid(tstudent);
	}
	
	@RequestMapping(value = "/saveStudent")
	@ResponseBody
	public JsonResult saveStudent(TStudent tstudent){
		JsonResult j=new JsonResult();
		try {
			studentService.saveStudent(tstudent);   	
			j.setSuccess(true);
			j.setMsg("添加成功!");
		} catch (Exception e) {
			e.printStackTrace();
			j.setMsg("添加失败!");
		}
		return j;		
	}
	
	@RequestMapping(value = "/editStudent")
	@ResponseBody
	public JsonResult editStudent(TStudent tstudent){
		JsonResult j=new JsonResult();
		try {
			studentService.editStudent(tstudent);   	
			j.setSuccess(true);
			j.setMsg("编辑成功!");
		} catch (Exception e) {
			e.printStackTrace();
			j.setMsg("编辑失败!");
		}
		return j;		
	}
	
	@RequestMapping(value = "/updateStudentState")
	@ResponseBody
	public JsonResult updateStudentState(TStudent tstudent){
		JsonResult j=new JsonResult();
		try {
			studentService.updateStudentState(tstudent);   	
			j.setSuccess(true);
			j.setMsg("更新成功!");
		} catch (Exception e) {
			e.printStackTrace();
			j.setMsg("更新失败!");
		}
		return j;		
	}
	
	@RequestMapping(value = "/loginStudent")
	public String loginStudent(BStudent bstudent,HttpSession session){
		BStudent b=studentService.login(bstudent);
		session.setAttribute("user", b);
		session.setAttribute("identity",1);
		List<CodeNode> l=tcrelationService.findAllCcode();
		session.setAttribute("ccodeList", l);
		List<CodeNode> lt=tcrelationService.findAllTcode();
		session.setAttribute("tcodeList", lt);
		return "/newIndex";		
	}
	
	@RequestMapping(value = "/studentCenterList")
	public String studentCenterList(){
		return "/foreground/studentCenterList";		
	}
	
	@RequestMapping(value = "/updateStudentPassword")
	public String updateStudentPassword(String id,String spassword,String newPassword,HttpSession session){
		BStudent b=studentService.updateStudentPassword(id,spassword,newPassword);
		session.removeAttribute("user");
		session.setAttribute("user", b);
		return "/foreground/studentCenterList";		
	}
	
	@RequestMapping(value="studentListExcel",method = RequestMethod.GET)
    public String studentListExcel(Model model,TStudent tstudent) {
        List<TStudent> lists = studentService.findExcelStudent(tstudent);
        String filename = "学生信息表";
        String jspPath = "studentListExcel";
        model.addAttribute("lists", lists);
        model.addAttribute("filename", filename);
        model.addAttribute("jspPath", jspPath);
        return "/background/common/excel";
    }
		
	@RequestMapping(value = "/importStudentExcel")
	@ResponseBody
	public JsonResult importStudentExcel(MultipartHttpServletRequest request){
		JsonResult j=new JsonResult();
		for (MultipartFile file : request.getFileMap().values()){
            try {
            	studentService.importStudentExcel(file);
            	j.setSuccess(true);
    			j.setMsg("更新成功!");
            } catch (Exception e) {
            	e.printStackTrace();
    			j.setMsg("更新失败!");
            }
        }	
		return j;	
	}
}