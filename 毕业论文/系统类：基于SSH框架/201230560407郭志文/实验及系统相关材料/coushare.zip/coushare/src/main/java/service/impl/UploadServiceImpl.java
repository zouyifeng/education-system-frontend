package service.impl;


import model.Course;
import model.UploadFileInfo;
import service.UploadServiceI;
import util.Page;
import util.PathUtil;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import pageModel.BCourse;
import pageModel.Chart;
import pageModel.FileCriteria;
import pageModel.Highchart;
import pageModel.TCourse;
import dao.UploadDaoI;

import javax.annotation.Resource;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * @Author: guozhiwen
 * @File: UploadServiceImpl.java
 * @DATE: 2016-01-22
 * @TIME: 14:23
 */
@Service
public class UploadServiceImpl implements UploadServiceI{

    @Resource
    private UploadDaoI uploadDao;

    @Override
    public UploadFileInfo saveFile(MultipartFile uploadFile,
                                   String baseUploadPath, String otherUploadPath, String recordId,
                                   String recordCode, String uploader) throws IOException {
        if (uploadFile == null) {
            return null;
        }
        otherUploadPath = PathUtil.wrapperPath(otherUploadPath);
        String path = baseUploadPath + PathUtil.wrapperPath(recordCode)
                + otherUploadPath;
        UploadFileInfo uploadFileInfo = builtUploadFileInfo(uploadFile,
                otherUploadPath, recordId, recordCode, uploader);

        // 读取指定文件夹
        File newFile = new File(path);
        // 防止文件夹不存在
        if (!newFile.exists()) {
            // 生成新的文件目录
            newFile.mkdirs();
        }
        if ("".equals(recordCode) || recordCode == null){
            path = path + "/";
        }
        FileCopyUtils.copy(uploadFile.getBytes(), new FileOutputStream(
                path + uploadFileInfo.getFileNewName()));
        uploadDao.save(uploadFileInfo);

        return uploadFileInfo;
    }

    /**
     * 建立完善上传文件信息类对象
     *
     * @param uploadFile      上传的文件对象
     * @param otherUploadPath 自定义的文件路径
     * @param recordId        记录主键
     * @param recordCode      记录编码（若是记录主键是联合主键，则把联合主键拼接，否则和记录主键值相同）
     * @param uploader        上传文件者
     * @return 上查文件信息类对象
     */
    public UploadFileInfo builtUploadFileInfo(MultipartFile uploadFile,
                                              String otherUploadPath, String recordId, String recordCode,
                                              String uploader) {
        UploadFileInfo uploadFileInfo = new UploadFileInfo();

        long currentTime = System.currentTimeMillis();

        uploadFileInfo.setFileName(uploadFile.getOriginalFilename());
        uploadFileInfo.setFileType(uploadFile.getContentType());
        uploadFileInfo.setFileSize(uploadFile.getSize() + "");
        // 保存的是自定义路径（“/**/”的形式）+重命名文件名
        uploadFileInfo.setFileNewName(otherUploadPath
                + getNewFileName(currentTime, uploadFileInfo.getFileName(),
                uploader));
        uploadFileInfo.setRecordId(recordId);
        uploadFileInfo.setRecordCode(recordCode);
        uploadFileInfo.setCreator(uploader);
        uploadFileInfo.setCreateTime(new Timestamp(currentTime));
        uploadFileInfo.setLastUpdateTime(new Timestamp(currentTime));
        uploadFileInfo.setOperator(uploader);
        
        uploadFileInfo.setCount(0);

        return uploadFileInfo;
    }

    /**
     * 获得新的文件名
     *
     * @param currentTime      当前系统时间
     * @param originalFilename 原始文件名
     * @param uploader         上传文件者
     * @return 新的文件名
     */
    private String getNewFileName(long currentTime, String originalFilename,
                                  String uploader) {
        return currentTime + "_" + uploader + "_" + getIntRandom()
                + getExtFileName(originalFilename);
    }

    /**
     * 获得文件扩展名
     *
     * @param originalFilename 包含文件扩展名的原始文件名
     * @return 文件扩展名
     */
    private String getExtFileName(String originalFilename) {
        return originalFilename.substring(originalFilename.lastIndexOf("."));
    }

    /**
     * 获得随机数
     *
     * @return 10000~99999之间的随机整数
     */
    private int getIntRandom() {
        Random rd = new Random();
        return (int) (rd.nextDouble() * (99999 - 10000 + 1)) + 10000;
    }

    @Override
    public List<UploadFileInfo> findUploadList(String recordCode, String recordId) {
    //    return uploadDao.findUploadFileInfoByRecordCodeAndRecordId(recordCode, recordId);
    	String hql = "from UploadFileInfo u where 1=1";
		Map<String, Object> params = new HashMap<String, Object>();
		if (recordCode != null && !recordCode.equals("")) {
			hql += " and u.recordCode =:recordCode";
			params.put("recordCode",recordCode);
		}
/*		if (recordId != null && !recordId.equals("")) {
			hql += " and u.recordId =:recordId";
			params.put("recordId",recordId);
		}*/
		List<UploadFileInfo> l=uploadDao.find(hql, params);
		return l;
    }

    /**
     * 根据文件Id查找相应的文件记录
     *
     * @param id 文件Id
     * @return 文件信息类对象
     */
    public UploadFileInfo obtainUploadFileInfoById(Integer id) {
    //    return uploadDao.findOne(Long.valueOf(id));
    	return uploadDao.get(UploadFileInfo.class,id);
    }

    /**
     * 删除文件和数据库表里的记录
     *
     * @param id         文件Id
     * @param baseUploadPath 基础路径
     * @return 是否删除成功
     */
    public Boolean deleteUploadFile(Integer id, String baseUploadPath) {
        Boolean isDelete = Boolean.FALSE;
        UploadFileInfo fileInfo = obtainUploadFileInfoById(id);
        if (deleteUploadFileInfoById(id)) {
            String wholeFilePath = baseUploadPath + "/"
                    + PathUtil.wrapperPath(fileInfo.getRecordCode())
                    + fileInfo.getFileNewName();
            File file = new File(wholeFilePath);
            if (file.exists()) {
                file.delete();
            }
            isDelete = Boolean.TRUE;
        }
        return isDelete;
    }

    /**
     * 根据上传文件的ID删除上传文件信息表里的记录
     *
     * @param id 上传文件的Id
     * @return 数据库表的记录是否删除成功
     */
    private Boolean deleteUploadFileInfoById(Integer id) {
        Boolean isDelete = Boolean.FALSE;
        if (!isDelete) {
        //    uploadDao.delete(Long.valueOf(id));
        	String hql = "delete UploadFileInfo u where u.id=:id";
        	Map<String, Object> params = new HashMap<String, Object>();    		
    		params.put("id",id);    		
        	uploadDao.executeHql(hql, params);
            isDelete = Boolean.TRUE;
        }
        return isDelete;
    }

	@Override
	public void updateFileDownloadCount(Integer id) {
		UploadFileInfo fileInfo = uploadDao.get(UploadFileInfo.class,id);;
		fileInfo.setCount(fileInfo.getCount()+1);
	}

	@Override
	public Page<UploadFileInfo> findFileByPage(FileCriteria fc) {
		String hql = "from UploadFileInfo u where 1=1";
		Map<String, Object> params = new HashMap<String, Object>();
		if (fc.getFileName() != null && !fc.getFileName().trim().equals("")) {
			hql += " and u.fileName like :fileName";
			params.put("fileName", "%%" + fc.getFileName().trim() + "%%");
		}
		if (fc.getCcode() != null && !fc.getCcode().equals("")) {
			hql += " and u.recordId =:recordId";
			params.put("recordId",fc.getCcode());
		}
		if (fc.getTcode() != null && !fc.getTcode().equals("")) {
			hql += " and u.recordCode =:recordCode";
			params.put("recordCode",fc.getTcode());
		}
		String totalHql = "select count(*) " + hql;
		List<UploadFileInfo> l = uploadDao.find(hql, params, fc.getCurrentPage(),fc.getPageSize());		
		Page<UploadFileInfo> page=new Page<UploadFileInfo>();
		page.setCurrentPage(fc.getCurrentPage());
		page.setPageSize(fc.getPageSize());
		page.setTotalSize(uploadDao.count(totalHql, params).intValue());
		page.setRecords(l);
		return page;
	}

	@Override
	public List<UploadFileInfo> findFileByCcode(String ccode) {
		String hql = "from UploadFileInfo u where 1=1";
		Map<String, Object> params = new HashMap<String, Object>();
		if (ccode != null && !ccode.equals("")) {
			hql += " and u.recordId =:ccode";
			params.put("ccode",ccode);
		}		
		List<UploadFileInfo> l = uploadDao.find(hql, params);
		return l;
	}

	@Override
	public List<UploadFileInfo> findTopFile() {
		String hql = "from UploadFileInfo u order by u.count desc";
		List<UploadFileInfo> l=uploadDao.find(hql, 0, 5);
		return l;
	}

	@Override
	public Chart findTopFileChart() {
		String hql = "select new Map(u.fileName as fileName,u.count as count) from UploadFileInfo u order by u.count desc";
		List<Map<String, Object>> list=uploadDao.findByMap(hql, 0, 5);
		List<String> categories=new ArrayList<>();
		List<Object> listdata=new ArrayList<>();
		for(Map<String, Object> map : list){
			categories.add((String) map.get("fileName"));
			listdata.add(map.get("count"));
		}
		Chart c=new Chart();
		c.setCategories(categories);
		Highchart h=new Highchart();
		h.setName("下载量");
		h.setData(listdata);
		c.setHighchart(h);
		return c;
	}
}
