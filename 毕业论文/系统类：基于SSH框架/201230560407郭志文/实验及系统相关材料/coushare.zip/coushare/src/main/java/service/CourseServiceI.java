package service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import pageModel.BCourse;
import pageModel.Chart;
import pageModel.CourseCriteria;
import pageModel.DataGrid;
import pageModel.TCourse;
import util.Page;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public interface CourseServiceI {

	public DataGrid datagrid(TCourse tcourse);
	public void saveCourse(TCourse tcourse);
	public void editCourse(TCourse tcourse);
	public void updateCourseState(TCourse tcourse);
	public Page<BCourse> findCousrseByPage(CourseCriteria cc);
	public BCourse findCourseById(String id);
	public void updateCourseGoodByCid(String id);
	public List<TCourse> findExcelCourse(TCourse tcourse);
	public void importCourseExcel(MultipartFile file) throws IOException;
	public List<TCourse> findTopCourse();
	public Chart findTopCourseChart();
}

