package service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.Comments;
import model.Course;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pageModel.BComment;
import pageModel.TCourse;
import dao.CommentDaoI;
import service.CommentServiceI;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Service("commentService")
public class CommentServiceImpl implements CommentServiceI{
	
	@Autowired
	private CommentDaoI commentDao;

	@Override
	public List<BComment> findCommentByCourseid(String id) {
		String hql = "from Comments c where c.course.id=:id order by c.commentdate asc";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", Integer.valueOf(id));
		List<Comments> l=commentDao.find(hql, params);
		List<BComment> lt = new ArrayList<BComment>();
		if (l != null && l.size() > 0) {
			for (Comments c : l) {
				BComment b = new BComment();
				BeanUtils.copyProperties(c, b);
				b.setCourseid(c.getCourse().getId());
				b.setCoursecode(c.getCourse().getCcode());
				lt.add(b);
			}
		}
		return lt;
	}

	@Override
	public BComment saveComment(BComment bcomment) {
		Comments c=new Comments();
		BeanUtils.copyProperties(bcomment,c);
		c.setCommentdate(new Date());
		Course course=new Course();
		course.setId(bcomment.getCourseid());
		c.setCourse(course);
		commentDao.save(c);
		BeanUtils.copyProperties(c,bcomment);
		return bcomment;
	}

	@Override
	public void removeCommentById(String id) {
		String hql = "delete Comments c where c.id=:id";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", Integer.valueOf(id));
		commentDao.executeHql(hql, params);
	}

}

