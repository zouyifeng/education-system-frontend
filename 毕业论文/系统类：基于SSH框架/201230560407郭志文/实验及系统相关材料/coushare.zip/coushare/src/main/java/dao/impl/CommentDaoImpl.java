package dao.impl;

import org.springframework.stereotype.Repository;

import model.Comments;
import dao.CommentDaoI;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Repository("commentDao")
public class CommentDaoImpl extends BaseDaoImpl<Comments> implements CommentDaoI{

}

