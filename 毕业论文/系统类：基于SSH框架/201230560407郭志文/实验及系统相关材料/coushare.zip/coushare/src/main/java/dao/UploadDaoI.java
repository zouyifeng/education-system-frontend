package dao;

import model.UploadFileInfo;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public interface UploadDaoI extends BaseDaoI<UploadFileInfo>{

}

