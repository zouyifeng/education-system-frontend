package service;

import model.UploadFileInfo;

import org.springframework.web.multipart.MultipartFile;

import pageModel.Chart;
import pageModel.FileCriteria;
import util.Page;

import java.io.IOException;
import java.util.List;

/**
 * @Author: guozhiwen
 * @File: UploadService.java
 * @DATE: 2016-01-22
 * @TIME: 14:23
 */
public interface UploadServiceI {
    UploadFileInfo saveFile(MultipartFile uploadFile, String baseUploadPath,
                            String otherUploadPath, String recordId, String recordCode,
                            String uploader) throws IOException;

    List<UploadFileInfo> findUploadList(String recordCode, String recordId);

    UploadFileInfo obtainUploadFileInfoById(Integer id);

    Boolean deleteUploadFile(Integer id, String baseUploadPath);
    
    public void updateFileDownloadCount(Integer id);
	public Page<UploadFileInfo> findFileByPage(FileCriteria fc);
	public List<UploadFileInfo> findFileByCcode(String ccode);
	public List<UploadFileInfo> findTopFile();
	public Chart findTopFileChart();
}
