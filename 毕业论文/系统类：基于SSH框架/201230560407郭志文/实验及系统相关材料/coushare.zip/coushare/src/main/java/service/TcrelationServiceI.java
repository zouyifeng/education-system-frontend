package service;

import java.util.List;

import pageModel.CodeNode;
import pageModel.ComboboxNode;
import pageModel.DataGrid;
import pageModel.TTcrelation;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public interface TcrelationServiceI {

	public DataGrid datagrid(TTcrelation ttcrelation);
	public List<ComboboxNode> findAllTeacherId();
	public List<ComboboxNode> findAllCourseId();
	public void saveTcrelation(TTcrelation ttcrelation);
	public boolean existRelation(TTcrelation ttcrelation);
	public void deleteTcrelation(String ids);
	
	public List<CodeNode> findTcrelationByTeacherid(Integer id);
	public List<CodeNode> findAllCcode();
	public List<CodeNode> findAllTcode();
}

