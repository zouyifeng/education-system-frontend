package service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import pageModel.BStudent;
import pageModel.DataGrid;
import pageModel.JsonResult;
import pageModel.TStudent;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public interface StudentServiceI {

	public DataGrid datagrid(TStudent tstudent);
	public void saveStudent(TStudent tstudent);
	public void editStudent(TStudent tstudent);
	public void updateStudentState(TStudent tstudent);
	public BStudent login(BStudent bstudent);
	public BStudent updateStudentPassword(String id, String spassword,String newPassword);
	public List<TStudent> findExcelStudent(TStudent tstudent);
	public void importStudentExcel(MultipartFile file) throws IOException;
}