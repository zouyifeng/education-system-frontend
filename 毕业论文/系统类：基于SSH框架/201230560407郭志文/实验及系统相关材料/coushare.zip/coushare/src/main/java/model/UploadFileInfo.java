package model;

import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @Author: guozhiwen
 * @File: UploadFileInfo.java
 * @DATE: 2016-01-21
 * @TIME: 16:23
 */
@Entity
@DynamicUpdate
@Table(name = "uploadfileinfo",catalog = "coushare")
public class UploadFileInfo extends IdEntity implements Serializable {

    private String fileName;
    private String fileType;
    private String fileSize;
    private String fileNewName;
    private String recordId;
    private String recordCode;
    private Timestamp createTime;
    private Timestamp lastUpdateTime;
    private String creator;
    private String operator;

    private String error;
    
    private Integer count;

    @Column(name = "FILENAME")
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @Column(name = "FILETYPE")
    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    @Column(name = "FILESIZE")
    public String getFileSize() {
        return fileSize;
    }

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize;
    }

    @Column(name = "FILENEWNAME")
    public String getFileNewName() {
        return fileNewName;
    }

    public void setFileNewName(String filePath) {
        this.fileNewName = filePath;
    }

    @Column(name = "RECORDID")
    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    @Column(name = "RECORDCODE")
    public String getRecordCode() {
        return recordCode;
    }

    public void setRecordCode(String recordCode) {
        this.recordCode = recordCode;
    }

    @Column(name = "CREATETIME")
    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    @Column(name = "LASTUPDATETIME")
    public Timestamp getLastUpdateTime() {
        return lastUpdateTime;
    }

    public void setLastUpdateTime(Timestamp lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    @Column(name = "CREATOR")
    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    @Column(name = "OPERATOR")
    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    @Column(name = "COUNT")
    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
    
    @Transient
    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    @Transient
    public String getUrl() {
        if (id == null) {
            return "";
        }
        return "../upload/downloadFile.do?id=" + id;
    }

    @Transient
    public String getThumbnailUrl() {
        if (id == null) {
            return "";
        }
        return "../upload/downloadFile.do?id=" + id;
    }

    @Transient
    public String getName() {
        return fileName;
    }

    @Transient
    public String getType() {
        return fileType;
    }

    @Transient
    public Long getSize() {
        if (fileSize == null) {
            return null;
        }
        return new Long(fileSize);
    }

    @Transient
    public String getDeleteUrl() {
        if (id == null) {
            return "";
        }
        return "../upload/ajax/deleteFile.do?id=" + id;
    }

    @Transient
    public String getDeleteType() {
        return "DELETE";
    }
}
