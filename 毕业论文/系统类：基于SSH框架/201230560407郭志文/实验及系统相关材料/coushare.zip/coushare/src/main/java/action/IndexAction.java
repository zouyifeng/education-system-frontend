package action;

import java.util.List;

import javax.annotation.Resource;

import model.UploadFileInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pageModel.Chart;
import pageModel.DataGrid;
import pageModel.TCourse;
import service.CourseServiceI;
import service.UploadServiceI;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Controller("indexAction")
@RequestMapping("/indexAction")
public class IndexAction {
	
	@Autowired
    private CourseServiceI courseService;
	
	@Resource
    private UploadServiceI uploadService;
	
	@RequestMapping("index")
	public String index(Model model){
		List<TCourse> l=courseService.findTopCourse();
		List<UploadFileInfo> lt=uploadService.findTopFile();
		model.addAttribute("topCourse", l);
		model.addAttribute("topFile", lt);
		return "/index";
	}
	
	@RequestMapping(value = "/findTopFileChart")
	@ResponseBody
	public Chart findTopFileChart(){
		return uploadService.findTopFileChart();
	}

	@RequestMapping(value = "/findTopCourseChart")
	@ResponseBody
	public Chart findTopCourseChart(){
		return courseService.findTopCourseChart();
	}
}

