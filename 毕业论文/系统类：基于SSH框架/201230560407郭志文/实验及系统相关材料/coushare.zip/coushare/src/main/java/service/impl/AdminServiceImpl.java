package service.impl;

import java.util.HashMap;
import java.util.Map;

import model.Admin;
import model.Student;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.AdminDaoI;
import pageModel.TAdmin;
import service.AdminServiceI;
import util.MD5Util;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Service("adminService")
public class AdminServiceImpl implements AdminServiceI{
	
	@Autowired
	private AdminDaoI adminDao;

	@Override
	public TAdmin login(TAdmin tadmin) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("name",tadmin.getName());
		params.put("password",MD5Util.md5(tadmin.getPassword()));
		Admin a= adminDao.get("from Admin a where a.name=:name and a.password=:password",params);
		if (a != null) {
			BeanUtils.copyProperties(a, tadmin);
			return tadmin;
		}
		return null;
	}

	@Override
	public TAdmin updateAdminPassword(TAdmin tadmin) {
		Admin a=adminDao.get(Admin.class,tadmin.getId());
		a.setPassword(MD5Util.md5(tadmin.getPassword()));
		BeanUtils.copyProperties(a, tadmin);
		return tadmin;
	}

}