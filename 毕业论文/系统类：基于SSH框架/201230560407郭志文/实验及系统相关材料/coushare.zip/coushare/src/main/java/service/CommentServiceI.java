package service;

import java.util.List;

import pageModel.BComment;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public interface CommentServiceI {

	public List<BComment> findCommentByCourseid(String id);
	public BComment saveComment(BComment bcomment);
	public void removeCommentById(String id);

}

