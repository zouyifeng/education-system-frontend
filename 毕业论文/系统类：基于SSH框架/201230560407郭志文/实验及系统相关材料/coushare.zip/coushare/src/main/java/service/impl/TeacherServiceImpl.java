package service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.Student;
import model.Teacher;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import dao.TeacherDaoI;
import pageModel.BStudent;
import pageModel.BTeacher;
import pageModel.DataGrid;
import pageModel.TStudent;
import pageModel.TTeacher;
import service.TeacherServiceI;
import util.MD5Util;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Service("teacherService")
public class TeacherServiceImpl implements TeacherServiceI{
	
	@Autowired
	private TeacherDaoI teacherDao;

	@Override
	public DataGrid datagrid(TTeacher tteacher) {
		DataGrid dg = new DataGrid();
		String hql = "from Teacher t where 1=1";
		Map<String, Object> params = new HashMap<String, Object>();
		hql = addWhere(tteacher, hql, params);
		String totalHql = "select count(*) " + hql;
		hql = addOrder(tteacher, hql);
		List<Teacher> l = teacherDao.find(hql, params, tteacher.getPage(),
				tteacher.getRows());
		List<TTeacher> lt = new ArrayList<TTeacher>();
		exchangeModel(l, lt);
		dg.setTotal(teacherDao.count(totalHql, params));
		dg.setRows(lt);
		return dg;
	}

	private String addWhere(TTeacher tteacher, String hql, Map<String, Object> params) {
		if (tteacher.getTcode() != null
				&& !tteacher.getTcode().trim().equals("")) {
			hql += " and t.tcode =:tcode";
			params.put("tcode", tteacher.getTcode().trim());
		}
		if (tteacher.getTname() != null
				&& !tteacher.getTname().trim().equals("")) {
			hql += " and t.tname like :tname";
			params.put("tname", "%%" + tteacher.getTname().trim() + "%%");
		}
		if (tteacher.getSex() != null && !tteacher.getSex().trim().equals("")) {
			hql += " and t.sex =:sex";
			params.put("sex", tteacher.getSex());
		}
		if (tteacher.getCollege() != null
				&& !tteacher.getCollege().trim().equals("")) {
			hql += " and t.college =:college";
			params.put("college", tteacher.getCollege());
		}
		if (tteacher.getTstate() != null
				&& !tteacher.getTstate().trim().equals("")) {
			hql += " and t.tstate =:tstate";
			params.put("tstate", tteacher.getTstate());
		}
		if (tteacher.getEmploymentdateStart() != null) {
			hql += " and t.employmentdate >= :employmentdateStart";
			params.put("employmentdateStart", tteacher.getEmploymentdateStart());
		}
		if (tteacher.getEmploymentdateEnd() != null) {
			hql += " and t.employmentdate <= :employmentdateEnd";
			params.put("employmentdateEnd", tteacher.getEmploymentdateEnd());
		}
		return hql;
	}
	
	private String addOrder(TTeacher tteacher, String hql) {
		if (tteacher.getSort() != null) {
			hql += " order by " + tteacher.getSort() + " "
					+ tteacher.getOrder();
		}
		return hql;
	}

	private void exchangeModel(List<Teacher> l, List<TTeacher> lt) {
		if (l != null && l.size() > 0) {
			for (Teacher s : l) {
				TTeacher t = new TTeacher();
				BeanUtils.copyProperties(s, t);
				lt.add(t);
			}
		}
	}

	@Override
	public void saveTeacher(TTeacher tteacher) {
		Teacher t=new Teacher();
		BeanUtils.copyProperties(tteacher, t,new String[] { "id","tpassword" });
		t.setTpassword(MD5Util.md5(tteacher.getTpassword()));
		teacherDao.save(t);	
	}

	@Override
	public void editTeacher(TTeacher tteacher) {
		Teacher t=teacherDao.get(Teacher.class, tteacher.getId());
		BeanUtils.copyProperties(tteacher, t,new String[] {"tpassword"});
		t.setTpassword(MD5Util.md5(tteacher.getTpassword()));
	}

	@Override
	public void updateTeacherState(TTeacher tteacher) {
		String[] nids = tteacher.getIds().split(",");
		for(int i = 0; i < nids.length; i++){
			Teacher t=teacherDao.get(Teacher.class,Integer.parseInt(nids[i]));
			if("在职".equals(t.getTstate())){
				t.setTstate("离职");
			}else{
				t.setTstate("在职");
			}
		}
	}

	@Override
	public BTeacher login(BTeacher bteacher) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tcode",bteacher.getTcode());
		params.put("tpassword",MD5Util.md5(bteacher.getTpassword()));
		Teacher t= teacherDao.get("from Teacher t where t.tcode=:tcode and t.tpassword=:tpassword",params);
		if (t != null) {
			BeanUtils.copyProperties(t, bteacher);
			return bteacher;
		}
		return null;
	}
	
	@Override
	public BTeacher updateStudentPassword(String id, String tpassword,String newPassword) {
		Teacher t=teacherDao.get(Teacher.class, Integer.valueOf(id));
		t.setTpassword(MD5Util.md5(newPassword));
		BTeacher bteacher=new BTeacher();
		BeanUtils.copyProperties(t,bteacher);
		return bteacher;
	}

	@Override
	public List<TTeacher> findExcelTeacher(TTeacher tteacher) {
		String hql = "from Teacher t where 1=1";
		Map<String, Object> params = new HashMap<String, Object>();
		hql = addWhere(tteacher, hql, params);
		List<Teacher> l = teacherDao.find(hql, params);
		List<TTeacher> lt = new ArrayList<TTeacher>();
		exchangeModel(l, lt);
		return lt;
	}

	@Override
	public void importTeacherExcel(MultipartFile file) throws IOException{
		HSSFWorkbook wb = new HSSFWorkbook(file.getInputStream());
		HSSFSheet sheet =wb.getSheetAt(0);
		int rows = sheet.getLastRowNum()+1-sheet.getFirstRowNum(); // 总行数
		for(int i=1; i<rows; i++){
            Teacher t=new Teacher();
            HSSFRow row = sheet.getRow(i);
            t.setTcode(row.getCell(0).toString());
            t.setTname(row.getCell(1).toString());
            t.setTpassword(MD5Util.md5(row.getCell(2).toString()));
            t.setBirth(row.getCell(3).getDateCellValue());
            t.setSex(row.getCell(4).toString());
            t.setEmploymentdate(row.getCell(5).getDateCellValue());
            t.setCollege(row.getCell(6).toString());
            t.setPhone(row.getCell(7).toString());
            t.setEmail(row.getCell(8).toString());
            t.setTstate(row.getCell(9).toString());
            teacherDao.save(t);
			if(i%50==0){ 
				teacherDao.clearCache();
			}
		}
		
	}
	
}