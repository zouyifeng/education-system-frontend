package dao.impl;

import org.springframework.stereotype.Repository;

import dao.UploadDaoI;
import model.UploadFileInfo;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Repository
public class UploadDaoImpl extends BaseDaoImpl<UploadFileInfo> implements UploadDaoI{

}

