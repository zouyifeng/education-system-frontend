package action;

import java.util.List;

import javax.annotation.Resource;

import model.UploadFileInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import pageModel.BCourse;
import pageModel.CourseCriteria;
import pageModel.DataGrid;
import pageModel.JsonResult;
import pageModel.TCourse;
import pageModel.TStudent;
import pageModel.TTeacher;
import service.CourseServiceI;
import service.UploadServiceI;
import util.Page;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Controller("courseAction")
@RequestMapping("/courseAction")
public class CourseAction {

	@Autowired
    private CourseServiceI courseService;
	
	@Autowired
    private UploadServiceI uploadService;
	
	@RequestMapping(value = "/datagrid")
	@ResponseBody
	public DataGrid datagrid(TCourse tcourse) {
		return courseService.datagrid(tcourse);
	}
	
	@RequestMapping(value = "/saveCourse")
	@ResponseBody
	public JsonResult saveCourse(TCourse tcourse){
		JsonResult j=new JsonResult();
		try {
			courseService.saveCourse(tcourse);   	
			j.setSuccess(true);
			j.setMsg("添加成功!");
		} catch (Exception e) {
			e.printStackTrace();
			j.setMsg("添加失败!");
		}
		return j;		
	}
	
	@RequestMapping(value = "/editCourse")
	@ResponseBody
	public JsonResult editCourse(TCourse tcourse){
		JsonResult j=new JsonResult();
		try {
			courseService.editCourse(tcourse);   	
			j.setSuccess(true);
			j.setMsg("编辑成功!");
		} catch (Exception e) {
			e.printStackTrace();
			j.setMsg("编辑失败!");
		}
		return j;		
	}
	
	@RequestMapping(value = "/updateCourseState")
	@ResponseBody
	public JsonResult updateCourseState(TCourse tcourse){
		JsonResult j=new JsonResult();
		try {
			courseService.updateCourseState(tcourse);   	
			j.setSuccess(true);
			j.setMsg("更新成功!");
		} catch (Exception e) {
			e.printStackTrace();
			j.setMsg("更新失败!");
		}
		return j;		
	}
	
	@RequestMapping(value = "/courseListByPage")
	public String courseListByPage(CourseCriteria cc,Model model){
		Page<BCourse> page=courseService.findCousrseByPage(cc);
	//	model.addAttribute(page);
	//	model.addAttribute(cc);		
		model.addAttribute("page", page);
		model.addAttribute("cc", cc);
		return "/foreground/courseListByPage";		
	}
	
	@RequestMapping(value = "/courseListById")
	public String courseListById(String id,Model model){
		BCourse b=courseService.findCourseById(id);
		model.addAttribute("course", b);
		List<UploadFileInfo> fileListByCcode=uploadService.findFileByCcode(b.getCcode());
		model.addAttribute("fileListByCcode", fileListByCcode);
		return "/foreground/courseListById";	
	}
	
	@RequestMapping(value = "/updateCourseGoodByCid")
	@ResponseBody
	public JsonResult updateCourseGoodByCid(String id){
		JsonResult j=new JsonResult();
		try {
			courseService.updateCourseGoodByCid(id);   	
			j.setSuccess(true);
			j.setMsg("更新成功!");
		} catch (Exception e) {
			e.printStackTrace();
			j.setMsg("更新失败!");
		}
		return j;		
	}
	
	@RequestMapping(value="courseListExcel",method = RequestMethod.GET)
    public String courseListExcel(Model model,TCourse tcourse) {
        List<TCourse> lists = courseService.findExcelCourse(tcourse);
        String filename = "课程信息表";
        String jspPath = "courseListExcel";
        model.addAttribute("lists", lists);
        model.addAttribute("filename", filename);
        model.addAttribute("jspPath", jspPath);
        return "/background/common/excel";
    }
	
	@RequestMapping(value = "/importCourseExcel")
	@ResponseBody
	public JsonResult importCourseExcel(MultipartHttpServletRequest request){
		JsonResult j=new JsonResult();
		for (MultipartFile file : request.getFileMap().values()){
            try {
            	courseService.importCourseExcel(file);
            	j.setSuccess(true);
    			j.setMsg("更新成功!");
            } catch (Exception e) {
            	e.printStackTrace();
    			j.setMsg("更新失败!");
            }
        }	
		return j;	
	}
}