package dao;

import model.Student;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public interface StudentDaoI extends BaseDaoI<Student>{

}

