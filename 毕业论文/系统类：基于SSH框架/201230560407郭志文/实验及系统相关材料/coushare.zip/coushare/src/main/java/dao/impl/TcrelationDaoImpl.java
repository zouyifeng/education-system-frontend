package dao.impl;

import model.Tcrelation;

import org.springframework.stereotype.Repository;

import dao.TcrelationDaoI;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Repository("tcrelationDao")
public class TcrelationDaoImpl extends BaseDaoImpl<Tcrelation> implements TcrelationDaoI{

}

