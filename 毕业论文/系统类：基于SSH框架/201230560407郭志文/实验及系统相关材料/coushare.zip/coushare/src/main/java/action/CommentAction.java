package action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pageModel.BComment;
import service.CommentServiceI;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Controller("commentAction")
@RequestMapping("/commentAction")
public class CommentAction {

	@Autowired
	private CommentServiceI commentService;
	
	@InitBinder
	private void dateBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		CustomDateEditor editor = new CustomDateEditor(dateFormat, true);
		binder.registerCustomEditor(Date.class, editor);
	}

	@RequestMapping(value = "/commentListByCourseid")
	public String commentListByCourseid(String id,Model model,HttpSession seeeion){		
		List<BComment> l=commentService.findCommentByCourseid(id);		
		model.addAttribute("commentList",l);
		return "/foreground/commentListByCourseid";		
	}
	
	@RequestMapping(value = "/saveComment")
	@ResponseBody
	public BComment saveComment(BComment bcomment) {
		BComment b=commentService.saveComment(bcomment);
		return b;
	}
	
	@RequestMapping(value = "/removeCommentById")
	public String removeCommentById(String id,String courseid,RedirectAttributes attr) {
		commentService.removeCommentById(id);
//		attr.addFlashAttribute("id",courseid); 获取的id是null
//		return "redirect:/courseAction/courseListById.do";
		return "redirect:/courseAction/courseListById.do?id="+courseid;	
	}
}