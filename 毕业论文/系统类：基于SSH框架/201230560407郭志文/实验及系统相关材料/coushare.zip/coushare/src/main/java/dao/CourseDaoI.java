package dao;

import model.Course;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public interface CourseDaoI extends BaseDaoI<Course>{

}

