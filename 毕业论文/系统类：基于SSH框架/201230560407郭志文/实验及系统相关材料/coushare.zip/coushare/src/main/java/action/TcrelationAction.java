package action;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pageModel.ComboboxNode;
import pageModel.DataGrid;
import pageModel.JsonResult;
import pageModel.TStudent;
import pageModel.TTcrelation;
import service.TcrelationServiceI;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Controller("tcrelationAction")
@RequestMapping("/tcrelationAction")
public class TcrelationAction {

	@Autowired
	private TcrelationServiceI tcrelationService;
	
	@RequestMapping(value = "/datagrid")
	@ResponseBody
	public DataGrid datagrid(TTcrelation ttcrelation) {
		return tcrelationService.datagrid(ttcrelation);
	}
	
	@RequestMapping(value = "/findAllTeacherId")
	@ResponseBody
	public List<ComboboxNode> findAllTeacherId(){
		return tcrelationService.findAllTeacherId();
	}
	
	@RequestMapping(value = "/findAllCourseId")
	@ResponseBody
	public List<ComboboxNode> findAllCourseId(){
		return tcrelationService.findAllCourseId();
	}
	
	@RequestMapping(value = "/saveTcrelation")
	@ResponseBody
	public JsonResult saveTcrelation(TTcrelation ttcrelation){
		JsonResult j=new JsonResult();
		if(tcrelationService.existRelation(ttcrelation)){
			try {
				tcrelationService.saveTcrelation(ttcrelation);   	
				j.setSuccess(true);
				j.setMsg("添加成功!");
			} catch (Exception e) {
				e.printStackTrace();
				j.setMsg("添加失败!");
			}			
		}else{
			j.setMsg("已存在该课程认证!");
		}		
		return j;		
	}
	
	@RequestMapping(value = "/deleteTcrelation")
	@ResponseBody
	public JsonResult deleteTcrelation(String ids){
		JsonResult j=new JsonResult();
		try {
			tcrelationService.deleteTcrelation(ids);   	
			j.setSuccess(true);
			j.setMsg("删除成功!");
		} catch (Exception e) {
			e.printStackTrace();
			j.setMsg("删除失败!");
		}
		return j;	
	}
}

