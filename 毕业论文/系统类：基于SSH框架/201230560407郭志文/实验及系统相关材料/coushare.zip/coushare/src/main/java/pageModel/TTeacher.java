package pageModel;

import java.util.Date;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public class TTeacher {
	
	private String ids;
	
	private int page;
	private int rows;
	private String sort;
	private String order;
	private Date employmentdateStart;
	private Date employmentdateEnd;
	
	private Integer id;
	private String tcode;
	private String tname;
	private String tpassword;
	private Date birth;
	private String sex;
	private Date employmentdate;
	private String phone;
	private String email;
	private String college;
	private String tstate;
	
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getRows() {
		return rows;
	}
	public void setRows(int rows) {
		this.rows = rows;
	}
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public Date getEmploymentdateStart() {
		return employmentdateStart;
	}
	public void setEmploymentdateStart(Date employmentdateStart) {
		this.employmentdateStart = employmentdateStart;
	}
	public Date getEmploymentdateEnd() {
		return employmentdateEnd;
	}
	public void setEmploymentdateEnd(Date employmentdateEnd) {
		this.employmentdateEnd = employmentdateEnd;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTcode() {
		return tcode;
	}
	public void setTcode(String tcode) {
		this.tcode = tcode;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getTpassword() {
		return tpassword;
	}
	public void setTpassword(String tpassword) {
		this.tpassword = tpassword;
	}
	public Date getBirth() {
		return birth;
	}
	public void setBirth(Date birth) {
		this.birth = birth;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public Date getEmploymentdate() {
		return employmentdate;
	}
	public void setEmploymentdate(Date employmentdate) {
		this.employmentdate = employmentdate;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	public String getTstate() {
		return tstate;
	}
	public void setTstate(String tstate) {
		this.tstate = tstate;
	}
	public String getIds() {
		return ids;
	}
	public void setIds(String ids) {
		this.ids = ids;
	}
}