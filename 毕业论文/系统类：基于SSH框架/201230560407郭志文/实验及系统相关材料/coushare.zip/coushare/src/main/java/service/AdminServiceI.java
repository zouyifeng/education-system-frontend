package service;

import pageModel.TAdmin;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public interface AdminServiceI {

	public TAdmin login(TAdmin tadmin);

	public TAdmin updateAdminPassword(TAdmin tadmin);

}

