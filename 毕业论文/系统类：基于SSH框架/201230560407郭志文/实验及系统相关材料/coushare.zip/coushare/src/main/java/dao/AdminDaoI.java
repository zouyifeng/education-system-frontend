package dao;

import model.Admin;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public interface AdminDaoI extends BaseDaoI<Admin>{

}

