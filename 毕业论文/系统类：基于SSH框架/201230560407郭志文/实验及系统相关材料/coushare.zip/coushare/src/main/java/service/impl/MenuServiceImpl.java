package service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.Menu;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.MenuDaoI;

import pageModel.TMenu;

import service.MenuServiceI;
@Service("menuService")
public class MenuServiceImpl implements MenuServiceI{
	private static final Logger logger = Logger.getLogger(MenuServiceImpl.class);
	@Autowired
    private MenuDaoI menuDao;		

	@Override
	public List<TMenu> getAllTreeNode() {
		List<TMenu> ls = new ArrayList<TMenu>();
		String hql = "from Menu m";
		List<Menu> l = menuDao.find(hql);
		if (l != null && l.size() > 0) {
			for (Menu m : l) {
				TMenu t= new TMenu();
				BeanUtils.copyProperties(m,t);
				Map<String,Object> attributes = new HashMap<String, Object>();
				attributes.put("url",m.getUrl());
				t.setAttributes(attributes);
				Menu tm =m.getMenu() ;// 获得当前节点的父节点对象
				if (tm != null) {
					t.setPid(tm.getId());
				}
				ls.add(t);
			}
		}
		return ls;
	}

}
