package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pageModel.JsonResult;
import pageModel.TAdmin;
import service.AdminServiceI;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Controller("adminAction")
@RequestMapping("/adminAction")
public class AdminAction {
	
	  @Autowired
	  private AdminServiceI adminService;

	  @RequestMapping(value="/logout.do")
	  public String logout(HttpServletRequest request) throws Exception{
		  request.getSession().removeAttribute("user");
		  request.getSession().removeAttribute("identity");			  
		  request.getSession().removeAttribute("ccodeListByTid");
		  return "newIndex";
	  }
	  
	  @RequestMapping(value = "/redirectLayout.do")
	  public String redirectLayout(){
		  return "/background/layout";		
	  }
	  
	  @RequestMapping(value = "/login.do")
	  @ResponseBody
	  public JsonResult login(TAdmin tadmin,HttpSession session) {
			TAdmin t=adminService.login(tadmin);
			session.setAttribute("user", t);
			session.setAttribute("identity",3);
			JsonResult j=new JsonResult();
			if (t!= null) {
				j.setSuccess(true);
				j.setMsg("登陆成功！");
			} else {
				j.setMsg("登录失败，用户名或密码错误！");
			}
			return j;
		}
	  
	  
	  @RequestMapping(value = "/updateAdminPassword.do")
	  @ResponseBody
	  public JsonResult updateAdminPassword(TAdmin tadmin,HttpSession session){	  
		    JsonResult j=new JsonResult();
			try {
				TAdmin t=adminService.updateAdminPassword(tadmin);  
				session.setAttribute("user", t); //覆盖user
				j.setSuccess(true);
				j.setMsg("更新成功!");
			} catch (Exception e) {
				e.printStackTrace();
				j.setMsg("更新失败!");
			}
			return j;		  
	  }
}