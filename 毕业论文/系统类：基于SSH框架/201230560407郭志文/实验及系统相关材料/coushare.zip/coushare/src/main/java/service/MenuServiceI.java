package service;

import java.util.List;

import pageModel.TMenu;

public interface MenuServiceI {
	
	public List<TMenu> getAllTreeNode();
}