package dao.impl;

import model.Admin;

import org.springframework.stereotype.Repository;

import dao.AdminDaoI;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Repository("adminDao")
public class AdminDaoImpl extends BaseDaoImpl<Admin> implements AdminDaoI{

}

