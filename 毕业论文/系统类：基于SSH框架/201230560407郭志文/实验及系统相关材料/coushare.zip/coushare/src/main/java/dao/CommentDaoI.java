package dao;

import model.Comments;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public interface CommentDaoI extends BaseDaoI<Comments>{

}

