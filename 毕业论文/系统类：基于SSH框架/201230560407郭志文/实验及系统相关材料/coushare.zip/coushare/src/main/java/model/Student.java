package model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.springframework.format.annotation.DateTimeFormat;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "student", catalog = "coushare", uniqueConstraints = @UniqueConstraint(columnNames = "scode"))
public class Student implements java.io.Serializable {

	// Fields

	private Integer id;
	private String scode;
	private String sname;
	private String spassword;
	private Date birth;
	private String sex;
	@DateTimeFormat( pattern = "yyyy-MM-dd" )
	private Date enrolltime;
	private String college;
	private String professional;
	private String grade;
	private String year;
	private String phone;
	private String email;
	private String sstate;

	// Constructors

	/** default constructor */
	public Student() {
	}

	/** minimal constructor */
	public Student(String scode, String sname, String spassword) {
		this.scode = scode;
		this.sname = sname;
		this.spassword = spassword;
	}

	/** full constructor */
	public Student(String scode, String sname, String spassword, Date birth,
			String sex, Date enrolltime, String college, String professional,
			String grade, String year, String phone, String email, String sstate) {
		this.scode = scode;
		this.sname = sname;
		this.spassword = spassword;
		this.birth = birth;
		this.sex = sex;
		this.enrolltime = enrolltime;
		this.college = college;
		this.professional = professional;
		this.grade = grade;
		this.year = year;
		this.phone = phone;
		this.email = email;
		this.sstate = sstate;
	}

	// Property accessors
	@Id
	@GeneratedValue
	@Column(name = "id", unique = true, nullable = false)
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "scode", unique = true, nullable = false)
	public String getScode() {
		return this.scode;
	}

	public void setScode(String scode) {
		this.scode = scode;
	}

	@Column(name = "sname", nullable = false, length = 80)
	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	@Column(name = "spassword", nullable = false, length = 80)
	public String getSpassword() {
		return this.spassword;
	}

	public void setSpassword(String spassword) {
		this.spassword = spassword;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "birth", length = 10)
	public Date getBirth() {
		return this.birth;
	}

	public void setBirth(Date birth) {
		this.birth = birth;
	}

	@Column(name = "sex", length = 30)
	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "enrolltime", length = 10)
	public Date getEnrolltime() {
		return this.enrolltime;
	}

	public void setEnrolltime(Date enrolltime) {
		this.enrolltime = enrolltime;
	}

	@Column(name = "college", length = 80)
	public String getCollege() {
		return this.college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	@Column(name = "professional", length = 80)
	public String getProfessional() {
		return this.professional;
	}

	public void setProfessional(String professional) {
		this.professional = professional;
	}

	@Column(name = "grade", length = 30)
	public String getGrade() {
		return this.grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	@Column(name = "year", length = 30)
	public String getYear() {
		return this.year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	@Column(name = "phone", length = 30)
	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Column(name = "email", length = 30)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "sstate", length = 30)
	public String getSstate() {
		return this.sstate;
	}

	public void setSstate(String sstate) {
		this.sstate = sstate;
	}

}