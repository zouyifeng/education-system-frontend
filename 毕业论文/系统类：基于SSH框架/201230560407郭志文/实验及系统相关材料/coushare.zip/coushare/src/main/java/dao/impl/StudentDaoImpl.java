package dao.impl;

import org.springframework.stereotype.Repository;

import model.Student;
import dao.StudentDaoI;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Repository("studentDao")
public class StudentDaoImpl extends BaseDaoImpl<Student> implements StudentDaoI{

}

