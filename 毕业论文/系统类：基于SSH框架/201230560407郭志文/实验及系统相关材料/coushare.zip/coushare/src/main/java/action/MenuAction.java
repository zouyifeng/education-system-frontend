package action;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import pageModel.TMenu;
import service.MenuServiceI;

@Controller("menuAction")
@RequestMapping("/menuAction")
public class MenuAction {

	private MenuServiceI menuService;
	public MenuServiceI getMenuService() {
		return menuService;
	}
	@Autowired
	public void setMenuService(MenuServiceI menuService) {
		this.menuService = menuService;
	}	

	@RequestMapping("/getAllTreeNode")
	@ResponseBody
	public List<TMenu> getAllTreeNode() {
		return menuService.getAllTreeNode();
	}
}