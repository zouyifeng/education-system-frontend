package pageModel;

import model.Type;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public class TCourse {

	private String ids;
	
	private int page;
	private int rows;
	private String sort;
	private String order;
	private Integer goodStart;
	private Integer goodEnd;
	
	private Integer typeid;
	private String typename;
	
	private Integer id;
	private String ccode;
	private String cname;
	private String definition;
	private String content;
	private String info;
	private Integer good;
	private String cstate;
	public Integer getTypeid() {
		return typeid;
	}
	public void setTypeid(Integer typeid) {
		this.typeid = typeid;
	}
	public String getTypename() {
		return typename;
	}
	public void setTypename(String typename) {
		this.typename = typename;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCcode() {
		return ccode;
	}
	public void setCcode(String ccode) {
		this.ccode = ccode;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getDefinition() {
		return definition;
	}
	public void setDefinition(String definition) {
		this.definition = definition;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public Integer getGood() {
		return good;
	}
	public void setGood(Integer good) {
		this.good = good;
	}
	public String getCstate() {
		return cstate;
	}
	public void setCstate(String cstate) {
		this.cstate = cstate;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getRows() {
		return rows;
	}
	public void setRows(int rows) {
		this.rows = rows;
	}
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public Integer getGoodStart() {
		return goodStart;
	}
	public void setGoodStart(Integer goodStart) {
		this.goodStart = goodStart;
	}
	public Integer getGoodEnd() {
		return goodEnd;
	}
	public void setGoodEnd(Integer goodEnd) {
		this.goodEnd = goodEnd;
	}
	public String getIds() {
		return ids;
	}
	public void setIds(String ids) {
		this.ids = ids;
	}
}