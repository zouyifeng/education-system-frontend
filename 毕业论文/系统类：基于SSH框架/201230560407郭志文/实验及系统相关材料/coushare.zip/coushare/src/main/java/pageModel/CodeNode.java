package pageModel;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public class CodeNode implements java.io.Serializable{
	
	private String code;
	private String name;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}

