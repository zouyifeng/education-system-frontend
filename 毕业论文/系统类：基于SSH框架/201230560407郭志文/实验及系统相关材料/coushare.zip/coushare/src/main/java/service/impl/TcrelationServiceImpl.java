package service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.Course;
import model.Tcrelation;
import model.Teacher;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pageModel.CodeNode;
import pageModel.ComboboxNode;
import pageModel.DataGrid;
import pageModel.TTcrelation;
import pageModel.TTeacher;
import dao.CourseDaoI;
import dao.TcrelationDaoI;
import dao.TeacherDaoI;
import service.TcrelationServiceI;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Service("tcrelationService")
public class TcrelationServiceImpl implements TcrelationServiceI{

	@Autowired
	private TcrelationDaoI tcrelationDao;
	
	@Autowired
	private TeacherDaoI teacherDao;
	
	@Autowired
	private CourseDaoI courseDao;

	@Override
	public DataGrid datagrid(TTcrelation ttcrelation) {
		DataGrid dg = new DataGrid();
		String hql = "from Tcrelation t where 1=1";
		Map<String, Object> params = new HashMap<String, Object>();
		hql = addWhere(ttcrelation, hql, params);
		String totalHql = "select count(*) " + hql;
		hql = addOrder(ttcrelation, hql);
		List<Tcrelation> l = tcrelationDao.find(hql, params, ttcrelation.getPage(),ttcrelation.getRows());
		List<TTcrelation> lt = new ArrayList<TTcrelation>();
		if (l != null && l.size() > 0) {
			for (Tcrelation t : l) {
				TTcrelation tt = new TTcrelation();
				BeanUtils.copyProperties(t, tt);
				tt.setTid(t.getTeacher().getId());
				tt.setTname(t.getTeacher().getTname());
				tt.setTcode(t.getTeacher().getTcode());
				tt.setCid(t.getCourse().getId());
				tt.setCname(t.getCourse().getCname());
				tt.setCcode(t.getCourse().getCcode());
				lt.add(tt);
			}
		}
		dg.setTotal(tcrelationDao.count(totalHql, params));
		dg.setRows(lt);
		return dg;
	}
	
	private String addWhere(TTcrelation ttcrelation, String hql, Map<String, Object> params) {
		if (ttcrelation.getTid() != null
				&& !ttcrelation.getTid().equals("")) {
			hql += " and t.teacher.id =:tid";
			params.put("tid",ttcrelation.getTid());
		}
		if (ttcrelation.getCid() != null
				&& !ttcrelation.getCid().equals("")) {
			hql += " and t.course.id =:cid";
			params.put("cid",ttcrelation.getCid());
		}
		return hql;
	}
	
	private String addOrder(TTcrelation ttcrelation, String hql) {
		if (ttcrelation.getSort() != null) {
			hql += " order by " + ttcrelation.getSort() + " "
					+ ttcrelation.getOrder();
		}
		return hql;
	}

	@Override
	public List<ComboboxNode> findAllTeacherId() {
		List<Teacher> l=teacherDao.find("from Teacher t");		
		List<ComboboxNode> lt= new ArrayList<ComboboxNode>();
		if(l!=null&&l.size()>0){   
			for(Teacher t:l){
				ComboboxNode c=new ComboboxNode();				
				c.setId(t.getId());
				c.setText(t.getTname());
				lt.add(c);
			}
		}		
		return lt;
	}

	@Override
	public List<ComboboxNode> findAllCourseId() {
		List<Course> l=courseDao.find("from Course c");		
		List<ComboboxNode> lt= new ArrayList<ComboboxNode>();
		if(l!=null&&l.size()>0){   
			for(Course t:l){
				ComboboxNode c=new ComboboxNode();				
				c.setId(t.getId());
				c.setText(t.getCname());
				lt.add(c);
			}
		}		
		return lt;
	}

	@Override
	public void saveTcrelation(TTcrelation ttcrelation) {
		Tcrelation t=new Tcrelation();
		Teacher teacher=new Teacher();
		teacher.setId(ttcrelation.getTid());
		Course course=new Course();
		course.setId(ttcrelation.getCid());
		t.setTeacher(teacher);
		t.setCourse(course);
		tcrelationDao.save(t);
	}

	@Override
	public boolean existRelation(TTcrelation ttcrelation) {
		String hql = "from Tcrelation t where 1=1";
		Map<String, Object> params = new HashMap<String, Object>();
		if (ttcrelation.getTid() != null && !ttcrelation.getTid().equals("")) {
			hql += " and t.teacher.id =:tid";
			params.put("tid",ttcrelation.getTid());
		}
		if (ttcrelation.getCid() != null && !ttcrelation.getCid().equals("")) {
			hql += " and t.course.id =:cid";
			params.put("cid",ttcrelation.getCid());
		}
		List<Tcrelation> l = tcrelationDao.find(hql, params);
		if(l.size()>0){
			return false;
		}else{
			return true;
		}		
	}

	@Override
	public void deleteTcrelation(String ids) {
		String[] nids = ids.split(",");
		String hql = "delete Tcrelation t where t.id in ("; 
		for (int i = 0; i < nids.length; i++) {
			if (i > 0) {
				hql += ",";
			}
			hql += "'" + nids[i] + "'";
		}
		hql += ")";
		tcrelationDao.executeHql(hql);		
	}

	@Override
	public List<CodeNode> findTcrelationByTeacherid(Integer id) {
		String hql = "from Tcrelation t where t.teacher.id=:id";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", id);
		List<Tcrelation> l=tcrelationDao.find(hql, params);
		List<CodeNode> lt = new ArrayList<CodeNode>();
		if (l != null && l.size() > 0) {
			for (Tcrelation t : l) {
				CodeNode cn = new CodeNode();
				cn.setCode(t.getCourse().getCcode());
	            cn.setName(t.getCourse().getCname());
				lt.add(cn);
			}
		}
		return lt;
	}

	@Override
	public List<CodeNode> findAllCcode() {
		String hql = "from Course c";
		List<Course> l=courseDao.find(hql);
		List<CodeNode> lt = new ArrayList<CodeNode>();
		if (l != null && l.size() > 0) {
			for (Course c : l) {
				CodeNode cn = new CodeNode();
				cn.setCode(c.getCcode());
	            cn.setName(c.getCname());
				lt.add(cn);
			}
		}
		return lt;
	}

	@Override
	public List<CodeNode> findAllTcode() {
		String hql = "from Teacher t";
		List<Teacher> l=teacherDao.find(hql);
		List<CodeNode> lt = new ArrayList<CodeNode>();
		if (l != null && l.size() > 0) {
			for (Teacher t : l) {
				CodeNode cn = new CodeNode();
				cn.setCode(t.getTcode());
	            cn.setName(t.getTname());
				lt.add(cn);
			}
		}
		return lt;
	}
	
}

