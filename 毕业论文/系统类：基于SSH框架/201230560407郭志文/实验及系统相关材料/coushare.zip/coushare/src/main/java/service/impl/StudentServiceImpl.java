package service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.Student;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import dao.StudentDaoI;
import pageModel.BStudent;
import pageModel.DataGrid;
import pageModel.TStudent;
import service.StudentServiceI;
import util.MD5Util;

/**
 * TODO 类/接口描述信息
 * 
 * @author LevenGuo
 * 
 */
@Service("/studentService")
public class StudentServiceImpl implements StudentServiceI {

	@Autowired
	private StudentDaoI studentDao;

	@Override
	public DataGrid datagrid(TStudent tstudent) {
		DataGrid dg = new DataGrid();
		String hql = "from Student s where 1=1";
		Map<String, Object> params = new HashMap<String, Object>();
		hql = addWhere(tstudent, hql, params);
		String totalHql = "select count(*) " + hql;
		hql = addOrder(tstudent, hql);
		List<Student> l = studentDao.find(hql, params, tstudent.getPage(),
				tstudent.getRows());
		List<TStudent> lt = new ArrayList<TStudent>();
		exchangeModel(l, lt);
		dg.setTotal(studentDao.count(totalHql, params));
		dg.setRows(lt);
		return dg;
	}

	private String addWhere(TStudent tstudent, String hql, Map<String, Object> params) {
		if (tstudent.getScode() != null
				&& !tstudent.getScode().trim().equals("")) {
			hql += " and s.scode =:scode";
			params.put("scode", tstudent.getScode().trim());
		}
		if (tstudent.getSname() != null
				&& !tstudent.getSname().trim().equals("")) {
			hql += " and s.sname like :sname";
			params.put("sname", "%%" + tstudent.getSname().trim() + "%%");
		}
		if (tstudent.getSex() != null && !tstudent.getSex().trim().equals("")) {
			hql += " and s.sex =:sex";
			params.put("sex", tstudent.getSex());
		}
		if (tstudent.getCollege() != null
				&& !tstudent.getCollege().trim().equals("")) {
			hql += " and s.college =:college";
			params.put("college", tstudent.getCollege());
		}
		if (tstudent.getProfessional() != null
				&& !tstudent.getProfessional().trim().equals("")) {
			hql += " and s.professional =:professional";
			params.put("professional", tstudent.getProfessional());
		}
		if (tstudent.getSstate() != null
				&& !tstudent.getSstate().trim().equals("")) {
			hql += " and s.sstate =:sstate";
			params.put("sstate", tstudent.getSstate());
		}
		if (tstudent.getEnrolltimeStart() != null) {
			hql += " and s.enrolltime >= :enrolltimeStart";
			params.put("enrolltimeStart", tstudent.getEnrolltimeStart());
		}
		if (tstudent.getEnrolltimeEnd() != null) {
			hql += " and s.enrolltime <= :enrolltimeEnd";
			params.put("enrolltimeEnd", tstudent.getEnrolltimeEnd());
		}
		return hql;
	}

	private String addOrder(TStudent tstudent, String hql) {
		if (tstudent.getSort() != null) {
			hql += " order by " + tstudent.getSort() + " "
					+ tstudent.getOrder();
		}
		return hql;
	}

	private void exchangeModel(List<Student> l, List<TStudent> lt) {
		if (l != null && l.size() > 0) {
			for (Student s : l) {
				TStudent t = new TStudent();
				BeanUtils.copyProperties(s, t);
				lt.add(t);
			}
		}
	}

	@Override
	public void saveStudent(TStudent tstudent) {
		Student s=new Student();
		BeanUtils.copyProperties(tstudent, s,new String[] { "id","spassword" });
		s.setSpassword(MD5Util.md5(tstudent.getSpassword()));
		studentDao.save(s);		
	}

	@Override
	public void editStudent(TStudent tstudent) {
		Student s=studentDao.get(Student.class, tstudent.getId());
		BeanUtils.copyProperties(tstudent, s,new String[] {"spassword"});
		s.setSpassword(MD5Util.md5(tstudent.getSpassword()));
	}

	@Override
	public void updateStudentState(TStudent tstudent) {
		String[] nids = tstudent.getIds().split(","); //字符串转数组
		for(int i = 0; i < nids.length; i++){
			Student s=studentDao.get(Student.class,Integer.parseInt(nids[i]));
			if("在校".equals(s.getSstate())){
				s.setSstate("离校");
			}else{
				s.setSstate("在校");
			}
		}
	}

	@Override
	public BStudent login(BStudent bstudent) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("scode",bstudent.getScode());
		params.put("spassword",MD5Util.md5(bstudent.getSpassword()));
		Student s= studentDao.get("from Student s where s.scode=:scode and s.spassword=:spassword",params);
		if (s != null) {
			BeanUtils.copyProperties(s, bstudent);
			return bstudent;
		}
		return null;
	}

	@Override
	public BStudent updateStudentPassword(String id, String spassword,String newPassword) {
		Student s=studentDao.get(Student.class, Integer.valueOf(id));
		s.setSpassword(MD5Util.md5(newPassword));
		BStudent bstudent=new BStudent();
		BeanUtils.copyProperties(s, bstudent);
		return bstudent;
	}

	@Override
	public List<TStudent> findExcelStudent(TStudent tstudent) {
		String hql = "from Student s where 1=1";
		Map<String, Object> params = new HashMap<String, Object>();
		hql = addWhere(tstudent, hql, params);
		List<Student> l = studentDao.find(hql, params);
		List<TStudent> lt = new ArrayList<TStudent>();
		exchangeModel(l, lt);
		return lt;
	}

	@Override
	public void importStudentExcel(MultipartFile file) throws IOException{
		String path="D:/coushare/excel/"; //先上传文件,再读取数据
		String filePath=path+file.getOriginalFilename();
		// 读取指定文件夹
        File newFile = new File(path);
        // 防止文件夹不存在
        if (!newFile.exists()) {
            // 生成新的文件目录
            newFile.mkdirs();
        }
		FileCopyUtils.copy(file.getBytes(), new FileOutputStream(filePath));
		//file.getInputStream()
		FileInputStream is = new FileInputStream(filePath);
		HSSFWorkbook wb = new HSSFWorkbook(is);
		HSSFSheet sheet =wb.getSheetAt(0);
		int rows = sheet.getLastRowNum()+1-sheet.getFirstRowNum(); // 总行数
		//注意隐藏的行数,有样式没有内容的行也算一行
		for(int i=1; i<rows; i++){
			Student s=new Student();
			HSSFRow row = sheet.getRow(i);
			s.setScode(row.getCell(0).toString());
			s.setSname(row.getCell(1).toString());
			s.setSpassword(MD5Util.md5(row.getCell(2).toString()));
			s.setBirth(row.getCell(3).getDateCellValue()); //相关格式可以事先在上传模板定义，例如日期格式,数字与字符串等
			s.setSex(row.getCell(4).toString());
			s.setEnrolltime(row.getCell(5).getDateCellValue());
			s.setCollege(row.getCell(6).toString());
			s.setProfessional(row.getCell(7).toString());
			s.setGrade(row.getCell(8).toString());
			s.setYear(row.getCell(9).toString());
			s.setPhone(row.getCell(10).toString());
			s.setEmail(row.getCell(11).toString());
			s.setSstate(row.getCell(12).toString());
			studentDao.save(s);
			
		/*	int cols = row.getLastCellNum()+1-row.getFirstCellNum(); // 该行的总列数			
			String[] str = new String[cols]; // 用来存放该行每一列的值
			for (int j = 0; j < cols; j++) {				
				str[j]=row.getCell(j).toString();
			}*/
			if(i%50==0){ //未进行大批量数据导入测试
				studentDao.clearCache();
			}
			File targetFile = new File(filePath);
			targetFile.delete();
		}
	}
}