package action;

import com.alibaba.fastjson.JSONObject;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import model.UploadFileInfo;
import service.UploadServiceI;
import util.Page;
import util.PathUtil;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import pageModel.BCourse;
import pageModel.BTeacher;
import pageModel.CourseCriteria;
import pageModel.FileCriteria;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Controller
@RequestMapping("/upload")
public class UploadAction {
	
	    private static Logger logger = LoggerFactory.getLogger(UploadAction.class);

	    @Resource
	    private UploadServiceI uploadService;
	    
	    private String baseUploadFilePath="D:/coushare/upload";

	    @RequestMapping(value = "/upload")
	    public String upload() {
	        return "foreground/includeUpload";
	    }

	    @RequestMapping(value = "/ajax/uploadFile", method = RequestMethod.GET)
	    @ResponseBody
	    public Object fileList(String recordCode, String recordId) {
	        List<UploadFileInfo> uploadFileInfos = uploadService.findUploadList(recordCode, recordId);
	        JSONObject jsonObject = new JSONObject();
	        jsonObject.put("files", uploadFileInfos);
	        return jsonObject;
	    }

	    @RequestMapping(value = "/ajax/uploadFile", method = RequestMethod.POST)
	    @ResponseBody
	    public JSONObject uploadFile(MultipartHttpServletRequest request,
	                           HttpServletResponse response, String otherUploadPath,
	                           String recordId, String recordCode,HttpSession session) throws IOException {

	        UploadFileInfo fileInfo;
	        List<UploadFileInfo> list = new LinkedList<UploadFileInfo>();
	        
	        BTeacher t=(BTeacher) session.getAttribute("user");//recordCode与t.getTcode()的值相同

	        for (MultipartFile file : request.getFileMap().values()){
	            try {
	                fileInfo = uploadService.saveFile(file, baseUploadFilePath,
	                        otherUploadPath, recordId, recordCode, t.getTcode());
	                list.add(fileInfo);
	            } catch (Exception e) {
	                String message = "上传文件失败";
	                fileInfo = new UploadFileInfo();
	                fileInfo.setError(message);
	                list.add(fileInfo);
	                logger.error(message, e);
	            }
	        }
	        JSONObject jsonObject = new JSONObject();
	        jsonObject.put("files", list);
	        /*JSONObject jsonObject = new JSONObject();
	        jsonObject.put("files", list);
	        response.setContentType("application/json;charset=UTF-8");
	        response.getWriter().print(jsonObject);*/
	        return jsonObject;
	    }

	    @RequestMapping(value = "/ajax/deleteFile")
	    @ResponseBody
	    public Map<String, Object> deleteFile(Integer id) {
	        Map<String, Object> jsonResult=new HashMap<>();
	        UploadFileInfo uploadFileInfo = uploadService.obtainUploadFileInfoById(id);
	        if (uploadService.deleteUploadFile(id, baseUploadFilePath)) {
	            jsonResult.put("code", "success");
	            jsonResult.put("message", "删除成功");
	            jsonResult.put("uploadFileInfo", uploadFileInfo);
	        } else {
	            jsonResult.put("code", "fail");
	            jsonResult.put("message", "删除失败");
	        }
	        return jsonResult;
	    }

	    @RequestMapping(value = "/downloadFile")
	    public void downloadFile(HttpServletRequest request,HttpServletResponse response, Integer id)
	            throws IOException {
	        UploadFileInfo fileInfo = uploadService.obtainUploadFileInfoById(id);	        
	        uploadService.updateFileDownloadCount(id);	   //Jquery fileupload第一次加载文件信息时会调用下载方法一次,估计是javascript的download模板     
	        File file = new File(baseUploadFilePath + "/"
	                + PathUtil.wrapperPath(fileInfo.getRecordCode())
	                + fileInfo.getFileNewName());
	        response.setContentType(fileInfo.getFileType());
	        response.setContentLength(FileUtils.readFileToByteArray(file).length);
//	      response.setHeader("Content-disposition", "attachment; filename=\""
//	                + fileInfo.getFileName() + "\"");

	        String fileName=fileInfo.getFileName();
	        String agent = request.getHeader("User-Agent").toUpperCase();
	        if (agent.indexOf("MSIE") > 0 || agent.indexOf("TRIDENT") > 0) {
	            fileName = URLEncoder.encode(fileName, "UTF-8");
	        } else {
	            fileName = new String(fileName.getBytes("utf-8"), "ISO_8859_1");
	        }
	        response.setHeader("Content-disposition", "attachment; filename="+fileName);

	        HttpHeaders headers = new HttpHeaders();
	        headers.setContentDispositionFormData("attachment",
	                fileInfo.getFileName());
	        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	        FileCopyUtils.copy(FileUtils.readFileToByteArray(file),
	                response.getOutputStream());
	    }
	    
	    @RequestMapping(value = "/fileListByPage")
		public String fileListByPage(FileCriteria fc,Model model){
			Page<UploadFileInfo> page=uploadService.findFileByPage(fc);	
			model.addAttribute("page", page);
			model.addAttribute("fc", fc);
			return "/foreground/fileListByPage";		
		}
}

