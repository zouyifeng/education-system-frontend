package service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.Course;
import model.Student;
import model.Teacher;
import model.Type;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import dao.CourseDaoI;
import pageModel.BCourse;
import pageModel.Chart;
import pageModel.CourseCriteria;
import pageModel.DataGrid;
import pageModel.Highchart;
import pageModel.TCourse;
import pageModel.TTeacher;
import service.CourseServiceI;
import util.Page;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Service("courseService")
public class CourseServiceImpl implements CourseServiceI{

	@Autowired
	private CourseDaoI courseDao;
	
	@Override
	public DataGrid datagrid(TCourse tcourse) {
		DataGrid dg = new DataGrid();
		String hql = "from Course c where 1=1";
		Map<String, Object> params = new HashMap<String, Object>();
		hql = addWhere(tcourse, hql, params);
		String totalHql = "select count(*) " + hql;
		hql = addOrder(tcourse, hql);
		List<Course> l = courseDao.find(hql, params, tcourse.getPage(),
				tcourse.getRows());
		List<TCourse> lt = new ArrayList<TCourse>();
		exchangeModel(l, lt);
		dg.setTotal(courseDao.count(totalHql, params));
		dg.setRows(lt);
		return dg;
	}
	
	private String addWhere(TCourse tcourse, String hql, Map<String, Object> params) {
		if (tcourse.getCcode() != null
				&& !tcourse.getCcode().trim().equals("")) {
			hql += " and c.ccode =:ccode";
			params.put("ccode", tcourse.getCcode().trim());
		}
		if (tcourse.getCname() != null
				&& !tcourse.getCname().trim().equals("")) {
			hql += " and c.cname like :cname";
			params.put("cname", "%%" + tcourse.getCname().trim() + "%%");
		}
		if (tcourse.getTypename() != null 
				&& !tcourse.getTypename().trim().equals("")) {
			hql += " and c.type.typename =:typename";
			params.put("typename", tcourse.getTypename());
		}
		if (tcourse.getCstate() != null
				&& !tcourse.getCstate().trim().equals("")) {
			hql += " and c.cstate =:cstate";
			params.put("cstate", tcourse.getCstate());
		}
		if (tcourse.getGoodStart() != null
				&& !tcourse.getGoodStart().equals("")) {
			hql += " and c.good >= :goodStart";
			params.put("goodStart", tcourse.getGoodStart());
		}
		if (tcourse.getGoodEnd() != null
				&& !tcourse.getGoodEnd().equals("")) {
			hql += " and c.good <= :goodEndd";
			params.put("goodEnd", tcourse.getGoodEnd());
		}
		return hql;
	}
	
	private String addOrder(TCourse tcourse, String hql) {
		if (tcourse.getSort() != null) {
			hql += " order by " + tcourse.getSort() + " "
					+ tcourse.getOrder();
		}
		return hql;
	}

	private void exchangeModel(List<Course> l, List<TCourse> lt) {
		if (l != null && l.size() > 0) {
			for (Course c : l) {
				TCourse t = new TCourse();
				BeanUtils.copyProperties(c, t);
				t.setTypename(c.getType().getTypename());
				lt.add(t);
			}
		}
	}

	@Override
	public void saveCourse(TCourse tcourse) {
		Course c=new Course();
		BeanUtils.copyProperties(tcourse, c,new String[] { "id" });
		selectCourseType(tcourse, c);
		c.setGood(0);
		courseDao.save(c);	
	}

	private void selectCourseType(TCourse tcourse, Course c) {
		Type t=new Type();
		if("必修课".equals(tcourse.getTypename())){
			t.setId(1);
		}
		if ("公共选修课".equals(tcourse.getTypename())) {
			t.setId(2);
		}
		if ("专业选修课".equals(tcourse.getTypename())) {
			t.setId(3);
		}
		c.setType(t);
	}

	@Override
	public void editCourse(TCourse tcourse) {
		Course c=courseDao.get(Course.class, tcourse.getId());
		BeanUtils.copyProperties(tcourse, c);
		selectCourseType(tcourse, c);
	}

	@Override
	public void updateCourseState(TCourse tcourse) {
		String[] nids = tcourse.getIds().split(",");
		for(int i = 0; i < nids.length; i++){
			Course c=courseDao.get(Course.class,Integer.parseInt(nids[i]));
			if("开课".equals(c.getCstate())){
				c.setCstate("结课");
			}else{
				c.setCstate("开课");
			}
		}
	}

	@Override
	public Page<BCourse> findCousrseByPage(CourseCriteria cc) {
		String hql = "from Course c where 1=1";
		Map<String, Object> params = new HashMap<String, Object>();
		if (cc.getCname() != null && !cc.getCname().trim().equals("")) {
			hql += " and c.cname like :cname";
			params.put("cname", "%%" + cc.getCname().trim() + "%%");
		}
		if (cc.getTypeid() != null && !cc.getTypeid().equals("")) {
			hql += " and c.type.id =:id";
			params.put("id",cc.getTypeid());
		}
		String totalHql = "select count(*) " + hql;
		List<Course> l = courseDao.find(hql, params, cc.getCurrentPage(),cc.getPageSize());
		List<BCourse> lt = new ArrayList<BCourse>();
		if (l != null && l.size() > 0) {
			for (Course c : l) {
				BCourse b = new BCourse();
				BeanUtils.copyProperties(c, b);
				b.setId(c.getId());
				b.setTypename(c.getType().getTypename());
				lt.add(b);
			}
		}
		Page<BCourse> page=new Page<BCourse>();
		page.setCurrentPage(cc.getCurrentPage());
		page.setPageSize(cc.getPageSize());
		page.setTotalSize(courseDao.count(totalHql, params).intValue());
		page.setRecords(lt);
		return page;
	}

	@Override
	public BCourse findCourseById(String id) {		
		Course c=courseDao.get(Course.class,Integer.parseInt(id));
		BCourse b = new BCourse();
		if (c != null ) {		
			BeanUtils.copyProperties(c, b);
			b.setId(c.getId());
			b.setTypename(c.getType().getTypename());							
		}
		return b;
	}

	@Override
	public void updateCourseGoodByCid(String id) {
		Course c=courseDao.get(Course.class,Integer.parseInt(id));
		c.setGood(c.getGood()+1);
	}

	@Override
	public List<TCourse> findExcelCourse(TCourse tcourse) {
		String hql = "from Course c where 1=1";
		Map<String, Object> params = new HashMap<String, Object>();
		hql = addWhere(tcourse, hql, params);
		List<Course> l = courseDao.find(hql, params);
		List<TCourse> lt = new ArrayList<TCourse>();
		exchangeModel(l, lt);
		return lt;
	}

	@Override
	public void importCourseExcel(MultipartFile file) throws IOException {
		HSSFWorkbook wb = new HSSFWorkbook(file.getInputStream());
		HSSFSheet sheet =wb.getSheetAt(0);
		int rows = sheet.getLastRowNum()+1-sheet.getFirstRowNum(); // 总行数
		for(int i=1; i<rows; i++){
            Course c=new Course();
            HSSFRow row = sheet.getRow(i);
            c.setCcode(row.getCell(0).toString());
            c.setCname(row.getCell(1).toString());
            c.setDefinition(row.getCell(3).toString());
            c.setContent(row.getCell(4).toString());
            c.setInfo(row.getCell(5).toString());//值为空的情况下需要将excel模板的空格设置单元格格式为文本，默认的话是null，不能使用toString()方法
            c.setCstate(row.getCell(6).toString());
            c.setGood(0);
            String typename=row.getCell(2).toString();
            Type t=new Type();
    		if("必修课".equals(typename)){
    			t.setId(1);
    		}
    		if ("公共选修课".equals(typename)) {
    			t.setId(2);
    		}
    		if ("专业选修课".equals(typename)) {
    			t.setId(3);
    		}
    		c.setType(t);
    		courseDao.save(c);
			if(i%50==0){ 
				courseDao.clearCache();
			}
		}
	}

	@Override
	public List<TCourse> findTopCourse() {
		String hql = "from Course c order by c.good desc";
		List<Course> l=courseDao.find(hql, 0, 3);
		List<TCourse> lt = new ArrayList<TCourse>();
		exchangeModel(l, lt);
		return lt;
	}

	@Override
	public Chart findTopCourseChart() {
		String hql = "select new Map(c.cname as cname,c.good as good) from Course c where c.cstate='开课' order by c.good desc";
		List<Map<String, Object>> list=courseDao.findByMap(hql, 0, 5);
		List<String> categories=new ArrayList<>();
		List<Object> listdata=new ArrayList<>();
		for(Map<String, Object> map : list){
			categories.add((String) map.get("cname"));
			listdata.add(map.get("good"));
		}
		Chart c=new Chart();
		c.setCategories(categories);
		Highchart h=new Highchart();
		h.setName("点赞量");
		h.setData(listdata);
		c.setHighchart(h);
		return c;
	}
}