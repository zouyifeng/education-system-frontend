package pageModel;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public class CourseCriteria {

	private int currentPage=1;
	private int pageSize=5;
	private String cname;
	private Integer typeid;
	
	public Integer getTypeid() {
		return typeid;
	}
	public void setTypeid(Integer typeid) {
		this.typeid = typeid;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
}

