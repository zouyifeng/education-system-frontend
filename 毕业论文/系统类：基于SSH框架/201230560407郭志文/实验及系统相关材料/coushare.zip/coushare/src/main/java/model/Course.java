package model;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * Course entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "course", catalog = "coushare", uniqueConstraints = @UniqueConstraint(columnNames = "ccode"))
public class Course implements java.io.Serializable {

	// Fields

	private Integer id;
	private Type type;
	private String ccode;
	private String cname;
	private String definition;
	private String content;
	private String info;
	private Integer good;
	private String cstate;
	private Set<Comments> commentses = new HashSet<Comments>(0);
	private Set<Tcrelation> tcrelations = new HashSet<Tcrelation>(0);

	// Constructors

	/** default constructor */
	public Course() {
	}

	/** minimal constructor */
	public Course(Type type, String ccode, String cname) {
		this.type = type;
		this.ccode = ccode;
		this.cname = cname;
	}

	/** full constructor */
	public Course(Type type, String ccode, String cname, String definition,
			String content, String info, Integer good, String cstate,
			Set<Comments> commentses, Set<Tcrelation> tcrelations) {
		this.type = type;
		this.ccode = ccode;
		this.cname = cname;
		this.definition = definition;
		this.content = content;
		this.info = info;
		this.good = good;
		this.cstate = cstate;
		this.commentses = commentses;
		this.tcrelations = tcrelations;
	}

	// Property accessors
	@Id
	@GeneratedValue
	@Column(name = "id", unique = true, nullable = false)
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "typeid", nullable = false)
	public Type getType() {
		return this.type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	@Column(name = "ccode", unique = true, nullable = false)
	public String getCcode() {
		return this.ccode;
	}

	public void setCcode(String ccode) {
		this.ccode = ccode;
	}

	@Column(name = "cname", nullable = false, length = 80)
	public String getCname() {
		return this.cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	@Column(name = "definition")
	public String getDefinition() {
		return this.definition;
	}

	public void setDefinition(String definition) {
		this.definition = definition;
	}

	@Column(name = "content")
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Column(name = "info")
	public String getInfo() {
		return this.info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	@Column(name = "good")
	public Integer getGood() {
		return this.good;
	}

	public void setGood(Integer good) {
		this.good = good;
	}

	@Column(name = "cstate", length = 30)
	public String getCstate() {
		return this.cstate;
	}

	public void setCstate(String cstate) {
		this.cstate = cstate;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "course")
	public Set<Comments> getCommentses() {
		return this.commentses;
	}

	public void setCommentses(Set<Comments> commentses) {
		this.commentses = commentses;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "course")
	public Set<Tcrelation> getTcrelations() {
		return this.tcrelations;
	}

	public void setTcrelations(Set<Tcrelation> tcrelations) {
		this.tcrelations = tcrelations;
	}

}