package dao;

import model.Teacher;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public interface TeacherDaoI extends BaseDaoI<Teacher>{

}

