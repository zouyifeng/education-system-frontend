package service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import pageModel.BTeacher;
import pageModel.DataGrid;
import pageModel.TTeacher;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public interface TeacherServiceI {

	public DataGrid datagrid(TTeacher tteacher);
	public void saveTeacher(TTeacher tteacher);
	public void editTeacher(TTeacher tteacher);
	public void updateTeacherState(TTeacher tteacher);
	public BTeacher login(BTeacher bteacher);
	public BTeacher updateStudentPassword(String id, String tpassword, String newPassword);
	public List<TTeacher> findExcelTeacher(TTeacher tteacher);
	public void importTeacherExcel(MultipartFile file) throws IOException;
}