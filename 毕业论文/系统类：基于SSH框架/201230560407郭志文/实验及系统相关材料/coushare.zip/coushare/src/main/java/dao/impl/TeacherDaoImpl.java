package dao.impl;

import org.springframework.stereotype.Repository;

import model.Teacher;
import dao.TeacherDaoI;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Repository("teacherDao")
public class TeacherDaoImpl extends BaseDaoImpl<Teacher> implements TeacherDaoI{

}

