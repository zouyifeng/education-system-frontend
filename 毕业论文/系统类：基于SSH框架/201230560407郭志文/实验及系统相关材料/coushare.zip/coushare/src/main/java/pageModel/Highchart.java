package pageModel;

import java.util.ArrayList;
import java.util.List;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public class Highchart {
	
	public String name;
	private List<Object> data=new ArrayList<>();

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Object> getData() {
		return data;
	}
	public void setData(List<Object> data) {
		this.data = data;
	}
}

