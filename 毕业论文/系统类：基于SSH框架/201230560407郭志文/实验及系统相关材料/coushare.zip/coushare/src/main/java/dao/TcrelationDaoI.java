package dao;

import model.Tcrelation;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public interface TcrelationDaoI extends BaseDaoI<Tcrelation>{

}

