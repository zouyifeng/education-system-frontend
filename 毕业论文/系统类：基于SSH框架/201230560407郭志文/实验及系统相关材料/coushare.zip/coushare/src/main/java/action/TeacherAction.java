package action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import pageModel.BStudent;
import pageModel.BTeacher;
import pageModel.CodeNode;
import pageModel.DataGrid;
import pageModel.JsonResult;
import pageModel.TStudent;
import pageModel.TTeacher;
import service.TcrelationServiceI;
import service.TeacherServiceI;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Controller("teacherAction")
@RequestMapping("/teacherAction")
public class TeacherAction {

	@Autowired
	private TeacherServiceI teacherService;
	
	@Autowired
	private TcrelationServiceI tcrelationService;
	
	@InitBinder
	private void dateBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		CustomDateEditor editor = new CustomDateEditor(dateFormat, true);
		binder.registerCustomEditor(Date.class, editor);
	}
	
	@RequestMapping(value = "/datagrid")
	@ResponseBody
	public DataGrid datagrid(TTeacher tteacher) {
		return teacherService.datagrid(tteacher);
	}
	
	@RequestMapping(value = "/saveTeacher")
	@ResponseBody
	public JsonResult saveTeacher(TTeacher tteacher){
		JsonResult j=new JsonResult();
		try {
			teacherService.saveTeacher(tteacher);   	
			j.setSuccess(true);
			j.setMsg("添加成功!");
		} catch (Exception e) {
			e.printStackTrace();
			j.setMsg("添加失败!");
		}
		return j;		
	}
	
	@RequestMapping(value = "/editTeacher")
	@ResponseBody
	public JsonResult editTeacher(TTeacher tteacher){
		JsonResult j=new JsonResult();
		try {
			teacherService.editTeacher(tteacher);   	
			j.setSuccess(true);
			j.setMsg("编辑成功!");
		} catch (Exception e) {
			e.printStackTrace();
			j.setMsg("编辑失败!");
		}
		return j;		
	}
	
	@RequestMapping(value = "/updateTeacherState")
	@ResponseBody
	public JsonResult updateTeacherState(TTeacher tteacher){
		JsonResult j=new JsonResult();
		try {
			teacherService.updateTeacherState(tteacher);   	
			j.setSuccess(true);
			j.setMsg("更新成功!");
		} catch (Exception e) {
			e.printStackTrace();
			j.setMsg("更新失败!");
		}
		return j;		
	}
	
	@RequestMapping(value = "/loginTeacher")
	public String loginTeacher(BTeacher bteacher,HttpSession session){
		BTeacher b=teacherService.login(bteacher);
		session.setAttribute("user", b);
		session.setAttribute("identity", 2);
		List<CodeNode> l=tcrelationService.findAllCcode();
		session.setAttribute("ccodeList", l);
		List<CodeNode> lt=tcrelationService.findAllTcode();
		session.setAttribute("tcodeList", lt);
		return "/newIndex";		
	}
	
	@RequestMapping(value = "/teacherCenterList")
	public String teacherCenterList(HttpSession session){
		BTeacher t=(BTeacher) session.getAttribute("user");
		List<CodeNode> l=tcrelationService.findTcrelationByTeacherid(t.getId());
		session.setAttribute("ccodeListByTid", l);
		return "/foreground/teacherCenterList";		
	}
	
	@RequestMapping(value = "/updateTeacherPassword")
	public String updateTeacherPassword(String id,String tpassword,String newPassword,HttpSession session){
		BTeacher b=teacherService.updateStudentPassword(id,tpassword,newPassword);
		session.removeAttribute("user");
		session.setAttribute("user", b);
		return "/foreground/teacherCenterList";		
	}
	
	@RequestMapping(value="teacherListExcel",method = RequestMethod.GET)
    public String teacherListExcel(Model model,TTeacher tteacher) {
        List<TTeacher> lists = teacherService.findExcelTeacher(tteacher);
        String filename = "老师信息表";
        String jspPath = "teacherListExcel";
        model.addAttribute("lists", lists);
        model.addAttribute("filename", filename);
        model.addAttribute("jspPath", jspPath);
        return "/background/common/excel";
    }
	
	@RequestMapping(value = "/importTeacherExcel")
	@ResponseBody
	public JsonResult importTeacherExcel(MultipartHttpServletRequest request){
		JsonResult j=new JsonResult();
		for (MultipartFile file : request.getFileMap().values()){
            try {
            	teacherService.importTeacherExcel(file);
            	j.setSuccess(true);
    			j.setMsg("更新成功!");
            } catch (Exception e) {
            	e.printStackTrace();
    			j.setMsg("更新失败!");
            }
        }	
		return j;	
	}
}