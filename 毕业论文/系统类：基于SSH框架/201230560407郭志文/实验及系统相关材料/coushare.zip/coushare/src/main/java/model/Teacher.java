package model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

/**
 * Teacher entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "teacher", catalog = "coushare", uniqueConstraints = @UniqueConstraint(columnNames = "tcode"))
public class Teacher implements java.io.Serializable {

	// Fields

	private Integer id;
	private String tcode;
	private String tname;
	private String tpassword;
	private Date birth;
	private String sex;
	private Date employmentdate;
	private String phone;
	private String email;
	private String college;
	private String tstate;
	private Set<Tcrelation> tcrelations = new HashSet<Tcrelation>(0);

	// Constructors

	/** default constructor */
	public Teacher() {
	}

	/** minimal constructor */
	public Teacher(String tcode, String tname, String tpassword) {
		this.tcode = tcode;
		this.tname = tname;
		this.tpassword = tpassword;
	}

	/** full constructor */
	public Teacher(String tcode, String tname, String tpassword, Date birth,
			String sex, Date employmentdate, String phone, String email,
			String college, String tstate, Set<Tcrelation> tcrelations) {
		this.tcode = tcode;
		this.tname = tname;
		this.tpassword = tpassword;
		this.birth = birth;
		this.sex = sex;
		this.employmentdate = employmentdate;
		this.phone = phone;
		this.email = email;
		this.college = college;
		this.tstate = tstate;
		this.tcrelations = tcrelations;
	}

	// Property accessors
	@Id
	@GeneratedValue
	@Column(name = "id", unique = true, nullable = false)
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "tcode", unique = true, nullable = false)
	public String getTcode() {
		return this.tcode;
	}

	public void setTcode(String tcode) {
		this.tcode = tcode;
	}

	@Column(name = "tname", nullable = false, length = 80)
	public String getTname() {
		return this.tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	@Column(name = "tpassword", nullable = false, length = 80)
	public String getTpassword() {
		return this.tpassword;
	}

	public void setTpassword(String tpassword) {
		this.tpassword = tpassword;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "birth", length = 10)
	public Date getBirth() {
		return this.birth;
	}

	public void setBirth(Date birth) {
		this.birth = birth;
	}

	@Column(name = "sex", length = 30)
	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "employmentdate", length = 10)
	public Date getEmploymentdate() {
		return this.employmentdate;
	}

	public void setEmploymentdate(Date employmentdate) {
		this.employmentdate = employmentdate;
	}

	@Column(name = "phone", length = 30)
	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Column(name = "email", length = 30)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "college", length = 80)
	public String getCollege() {
		return this.college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	@Column(name = "tstate", length = 30)
	public String getTstate() {
		return this.tstate;
	}

	public void setTstate(String tstate) {
		this.tstate = tstate;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "teacher")
	public Set<Tcrelation> getTcrelations() {
		return this.tcrelations;
	}

	public void setTcrelations(Set<Tcrelation> tcrelations) {
		this.tcrelations = tcrelations;
	}

}