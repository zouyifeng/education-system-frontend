package dao.impl;

import org.springframework.stereotype.Repository;

import dao.MenuDaoI;
import model.Menu;
@Repository("menuDao")
public class MenuDaoImpl extends BaseDaoImpl<Menu> implements MenuDaoI{

}
