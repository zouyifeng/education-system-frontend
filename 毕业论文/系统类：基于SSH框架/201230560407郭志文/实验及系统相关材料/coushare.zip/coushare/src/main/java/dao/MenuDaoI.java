package dao;

import model.Menu;

public interface MenuDaoI extends BaseDaoI<Menu>{

}