package dao.impl;

import org.springframework.stereotype.Repository;

import dao.CourseDaoI;
import model.Course;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
@Repository("courseDao")
public class CourseDaoImpl extends BaseDaoImpl<Course> implements CourseDaoI{

}