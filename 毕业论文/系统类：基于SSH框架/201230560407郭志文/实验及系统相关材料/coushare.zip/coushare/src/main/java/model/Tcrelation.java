package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Tcrelation entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "tcrelation", catalog = "coushare")
public class Tcrelation implements java.io.Serializable {

	// Fields

	private Integer id;
	private Teacher teacher;
	private Course course;

	// Constructors

	/** default constructor */
	public Tcrelation() {
	}

	/** full constructor */
	public Tcrelation(Teacher teacher, Course course) {
		this.teacher = teacher;
		this.course = course;
	}

	// Property accessors
	@Id
	@GeneratedValue
	@Column(name = "id", unique = true, nullable = false)
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "tid", nullable = false)
	public Teacher getTeacher() {
		return this.teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "cid", nullable = false)
	public Course getCourse() {
		return this.course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

}