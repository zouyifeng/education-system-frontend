package util;

/**
 * @Author: guozhiwen
 * @File: UploadServiceImpl.java
 * @DATE: 2016-01-25
 * @TIME: 11:23
 */
public class PathUtil {

    public static String wrapperPath(String path) {
        if (path == null || path.equals("")) {
            return "";
        }
        return "/" + path + "/";
    }
}