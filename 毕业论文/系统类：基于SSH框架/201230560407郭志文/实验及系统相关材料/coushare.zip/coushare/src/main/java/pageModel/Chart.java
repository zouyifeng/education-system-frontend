package pageModel;

import java.util.List;

/**
 * TODO 类/接口描述信息
 *
 * @author LevenGuo
 *
 */
public class Chart {
	
	private List<String> categories;
	private Highchart highchart;
	public List<String> getCategories() {
		return categories;
	}
	public void setCategories(List<String> categories) {
		this.categories = categories;
	}
	public Highchart getHighchart() {
		return highchart;
	}
	public void setHighchart(Highchart highchart) {
		this.highchart = highchart;
	}

}

